var utg = 
{
  "nodes": [
    {
      "id": "aed03111cf473b5dbe1869f144ad5f56",
      "shape": "image",
      "image": "states\\screen_2025-06-27_155236.png",
      "label": "NexusLauncherActivity\n<FIRST>",
      "package": "com.google.android.apps.nexuslauncher",
      "activity": ".NexusLauncherActivity",
      "state_str": "aed03111cf473b5dbe1869f144ad5f56",
      "structure_str": "0b6248faa98da8f552fcf7a8c078455c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.apps.nexuslauncher</td></tr>\n<tr><th>activity</th><td>.NexusLauncherActivity</td></tr>\n<tr><th>state_str</th><td>aed03111cf473b5dbe1869f144ad5f56</td></tr>\n<tr><th>structure_str</th><td>0b6248faa98da8f552fcf7a8c078455c</td></tr>\n</table>",
      "content": "com.google.android.apps.nexuslauncher\n.NexusLauncherActivity\naed03111cf473b5dbe1869f144ad5f56\ncom.google.android.apps.nexuslauncher:id/scrim_view,com.google.android.apps.nexuslauncher:id/smartspace_subtitle_group,com.google.android.apps.nexuslauncher:id/search_container_workspace,com.google.android.apps.nexuslauncher:id/date,com.google.android.apps.nexuslauncher:id/end_part,com.google.android.apps.nexuslauncher:id/smartspace_card_pager,com.google.android.apps.nexuslauncher:id/lens_icon,com.google.android.apps.nexuslauncher:id/overview_actions_view,com.google.android.apps.nexuslauncher:id/base_template_card_with_date,com.google.android.apps.nexuslauncher:id/launcher,com.google.android.apps.nexuslauncher:id/mic_icon,com.google.android.apps.nexuslauncher:id/g_icon,com.google.android.apps.nexuslauncher:id/hotseat,com.google.android.apps.nexuslauncher:id/page_indicator,com.google.android.apps.nexuslauncher:id/bc_smartspace_view,com.google.android.apps.nexuslauncher:id/workspace,com.google.android.apps.nexuslauncher:id/search_container_hotseat,com.google.android.apps.nexuslauncher:id/drag_layer,com.google.android.apps.nexuslauncher:id/text_group,android:id/content\nChrome,Messages,Gmail,Photos,Fri, Jun 27,Phone,DroidBot,YouTube",
      "font": "14px Arial red"
    },
    {
      "id": "d41d8cd98f00b204e9800998ecf8427e",
      "shape": "image",
      "image": "states\\screen_2025-06-27_155246.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "d41d8cd98f00b204e9800998ecf8427e",
      "structure_str": "d41d8cd98f00b204e9800998ecf8427e",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>d41d8cd98f00b204e9800998ecf8427e</td></tr>\n<tr><th>structure_str</th><td>d41d8cd98f00b204e9800998ecf8427e</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nd41d8cd98f00b204e9800998ecf8427e\n\n"
    },
    {
      "id": "51625852089189a0c50eb06339aae31d",
      "shape": "image",
      "image": "states\\screen_2025-06-27_155258.png",
      "label": "FeatureLauncherActivity\n<LAST>",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "51625852089189a0c50eb06339aae31d",
      "structure_str": "42de170b4a3e82b3fa6549fac65f1e86",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>51625852089189a0c50eb06339aae31d</td></tr>\n<tr><th>structure_str</th><td>42de170b4a3e82b3fa6549fac65f1e86</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\n51625852089189a0c50eb06339aae31d\ncom.fsck.k9.debug:id/action_bar_root,android:id/navigationBarBackground,android:id/statusBarBackground,android:id/content\nDeveloped by a dedicated team at MZLA Technologies and a global community of volunteers. Part of the Mozilla family.,Get started,An open source, privacy-focused and ad-free email app for Android.,Import settings,K-9 Mail",
      "font": "14px Arial red"
    },
    {
      "id": "097dbdfba4aab2568bdfe5beb2629fe0",
      "shape": "image",
      "image": "states\\screen_2025-06-27_155304.png",
      "label": "FeatureLauncherActivity",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "097dbdfba4aab2568bdfe5beb2629fe0",
      "structure_str": "94a485b7faea4a07e4c262f85f8b9b50",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>097dbdfba4aab2568bdfe5beb2629fe0</td></tr>\n<tr><th>structure_str</th><td>94a485b7faea4a07e4c262f85f8b9b50</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\n097dbdfba4aab2568bdfe5beb2629fe0\nandroid:id/navigationBarBackground,com.fsck.k9.debug:id/pickDocumentButton,android:id/statusBarBackground,com.fsck.k9.debug:id/importButton,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/bottomBar,android:id/content\nImport,Select file,Import settings"
    },
    {
      "id": "d6c61a4c29944b7f61b470434178ab2b",
      "shape": "image",
      "image": "states\\screen_2025-06-27_155315.png",
      "label": "FeatureLauncherActivity",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "d6c61a4c29944b7f61b470434178ab2b",
      "structure_str": "b071af21650fd584c3391d2507692670",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>d6c61a4c29944b7f61b470434178ab2b</td></tr>\n<tr><th>structure_str</th><td>b071af21650fd584c3391d2507692670</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\nd6c61a4c29944b7f61b470434178ab2b\ncom.fsck.k9.debug:id/action_bar_root,android:id/navigationBarBackground,android:id/statusBarBackground,android:id/content\nNext,Email address,Back,K-9 Mail"
    },
    {
      "id": "41efd37e2f5cd7b1e8722e185673a548",
      "shape": "image",
      "image": "states\\screen_2025-06-27_155337.png",
      "label": "FeatureLauncherActivity",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "41efd37e2f5cd7b1e8722e185673a548",
      "structure_str": "2cd88e2aeced5a3b61beb965512dfcde",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>41efd37e2f5cd7b1e8722e185673a548</td></tr>\n<tr><th>structure_str</th><td>2cd88e2aeced5a3b61beb965512dfcde</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\n41efd37e2f5cd7b1e8722e185673a548\ncom.fsck.k9.debug:id/action_bar_root,android:id/navigationBarBackground,android:id/statusBarBackground,android:id/content\nNext,Email address,Back,K-9 Mail"
    },
    {
      "id": "0538a2348b7d65d629bb50b56677c4c8",
      "shape": "image",
      "image": "states\\screen_2025-06-27_155401.png",
      "label": "FeatureLauncherActivity",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "0538a2348b7d65d629bb50b56677c4c8",
      "structure_str": "5e4bba131a509c0cd28ff1c8b05b4bf2",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>0538a2348b7d65d629bb50b56677c4c8</td></tr>\n<tr><th>structure_str</th><td>5e4bba131a509c0cd28ff1c8b05b4bf2</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\n0538a2348b7d65d629bb50b56677c4c8\ncom.fsck.k9.debug:id/action_bar_root,android:id/navigationBarBackground,android:id/statusBarBackground,android:id/content\n2,Back,Next,Email address,K-9 Mail"
    },
    {
      "id": "360cc07bef0e102ec605189cd6703631",
      "shape": "image",
      "image": "states\\screen_2025-06-27_155947.png",
      "label": "NexusLauncherActivity",
      "package": "com.google.android.apps.nexuslauncher",
      "activity": ".NexusLauncherActivity",
      "state_str": "360cc07bef0e102ec605189cd6703631",
      "structure_str": "8dd75866c51ca1fc92a8516e56761391",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.apps.nexuslauncher</td></tr>\n<tr><th>activity</th><td>.NexusLauncherActivity</td></tr>\n<tr><th>state_str</th><td>360cc07bef0e102ec605189cd6703631</td></tr>\n<tr><th>structure_str</th><td>8dd75866c51ca1fc92a8516e56761391</td></tr>\n</table>",
      "content": "com.google.android.apps.nexuslauncher\n.NexusLauncherActivity\n360cc07bef0e102ec605189cd6703631\ncom.google.android.apps.nexuslauncher:id/scrim_view,com.google.android.apps.nexuslauncher:id/smartspace_subtitle_group,com.google.android.apps.nexuslauncher:id/got_it,com.google.android.apps.nexuslauncher:id/search_container_workspace,com.google.android.apps.nexuslauncher:id/typeahead_input,com.google.android.apps.nexuslauncher:id/date,com.google.android.apps.nexuslauncher:id/title_text,com.google.android.apps.nexuslauncher:id/lens_icon,com.google.android.apps.nexuslauncher:id/smartspace_card_pager,com.google.android.apps.nexuslauncher:id/overview_actions_view,com.google.android.apps.nexuslauncher:id/base_template_card_with_date,com.google.android.apps.nexuslauncher:id/launcher,com.google.android.apps.nexuslauncher:id/end_icons,com.google.android.apps.nexuslauncher:id/apps_view,com.google.android.apps.nexuslauncher:id/search_settings_button,com.google.android.apps.nexuslauncher:id/ripple,com.google.android.apps.nexuslauncher:id/search_results_list_view,com.google.android.apps.nexuslauncher:id/mic_icon,com.google.android.apps.nexuslauncher:id/input,com.google.android.apps.nexuslauncher:id/g_icon,com.google.android.apps.nexuslauncher:id/body_text,com.google.android.apps.nexuslauncher:id/search_container_all_apps,com.google.android.apps.nexuslauncher:id/action_btn_container,com.google.android.apps.nexuslauncher:id/learn_more_button,com.google.android.apps.nexuslauncher:id/fast_scroller_popup,com.google.android.apps.nexuslauncher:id/search_result_divider,com.google.android.apps.nexuslauncher:id/bc_smartspace_view,com.google.android.apps.nexuslauncher:id/workspace,com.google.android.apps.nexuslauncher:id/drag_layer,com.google.android.apps.nexuslauncher:id/text_group,android:id/content\nSearch web and more,Marder,Gmail,YouTube,Photos,Fri, Jun 27,You can search for web and app content from logged in accounts, including Play, Settings and Contacts. Selected suggestions may be saved in your Google app or Google Play search history. You can make updates in search settings.,Got it,Omni Notes Alpha,K-9 Mail,PassAndroid"
    }
  ],
  "edges": [
    {
      "from": "aed03111cf473b5dbe1869f144ad5f56",
      "to": "d41d8cd98f00b204e9800998ecf8427e",
      "id": "aed03111cf473b5dbe1869f144ad5f56-->d41d8cd98f00b204e9800998ecf8427e",
      "title": "<table class=\"table\">\n<tr><th>22</th><td>IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')</td></tr>\n</table>",
      "label": "22",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')",
          "event_id": 22,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "aed03111cf473b5dbe1869f144ad5f56",
      "to": "51625852089189a0c50eb06339aae31d",
      "id": "aed03111cf473b5dbe1869f144ad5f56-->51625852089189a0c50eb06339aae31d",
      "title": "<table class=\"table\">\n<tr><th>22</th><td>IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')</td></tr>\n</table>",
      "label": "22",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')",
          "event_id": 22,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "aed03111cf473b5dbe1869f144ad5f56",
      "to": "360cc07bef0e102ec605189cd6703631",
      "id": "aed03111cf473b5dbe1869f144ad5f56-->360cc07bef0e102ec605189cd6703631",
      "title": "<table class=\"table\">\n<tr><th>23</th><td>LongTouchEvent(state=aed03111cf473b5dbe1869f144ad5f56, view=4d2857b636a1befead0b77c7d76d097b(NexusLauncherActivity/FrameLayout-))</td></tr>\n</table>",
      "label": "23",
      "events": [
        {
          "event_str": "LongTouchEvent(state=aed03111cf473b5dbe1869f144ad5f56, view=4d2857b636a1befead0b77c7d76d097b(NexusLauncherActivity/FrameLayout-))",
          "event_id": 23,
          "event_type": "long_touch",
          "view_images": [
            "views/view_4d2857b636a1befead0b77c7d76d097b.png"
          ]
        }
      ]
    },
    {
      "from": "d41d8cd98f00b204e9800998ecf8427e",
      "to": "aed03111cf473b5dbe1869f144ad5f56",
      "id": "d41d8cd98f00b204e9800998ecf8427e-->aed03111cf473b5dbe1869f144ad5f56",
      "title": "<table class=\"table\">\n<tr><th>22</th><td>KeyEvent(state=d41d8cd98f00b204e9800998ecf8427e, name=BACK)</td></tr>\n<tr><th>22</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "22, 22",
      "events": [
        {
          "event_str": "KeyEvent(state=d41d8cd98f00b204e9800998ecf8427e, name=BACK)",
          "event_id": 22,
          "event_type": "key",
          "view_images": []
        },
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 22,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "d41d8cd98f00b204e9800998ecf8427e",
      "to": "097dbdfba4aab2568bdfe5beb2629fe0",
      "id": "d41d8cd98f00b204e9800998ecf8427e-->097dbdfba4aab2568bdfe5beb2629fe0",
      "title": "<table class=\"table\">\n<tr><th>20</th><td>KeyEvent(state=d41d8cd98f00b204e9800998ecf8427e, name=BACK)</td></tr>\n</table>",
      "label": "20",
      "events": [
        {
          "event_str": "KeyEvent(state=d41d8cd98f00b204e9800998ecf8427e, name=BACK)",
          "event_id": 20,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "d41d8cd98f00b204e9800998ecf8427e",
      "to": "360cc07bef0e102ec605189cd6703631",
      "id": "d41d8cd98f00b204e9800998ecf8427e-->360cc07bef0e102ec605189cd6703631",
      "title": "<table class=\"table\">\n<tr><th>23</th><td>KeyEvent(state=d41d8cd98f00b204e9800998ecf8427e, name=BACK)</td></tr>\n</table>",
      "label": "23",
      "events": [
        {
          "event_str": "KeyEvent(state=d41d8cd98f00b204e9800998ecf8427e, name=BACK)",
          "event_id": 23,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "51625852089189a0c50eb06339aae31d",
      "to": "097dbdfba4aab2568bdfe5beb2629fe0",
      "id": "51625852089189a0c50eb06339aae31d-->097dbdfba4aab2568bdfe5beb2629fe0",
      "title": "<table class=\"table\">\n<tr><th>15</th><td>TouchEvent(state=51625852089189a0c50eb06339aae31d, view=44cc06867b634ae67a4210bf3a6782c5(FeatureLauncherActivity/View-))</td></tr>\n<tr><th>17</th><td>TouchEvent(state=51625852089189a0c50eb06339aae31d, view=c46a26225470ff92da87d9a1670a16e5(FeatureLauncherActivity/TextView-Import set))</td></tr>\n<tr><th>19</th><td>TouchEvent(state=51625852089189a0c50eb06339aae31d, view=338c2b2e1e399e974ea948967a22dc02(FeatureLauncherActivity/Button-))</td></tr>\n</table>",
      "label": "15, 17, 19",
      "events": [
        {
          "event_str": "TouchEvent(state=51625852089189a0c50eb06339aae31d, view=44cc06867b634ae67a4210bf3a6782c5(FeatureLauncherActivity/View-))",
          "event_id": 15,
          "event_type": "touch",
          "view_images": [
            "views/view_44cc06867b634ae67a4210bf3a6782c5.png"
          ]
        },
        {
          "event_str": "TouchEvent(state=51625852089189a0c50eb06339aae31d, view=c46a26225470ff92da87d9a1670a16e5(FeatureLauncherActivity/TextView-Import set))",
          "event_id": 17,
          "event_type": "touch",
          "view_images": [
            "views/view_c46a26225470ff92da87d9a1670a16e5.png"
          ]
        },
        {
          "event_str": "TouchEvent(state=51625852089189a0c50eb06339aae31d, view=338c2b2e1e399e974ea948967a22dc02(FeatureLauncherActivity/Button-))",
          "event_id": 19,
          "event_type": "touch",
          "view_images": [
            "views/view_338c2b2e1e399e974ea948967a22dc02.png"
          ]
        }
      ]
    },
    {
      "from": "51625852089189a0c50eb06339aae31d",
      "to": "d6c61a4c29944b7f61b470434178ab2b",
      "id": "51625852089189a0c50eb06339aae31d-->d6c61a4c29944b7f61b470434178ab2b",
      "title": "<table class=\"table\">\n<tr><th>11</th><td>TouchEvent(state=51625852089189a0c50eb06339aae31d, view=e245bd5b29fa5ca0b87d8acca15f8100(FeatureLauncherActivity/View-))</td></tr>\n<tr><th>22</th><td>TouchEvent(state=51625852089189a0c50eb06339aae31d, view=ed098265dd043ac0f69cf666f68144ce(FeatureLauncherActivity/TextView-Get starte))</td></tr>\n</table>",
      "label": "11, 22",
      "events": [
        {
          "event_str": "TouchEvent(state=51625852089189a0c50eb06339aae31d, view=e245bd5b29fa5ca0b87d8acca15f8100(FeatureLauncherActivity/View-))",
          "event_id": 11,
          "event_type": "touch",
          "view_images": [
            "views/view_e245bd5b29fa5ca0b87d8acca15f8100.png"
          ]
        },
        {
          "event_str": "TouchEvent(state=51625852089189a0c50eb06339aae31d, view=ed098265dd043ac0f69cf666f68144ce(FeatureLauncherActivity/TextView-Get starte))",
          "event_id": 22,
          "event_type": "touch",
          "view_images": [
            "views/view_ed098265dd043ac0f69cf666f68144ce.png"
          ]
        }
      ]
    },
    {
      "from": "51625852089189a0c50eb06339aae31d",
      "to": "aed03111cf473b5dbe1869f144ad5f56",
      "id": "51625852089189a0c50eb06339aae31d-->aed03111cf473b5dbe1869f144ad5f56",
      "title": "<table class=\"table\">\n<tr><th>19</th><td>KeyEvent(state=51625852089189a0c50eb06339aae31d, name=BACK)</td></tr>\n</table>",
      "label": "19",
      "events": [
        {
          "event_str": "KeyEvent(state=51625852089189a0c50eb06339aae31d, name=BACK)",
          "event_id": 19,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "097dbdfba4aab2568bdfe5beb2629fe0",
      "to": "51625852089189a0c50eb06339aae31d",
      "id": "097dbdfba4aab2568bdfe5beb2629fe0-->51625852089189a0c50eb06339aae31d",
      "title": "<table class=\"table\">\n<tr><th>4</th><td>TouchEvent(state=097dbdfba4aab2568bdfe5beb2629fe0, view=ef500b81f8f414edf686e15b2500f668(FeatureLauncherActivity/View-))</td></tr>\n<tr><th>16</th><td>TouchEvent(state=097dbdfba4aab2568bdfe5beb2629fe0, view=338c2b2e1e399e974ea948967a22dc02(FeatureLauncherActivity/Button-))</td></tr>\n<tr><th>18</th><td>TouchEvent(state=097dbdfba4aab2568bdfe5beb2629fe0, view=3fb0ff50d81f3e47d2692cddea0fee69(FeatureLauncherActivity/View-))</td></tr>\n<tr><th>21</th><td>KeyEvent(state=097dbdfba4aab2568bdfe5beb2629fe0, name=BACK)</td></tr>\n</table>",
      "label": "4, 16, 18, 21",
      "events": [
        {
          "event_str": "TouchEvent(state=097dbdfba4aab2568bdfe5beb2629fe0, view=ef500b81f8f414edf686e15b2500f668(FeatureLauncherActivity/View-))",
          "event_id": 4,
          "event_type": "touch",
          "view_images": [
            "views/view_ef500b81f8f414edf686e15b2500f668.png"
          ]
        },
        {
          "event_str": "TouchEvent(state=097dbdfba4aab2568bdfe5beb2629fe0, view=338c2b2e1e399e974ea948967a22dc02(FeatureLauncherActivity/Button-))",
          "event_id": 16,
          "event_type": "touch",
          "view_images": [
            "views/view_338c2b2e1e399e974ea948967a22dc02.png"
          ]
        },
        {
          "event_str": "TouchEvent(state=097dbdfba4aab2568bdfe5beb2629fe0, view=3fb0ff50d81f3e47d2692cddea0fee69(FeatureLauncherActivity/View-))",
          "event_id": 18,
          "event_type": "touch",
          "view_images": [
            "views/view_3fb0ff50d81f3e47d2692cddea0fee69.png"
          ]
        },
        {
          "event_str": "KeyEvent(state=097dbdfba4aab2568bdfe5beb2629fe0, name=BACK)",
          "event_id": 21,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "097dbdfba4aab2568bdfe5beb2629fe0",
      "to": "d41d8cd98f00b204e9800998ecf8427e",
      "id": "097dbdfba4aab2568bdfe5beb2629fe0-->d41d8cd98f00b204e9800998ecf8427e",
      "title": "<table class=\"table\">\n<tr><th>20</th><td>TouchEvent(state=097dbdfba4aab2568bdfe5beb2629fe0, view=c6e57d6be01f3b89a385123a0f7ee5ca(FeatureLauncherActivity/Button-Select fil))</td></tr>\n</table>",
      "label": "20",
      "events": [
        {
          "event_str": "TouchEvent(state=097dbdfba4aab2568bdfe5beb2629fe0, view=c6e57d6be01f3b89a385123a0f7ee5ca(FeatureLauncherActivity/Button-Select fil))",
          "event_id": 20,
          "event_type": "touch",
          "view_images": [
            "views/view_c6e57d6be01f3b89a385123a0f7ee5ca.png"
          ]
        }
      ]
    },
    {
      "from": "d6c61a4c29944b7f61b470434178ab2b",
      "to": "51625852089189a0c50eb06339aae31d",
      "id": "d6c61a4c29944b7f61b470434178ab2b-->51625852089189a0c50eb06339aae31d",
      "title": "<table class=\"table\">\n<tr><th>6</th><td>KeyEvent(state=d6c61a4c29944b7f61b470434178ab2b, name=BACK)</td></tr>\n</table>",
      "label": "6",
      "events": [
        {
          "event_str": "KeyEvent(state=d6c61a4c29944b7f61b470434178ab2b, name=BACK)",
          "event_id": 6,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "d6c61a4c29944b7f61b470434178ab2b",
      "to": "41efd37e2f5cd7b1e8722e185673a548",
      "id": "d6c61a4c29944b7f61b470434178ab2b-->41efd37e2f5cd7b1e8722e185673a548",
      "title": "<table class=\"table\">\n<tr><th>12</th><td>SetTextEvent(state=d6c61a4c29944b7f61b470434178ab2b, view=a94654e4c5453af34504c2a9780dc85d(FeatureLauncherActivity/EditText-), text=2)</td></tr>\n<tr><th>22</th><td>SetTextEvent(state=d6c61a4c29944b7f61b470434178ab2b, view=a94654e4c5453af34504c2a9780dc85d(FeatureLauncherActivity/EditText-), text=1)</td></tr>\n<tr><th>22</th><td>SetTextEvent(state=d6c61a4c29944b7f61b470434178ab2b, view=a94654e4c5453af34504c2a9780dc85d(FeatureLauncherActivity/EditText-), text=Humad)</td></tr>\n</table>",
      "label": "12, 22, 22",
      "events": [
        {
          "event_str": "SetTextEvent(state=d6c61a4c29944b7f61b470434178ab2b, view=a94654e4c5453af34504c2a9780dc85d(FeatureLauncherActivity/EditText-), text=2)",
          "event_id": 12,
          "event_type": "set_text",
          "view_images": [
            "views/view_a94654e4c5453af34504c2a9780dc85d.png"
          ]
        },
        {
          "event_str": "SetTextEvent(state=d6c61a4c29944b7f61b470434178ab2b, view=a94654e4c5453af34504c2a9780dc85d(FeatureLauncherActivity/EditText-), text=1)",
          "event_id": 22,
          "event_type": "set_text",
          "view_images": [
            "views/view_a94654e4c5453af34504c2a9780dc85d.png"
          ]
        },
        {
          "event_str": "SetTextEvent(state=d6c61a4c29944b7f61b470434178ab2b, view=a94654e4c5453af34504c2a9780dc85d(FeatureLauncherActivity/EditText-), text=Humad)",
          "event_id": 22,
          "event_type": "set_text",
          "view_images": [
            "views/view_a94654e4c5453af34504c2a9780dc85d.png"
          ]
        }
      ]
    },
    {
      "from": "41efd37e2f5cd7b1e8722e185673a548",
      "to": "0538a2348b7d65d629bb50b56677c4c8",
      "id": "41efd37e2f5cd7b1e8722e185673a548-->0538a2348b7d65d629bb50b56677c4c8",
      "title": "<table class=\"table\">\n<tr><th>14</th><td>KeyEvent(state=41efd37e2f5cd7b1e8722e185673a548, name=BACK)</td></tr>\n</table>",
      "label": "14",
      "events": [
        {
          "event_str": "KeyEvent(state=41efd37e2f5cd7b1e8722e185673a548, name=BACK)",
          "event_id": 14,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "41efd37e2f5cd7b1e8722e185673a548",
      "to": "aed03111cf473b5dbe1869f144ad5f56",
      "id": "41efd37e2f5cd7b1e8722e185673a548-->aed03111cf473b5dbe1869f144ad5f56",
      "title": "<table class=\"table\">\n<tr><th>22</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "22",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 22,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "0538a2348b7d65d629bb50b56677c4c8",
      "to": "51625852089189a0c50eb06339aae31d",
      "id": "0538a2348b7d65d629bb50b56677c4c8-->51625852089189a0c50eb06339aae31d",
      "title": "<table class=\"table\">\n<tr><th>14</th><td>KeyEvent(state=0538a2348b7d65d629bb50b56677c4c8, name=BACK)</td></tr>\n</table>",
      "label": "14",
      "events": [
        {
          "event_str": "KeyEvent(state=0538a2348b7d65d629bb50b56677c4c8, name=BACK)",
          "event_id": 14,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "0538a2348b7d65d629bb50b56677c4c8",
      "to": "41efd37e2f5cd7b1e8722e185673a548",
      "id": "0538a2348b7d65d629bb50b56677c4c8-->41efd37e2f5cd7b1e8722e185673a548",
      "title": "<table class=\"table\">\n<tr><th>13</th><td>SetTextEvent(state=0538a2348b7d65d629bb50b56677c4c8, view=400e887e00e8e251e031dcb575fb063a(FeatureLauncherActivity/EditText-Laura Lee), text=2)</td></tr>\n<tr><th>14</th><td>SetTextEvent(state=0538a2348b7d65d629bb50b56677c4c8, view=743df0adcf88b6b2c83f0455bd84da4c(FeatureLauncherActivity/EditText-2), text=2)</td></tr>\n</table>",
      "label": "13, 14",
      "events": [
        {
          "event_str": "SetTextEvent(state=0538a2348b7d65d629bb50b56677c4c8, view=400e887e00e8e251e031dcb575fb063a(FeatureLauncherActivity/EditText-Laura Lee), text=2)",
          "event_id": 13,
          "event_type": "set_text",
          "view_images": [
            "views/view_400e887e00e8e251e031dcb575fb063a.png"
          ]
        },
        {
          "event_str": "SetTextEvent(state=0538a2348b7d65d629bb50b56677c4c8, view=743df0adcf88b6b2c83f0455bd84da4c(FeatureLauncherActivity/EditText-2), text=2)",
          "event_id": 14,
          "event_type": "set_text",
          "view_images": [
            "views/view_743df0adcf88b6b2c83f0455bd84da4c.png"
          ]
        }
      ]
    },
    {
      "from": "360cc07bef0e102ec605189cd6703631",
      "to": "d41d8cd98f00b204e9800998ecf8427e",
      "id": "360cc07bef0e102ec605189cd6703631-->d41d8cd98f00b204e9800998ecf8427e",
      "title": "<table class=\"table\">\n<tr><th>23</th><td>IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')</td></tr>\n</table>",
      "label": "23",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')",
          "event_id": 23,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "360cc07bef0e102ec605189cd6703631",
      "to": "51625852089189a0c50eb06339aae31d",
      "id": "360cc07bef0e102ec605189cd6703631-->51625852089189a0c50eb06339aae31d",
      "title": "<table class=\"table\">\n<tr><th>23</th><td>IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')</td></tr>\n</table>",
      "label": "23",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')",
          "event_id": 23,
          "event_type": "intent",
          "view_images": []
        }
      ]
    }
  ],
  "num_nodes": 8,
  "num_edges": 19,
  "num_effective_events": 23,
  "num_reached_activities": 2,
  "test_date": "2025-06-27 15:51:13",
  "time_spent": 534.857654,
  "num_transitions": 79,
  "device_serial": "emulator-5554",
  "device_model_number": "sdk_gphone64_x86_64",
  "device_sdk_version": 35,
  "app_sha256": "44fdd3523a2839bc2f11f729ef1f48defbfc76a2a74fd27a55121a265e85c457",
  "app_package": "com.fsck.k9.debug",
  "app_main_activity": "com.fsck.k9.activity.MessageList",
  "app_num_total_activities": 28
}