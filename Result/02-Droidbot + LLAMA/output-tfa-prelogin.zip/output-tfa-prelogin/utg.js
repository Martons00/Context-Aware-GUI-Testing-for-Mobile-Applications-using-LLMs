var utg = 
{
  "nodes": [
    {
      "id": "c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104244.png",
      "label": "NexusLauncherActivity\n<FIRST>\n<LAST>",
      "package": "com.google.android.apps.nexuslauncher",
      "activity": ".NexusLauncherActivity",
      "state_str": "c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "structure_str": "345d86390034d21a3935ecda158a4915",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.apps.nexuslauncher</td></tr>\n<tr><th>activity</th><td>.NexusLauncherActivity</td></tr>\n<tr><th>state_str</th><td>c3e8c9a9fec5d9eed0f40a9783f44f1c</td></tr>\n<tr><th>structure_str</th><td>345d86390034d21a3935ecda158a4915</td></tr>\n</table>",
      "content": "com.google.android.apps.nexuslauncher\n.NexusLauncherActivity\nc3e8c9a9fec5d9eed0f40a9783f44f1c\ncom.google.android.apps.nexuslauncher:id/base_template_card_with_date,com.google.android.apps.nexuslauncher:id/launcher,com.google.android.apps.nexuslauncher:id/page_indicator,com.google.android.apps.nexuslauncher:id/search_container_hotseat,com.google.android.apps.nexuslauncher:id/hotseat,com.google.android.apps.nexuslauncher:id/overview_actions_view,com.google.android.apps.nexuslauncher:id/smartspace_subtitle_group,com.google.android.apps.nexuslauncher:id/search_container_workspace,com.google.android.apps.nexuslauncher:id/mic_icon,com.google.android.apps.nexuslauncher:id/drag_layer,com.google.android.apps.nexuslauncher:id/end_part,com.google.android.apps.nexuslauncher:id/text_group,com.google.android.apps.nexuslauncher:id/scrim_view,com.google.android.apps.nexuslauncher:id/g_icon,com.google.android.apps.nexuslauncher:id/bc_smartspace_view,com.google.android.apps.nexuslauncher:id/date,android:id/content,com.google.android.apps.nexuslauncher:id/smartspace_card_pager,com.google.android.apps.nexuslauncher:id/lens_icon,com.google.android.apps.nexuslauncher:id/workspace\nPhotos,Fri, Jun 27,Chrome,Messages,YouTube,Phone,DroidBot,Gmail",
      "font": "14px Arial red"
    },
    {
      "id": "61313c33ffc04b0a4ff93735152c7ddf",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104248.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "61313c33ffc04b0a4ff93735152c7ddf",
      "structure_str": "61313c33ffc04b0a4ff93735152c7ddf",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>61313c33ffc04b0a4ff93735152c7ddf</td></tr>\n<tr><th>structure_str</th><td>61313c33ffc04b0a4ff93735152c7ddf</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n61313c33ffc04b0a4ff93735152c7ddf\n\n"
    },
    {
      "id": "8006523b45a79f3278661fcaeaa2ebe3",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104258.png",
      "label": "FeatureLauncherActivity",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "8006523b45a79f3278661fcaeaa2ebe3",
      "structure_str": "c2b93caff0ce4107570c2653d42884e5",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>8006523b45a79f3278661fcaeaa2ebe3</td></tr>\n<tr><th>structure_str</th><td>c2b93caff0ce4107570c2653d42884e5</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\n8006523b45a79f3278661fcaeaa2ebe3\ncom.fsck.k9.debug:id/action_bar_root,android:id/content,android:id/navigationBarBackground,android:id/statusBarBackground\nAn open source, privacy-focused and ad-free email app for Android.,K-9 Mail,Import settings,Developed by a dedicated team at MZLA Technologies and a global community of volunteers. Part of the Mozilla family.,Get started"
    },
    {
      "id": "302e338ddac3fa6d57da0480959a3405",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104303.png",
      "label": "FeatureLauncherActivity",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "302e338ddac3fa6d57da0480959a3405",
      "structure_str": "3aaae71728e45ee8e274460b4e0c58ff",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>302e338ddac3fa6d57da0480959a3405</td></tr>\n<tr><th>structure_str</th><td>3aaae71728e45ee8e274460b4e0c58ff</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\n302e338ddac3fa6d57da0480959a3405\ncom.fsck.k9.debug:id/action_bar_root,android:id/content,android:id/navigationBarBackground,android:id/statusBarBackground\nBack,K-9 Mail,Next,Email address"
    },
    {
      "id": "a9e5ab939c46510919a403873570855c",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104314.png",
      "label": "FeatureLauncherActivity",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "a9e5ab939c46510919a403873570855c",
      "structure_str": "3aaae71728e45ee8e274460b4e0c58ff",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>a9e5ab939c46510919a403873570855c</td></tr>\n<tr><th>structure_str</th><td>3aaae71728e45ee8e274460b4e0c58ff</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\na9e5ab939c46510919a403873570855c\ncom.fsck.k9.debug:id/action_bar_root,android:id/content,android:id/navigationBarBackground,android:id/statusBarBackground\nK-9 Mail,Back,john.doe@exampl,Next,Email address"
    },
    {
      "id": "e2484d8b2a16670784e6c8d3ebd0fb2f",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104333.png",
      "label": "FeatureLauncherActivity",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "e2484d8b2a16670784e6c8d3ebd0fb2f",
      "structure_str": "e2484d8b2a16670784e6c8d3ebd0fb2f",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>e2484d8b2a16670784e6c8d3ebd0fb2f</td></tr>\n<tr><th>structure_str</th><td>e2484d8b2a16670784e6c8d3ebd0fb2f</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\ne2484d8b2a16670784e6c8d3ebd0fb2f\n\n"
    },
    {
      "id": "7134db92336404c40fcf2a8a0f182ffb",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104348.png",
      "label": "FeatureLauncherActivity",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "7134db92336404c40fcf2a8a0f182ffb",
      "structure_str": "f2aac67c8c48885752b304ea34d16658",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>7134db92336404c40fcf2a8a0f182ffb</td></tr>\n<tr><th>structure_str</th><td>f2aac67c8c48885752b304ea34d16658</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\n7134db92336404c40fcf2a8a0f182ffb\ncom.fsck.k9.debug:id/pickDocumentButton,android:id/navigationBarBackground,com.fsck.k9.debug:id/importButton,com.fsck.k9.debug:id/bottomBar,android:id/content,com.fsck.k9.debug:id/action_bar_root,android:id/statusBarBackground\nImport,Select file,Import settings"
    },
    {
      "id": "8c39b31ec7698d988a0395796fe63731",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104353.png",
      "label": "PickActivity",
      "package": "com.google.android.documentsui",
      "activity": "com.android.documentsui.picker.PickActivity",
      "state_str": "8c39b31ec7698d988a0395796fe63731",
      "structure_str": "06480fe8007c268975f44265bd0a36e6",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.documentsui</td></tr>\n<tr><th>activity</th><td>com.android.documentsui.picker.PickActivity</td></tr>\n<tr><th>state_str</th><td>8c39b31ec7698d988a0395796fe63731</td></tr>\n<tr><th>structure_str</th><td>06480fe8007c268975f44265bd0a36e6</td></tr>\n</table>",
      "content": "com.google.android.documentsui\ncom.android.documentsui.picker.PickActivity\n8c39b31ec7698d988a0395796fe63731\ncom.google.android.documentsui:id/item_root,com.google.android.documentsui:id/horizontal_breadcrumb,com.google.android.documentsui:id/header_title,com.google.android.documentsui:id/refresh_layout,com.google.android.documentsui:id/icon,com.google.android.documentsui:id/app_icon,com.google.android.documentsui:id/drawer_layout,com.google.android.documentsui:id/metadata,com.google.android.documentsui:id/action_bar_root,com.google.android.documentsui:id/directory_header,com.google.android.documentsui:id/container_directory,com.google.android.documentsui:id/container_search_fragment,com.google.android.documentsui:id/search_chip_group,com.google.android.documentsui:id/preview_icon,com.google.android.documentsui:id/container_save,com.google.android.documentsui:id/dir_list,com.google.android.documentsui:id/sub_menu_grid,com.google.android.documentsui:id/toolbar,com.google.android.documentsui:id/icon_thumb,com.google.android.documentsui:id/line2,com.google.android.documentsui:id/option_menu_search,com.google.android.documentsui:id/coordinator_layout,com.google.android.documentsui:id/sub_menu,com.google.android.documentsui:id/icon_check,android:id/title,com.google.android.documentsui:id/collapsing_toolbar,com.google.android.documentsui:id/header_container,com.google.android.documentsui:id/app_bar,com.google.android.documentsui:id/icon_mime,com.google.android.documentsui:id/apps_group,android:id/content,com.google.android.documentsui:id/drawer_edge,com.google.android.documentsui:id/apps_row\nBROWSE FILES IN OTHER APPS,Videos,Photos,Audio,Large files,May 25, 125 kB, PNG image,Images,Documents,Drive,This week,Media picker,Recent files,Recent,Screenshot_20250525-195320.png"
    },
    {
      "id": "c1c1fd93800024bf64f1cfee9d4f1fd5",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104358.png",
      "label": "PickActivity",
      "package": "com.google.android.documentsui",
      "activity": "com.android.documentsui.picker.PickActivity",
      "state_str": "c1c1fd93800024bf64f1cfee9d4f1fd5",
      "structure_str": "06480fe8007c268975f44265bd0a36e6",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.documentsui</td></tr>\n<tr><th>activity</th><td>com.android.documentsui.picker.PickActivity</td></tr>\n<tr><th>state_str</th><td>c1c1fd93800024bf64f1cfee9d4f1fd5</td></tr>\n<tr><th>structure_str</th><td>06480fe8007c268975f44265bd0a36e6</td></tr>\n</table>",
      "content": "com.google.android.documentsui\ncom.android.documentsui.picker.PickActivity\nc1c1fd93800024bf64f1cfee9d4f1fd5\ncom.google.android.documentsui:id/item_root,com.google.android.documentsui:id/horizontal_breadcrumb,com.google.android.documentsui:id/header_title,com.google.android.documentsui:id/refresh_layout,com.google.android.documentsui:id/icon,com.google.android.documentsui:id/app_icon,com.google.android.documentsui:id/drawer_layout,com.google.android.documentsui:id/metadata,com.google.android.documentsui:id/action_bar_root,com.google.android.documentsui:id/directory_header,com.google.android.documentsui:id/container_directory,com.google.android.documentsui:id/container_search_fragment,com.google.android.documentsui:id/search_chip_group,com.google.android.documentsui:id/preview_icon,com.google.android.documentsui:id/container_save,com.google.android.documentsui:id/dir_list,com.google.android.documentsui:id/sub_menu_grid,com.google.android.documentsui:id/toolbar,com.google.android.documentsui:id/icon_thumb,com.google.android.documentsui:id/line2,com.google.android.documentsui:id/option_menu_search,com.google.android.documentsui:id/coordinator_layout,com.google.android.documentsui:id/sub_menu,com.google.android.documentsui:id/icon_check,android:id/title,com.google.android.documentsui:id/collapsing_toolbar,com.google.android.documentsui:id/header_container,com.google.android.documentsui:id/app_bar,com.google.android.documentsui:id/icon_mime,com.google.android.documentsui:id/apps_group,android:id/content,com.google.android.documentsui:id/drawer_edge,com.google.android.documentsui:id/apps_row\nImages,Drive,May 16, 93.89 kB, PNG image,Recent,Videos,screen_2025-05-16_164645.png,Audio,Large files,May 16, 8.27 kB, PNG image,May 16, 62 B, PNG image,Files,This week,screen_2025-05-16_182455.png,May 13, 62 B, PNG image,Photos,May 17, 57.49 kB, PNG image,May 25, 125 kB, PNG image,screen_2025-05-17_133330.png,Screenshot_20250525-195320.png,screen_2025-05-16_181754.png,BROWSE FILES IN OTHER APPS,May 16, 71.15 kB, PNG image,Documents,screen_2025-05-16_163701.png,Media picker,screen_2025-05-13_183642.png"
    },
    {
      "id": "37c2eae9a2a375f34e0cc8aade3dd5de",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104403.png",
      "label": "PickActivity",
      "package": "com.google.android.documentsui",
      "activity": "com.android.documentsui.picker.PickActivity",
      "state_str": "37c2eae9a2a375f34e0cc8aade3dd5de",
      "structure_str": "06480fe8007c268975f44265bd0a36e6",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.documentsui</td></tr>\n<tr><th>activity</th><td>com.android.documentsui.picker.PickActivity</td></tr>\n<tr><th>state_str</th><td>37c2eae9a2a375f34e0cc8aade3dd5de</td></tr>\n<tr><th>structure_str</th><td>06480fe8007c268975f44265bd0a36e6</td></tr>\n</table>",
      "content": "com.google.android.documentsui\ncom.android.documentsui.picker.PickActivity\n37c2eae9a2a375f34e0cc8aade3dd5de\ncom.google.android.documentsui:id/item_root,com.google.android.documentsui:id/horizontal_breadcrumb,com.google.android.documentsui:id/header_title,com.google.android.documentsui:id/refresh_layout,com.google.android.documentsui:id/icon,com.google.android.documentsui:id/app_icon,com.google.android.documentsui:id/drawer_layout,com.google.android.documentsui:id/metadata,com.google.android.documentsui:id/action_bar_root,com.google.android.documentsui:id/directory_header,com.google.android.documentsui:id/container_directory,com.google.android.documentsui:id/container_search_fragment,com.google.android.documentsui:id/search_chip_group,com.google.android.documentsui:id/preview_icon,com.google.android.documentsui:id/container_save,com.google.android.documentsui:id/dir_list,com.google.android.documentsui:id/sub_menu_grid,com.google.android.documentsui:id/toolbar,com.google.android.documentsui:id/icon_thumb,com.google.android.documentsui:id/line2,com.google.android.documentsui:id/option_menu_search,com.google.android.documentsui:id/coordinator_layout,com.google.android.documentsui:id/sub_menu,com.google.android.documentsui:id/icon_check,android:id/title,com.google.android.documentsui:id/collapsing_toolbar,com.google.android.documentsui:id/header_container,com.google.android.documentsui:id/app_bar,com.google.android.documentsui:id/icon_mime,com.google.android.documentsui:id/apps_group,android:id/content,com.google.android.documentsui:id/drawer_edge,com.google.android.documentsui:id/apps_row\nBROWSE FILES IN OTHER APPS,Videos,Photos,10:44\u202fAM, 290 kB, PNG image,Audio,Large files,Images,Documents,Drive,This week,Media picker,Recent files,Recent,screen_2025-06-27_104401.png"
    },
    {
      "id": "78539d55fb0ea160a0b1911203129baa",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104409.png",
      "label": "PickActivity",
      "package": "com.google.android.documentsui",
      "activity": "com.android.documentsui.picker.PickActivity",
      "state_str": "78539d55fb0ea160a0b1911203129baa",
      "structure_str": "06480fe8007c268975f44265bd0a36e6",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.documentsui</td></tr>\n<tr><th>activity</th><td>com.android.documentsui.picker.PickActivity</td></tr>\n<tr><th>state_str</th><td>78539d55fb0ea160a0b1911203129baa</td></tr>\n<tr><th>structure_str</th><td>06480fe8007c268975f44265bd0a36e6</td></tr>\n</table>",
      "content": "com.google.android.documentsui\ncom.android.documentsui.picker.PickActivity\n78539d55fb0ea160a0b1911203129baa\ncom.google.android.documentsui:id/item_root,com.google.android.documentsui:id/horizontal_breadcrumb,com.google.android.documentsui:id/header_title,com.google.android.documentsui:id/refresh_layout,com.google.android.documentsui:id/icon,com.google.android.documentsui:id/app_icon,com.google.android.documentsui:id/drawer_layout,com.google.android.documentsui:id/metadata,com.google.android.documentsui:id/action_bar_root,com.google.android.documentsui:id/directory_header,com.google.android.documentsui:id/container_directory,com.google.android.documentsui:id/container_search_fragment,com.google.android.documentsui:id/search_chip_group,com.google.android.documentsui:id/preview_icon,com.google.android.documentsui:id/container_save,com.google.android.documentsui:id/dir_list,com.google.android.documentsui:id/sub_menu_grid,com.google.android.documentsui:id/toolbar,com.google.android.documentsui:id/icon_thumb,com.google.android.documentsui:id/line2,com.google.android.documentsui:id/option_menu_search,com.google.android.documentsui:id/coordinator_layout,com.google.android.documentsui:id/sub_menu,com.google.android.documentsui:id/icon_check,android:id/title,com.google.android.documentsui:id/collapsing_toolbar,com.google.android.documentsui:id/header_container,com.google.android.documentsui:id/app_bar,com.google.android.documentsui:id/icon_mime,com.google.android.documentsui:id/apps_group,android:id/content,com.google.android.documentsui:id/drawer_edge,com.google.android.documentsui:id/apps_row\nMay 10, 49.29 kB, PNG image,Images,Drive,May 16, 93.89 kB, PNG image,Recent,screen_2025-05-10_121419.png,Videos,screen_2025-05-16_164645.png,May 13, 49.29 kB, PNG image,Audio,screen_2025-05-10_120448.png,Large files,May 16, 8.27 kB, PNG image,May 16, 62 B, PNG image,Files,This week,screen_2025-05-16_182455.png,May 13, 62 B, PNG image,screen_2025-05-13_180509.png,Photos,May 17, 57.49 kB, PNG image,May 25, 125 kB, PNG image,screen_2025-05-17_133330.png,Screenshot_20250525-195320.png,screen_2025-05-16_181754.png,screen_2025-05-13_183349.png,May 13, 61.73 kB, PNG image,BROWSE FILES IN OTHER APPS,May 16, 71.15 kB, PNG image,May 10, 58.58 kB, PNG image,Documents,screen_2025-05-16_163701.png,Media picker,screen_2025-05-13_183642.png"
    },
    {
      "id": "3db1de1be1439e12b72cda678753836d",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104414.png",
      "label": "PickActivity",
      "package": "com.google.android.documentsui",
      "activity": "com.android.documentsui.picker.PickActivity",
      "state_str": "3db1de1be1439e12b72cda678753836d",
      "structure_str": "06480fe8007c268975f44265bd0a36e6",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.documentsui</td></tr>\n<tr><th>activity</th><td>com.android.documentsui.picker.PickActivity</td></tr>\n<tr><th>state_str</th><td>3db1de1be1439e12b72cda678753836d</td></tr>\n<tr><th>structure_str</th><td>06480fe8007c268975f44265bd0a36e6</td></tr>\n</table>",
      "content": "com.google.android.documentsui\ncom.android.documentsui.picker.PickActivity\n3db1de1be1439e12b72cda678753836d\ncom.google.android.documentsui:id/item_root,com.google.android.documentsui:id/horizontal_breadcrumb,com.google.android.documentsui:id/header_title,com.google.android.documentsui:id/refresh_layout,com.google.android.documentsui:id/icon,com.google.android.documentsui:id/app_icon,com.google.android.documentsui:id/drawer_layout,com.google.android.documentsui:id/metadata,com.google.android.documentsui:id/action_bar_root,com.google.android.documentsui:id/directory_header,com.google.android.documentsui:id/container_directory,com.google.android.documentsui:id/container_search_fragment,com.google.android.documentsui:id/search_chip_group,com.google.android.documentsui:id/preview_icon,com.google.android.documentsui:id/container_save,com.google.android.documentsui:id/dir_list,com.google.android.documentsui:id/sub_menu_grid,com.google.android.documentsui:id/toolbar,com.google.android.documentsui:id/icon_thumb,com.google.android.documentsui:id/line2,com.google.android.documentsui:id/option_menu_search,com.google.android.documentsui:id/coordinator_layout,com.google.android.documentsui:id/sub_menu,com.google.android.documentsui:id/icon_check,android:id/title,com.google.android.documentsui:id/collapsing_toolbar,com.google.android.documentsui:id/header_container,com.google.android.documentsui:id/app_bar,com.google.android.documentsui:id/icon_mime,com.google.android.documentsui:id/apps_group,android:id/content,com.google.android.documentsui:id/drawer_edge,com.google.android.documentsui:id/apps_row\nImages,Drive,May 16, 93.89 kB, PNG image,Recent,Videos,screen_2025-05-16_164645.png,May 13, 49.29 kB, PNG image,Audio,Large files,May 16, 8.27 kB, PNG image,May 16, 62 B, PNG image,This week,screen_2025-05-16_182455.png,May 13, 62 B, PNG image,screen_2025-05-13_180509.png,Photos,May 17, 57.49 kB, PNG image,May 25, 125 kB, PNG image,screen_2025-05-17_133330.png,Screenshot_20250525-195320.png,screen_2025-05-16_181754.png,screen_2025-05-13_183349.png,May 13, 61.73 kB, PNG image,BROWSE FILES IN OTHER APPS,May 16, 71.15 kB, PNG image,Documents,screen_2025-05-16_163701.png,Media picker,Recent files,screen_2025-05-13_183642.png"
    },
    {
      "id": "0d6c9d4f1e1453576cf942bc95e00fa8",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104425.png",
      "label": "PickActivity",
      "package": "com.google.android.documentsui",
      "activity": "com.android.documentsui.picker.PickActivity",
      "state_str": "0d6c9d4f1e1453576cf942bc95e00fa8",
      "structure_str": "06480fe8007c268975f44265bd0a36e6",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.documentsui</td></tr>\n<tr><th>activity</th><td>com.android.documentsui.picker.PickActivity</td></tr>\n<tr><th>state_str</th><td>0d6c9d4f1e1453576cf942bc95e00fa8</td></tr>\n<tr><th>structure_str</th><td>06480fe8007c268975f44265bd0a36e6</td></tr>\n</table>",
      "content": "com.google.android.documentsui\ncom.android.documentsui.picker.PickActivity\n0d6c9d4f1e1453576cf942bc95e00fa8\ncom.google.android.documentsui:id/item_root,com.google.android.documentsui:id/horizontal_breadcrumb,com.google.android.documentsui:id/header_title,com.google.android.documentsui:id/refresh_layout,com.google.android.documentsui:id/icon,com.google.android.documentsui:id/app_icon,com.google.android.documentsui:id/drawer_layout,com.google.android.documentsui:id/metadata,com.google.android.documentsui:id/action_bar_root,com.google.android.documentsui:id/directory_header,com.google.android.documentsui:id/container_directory,com.google.android.documentsui:id/container_search_fragment,com.google.android.documentsui:id/search_chip_group,com.google.android.documentsui:id/preview_icon,com.google.android.documentsui:id/container_save,com.google.android.documentsui:id/dir_list,com.google.android.documentsui:id/sub_menu_grid,com.google.android.documentsui:id/toolbar,com.google.android.documentsui:id/icon_thumb,com.google.android.documentsui:id/line2,com.google.android.documentsui:id/option_menu_search,com.google.android.documentsui:id/coordinator_layout,com.google.android.documentsui:id/sub_menu,com.google.android.documentsui:id/icon_check,android:id/title,com.google.android.documentsui:id/collapsing_toolbar,com.google.android.documentsui:id/header_container,com.google.android.documentsui:id/app_bar,com.google.android.documentsui:id/icon_mime,com.google.android.documentsui:id/apps_group,android:id/content,com.google.android.documentsui:id/drawer_edge,com.google.android.documentsui:id/apps_row\nBROWSE FILES IN OTHER APPS,Videos,Photos,May 17, 57.49 kB, PNG image,Audio,screen_2025-06-27_104423.png,Large files,10:44\u202fAM, 290 kB, PNG image,May 25, 125 kB, PNG image,Images,Documents,Drive,This week,Media picker,Recent files,Recent,Screenshot_20250525-195320.png,screen_2025-05-17_133330.png"
    },
    {
      "id": "ed1152153c6f5f83d480165213b802f0",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104458.png",
      "label": "FeatureLauncherActivity",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "ed1152153c6f5f83d480165213b802f0",
      "structure_str": "3aaae71728e45ee8e274460b4e0c58ff",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>ed1152153c6f5f83d480165213b802f0</td></tr>\n<tr><th>structure_str</th><td>3aaae71728e45ee8e274460b4e0c58ff</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\ned1152153c6f5f83d480165213b802f0\ncom.fsck.k9.debug:id/action_bar_root,android:id/content,android:id/navigationBarBackground,android:id/statusBarBackground\nBack,K-9 Mail,Next,Email address"
    },
    {
      "id": "f0a354f8a9281b6b6b2dc0f21939ec7b",
      "shape": "image",
      "image": "states\\screen_2025-06-27_104639.png",
      "label": "FeatureLauncherActivity",
      "package": "com.fsck.k9.debug",
      "activity": "app.k9mail.feature.launcher.FeatureLauncherActivity",
      "state_str": "f0a354f8a9281b6b6b2dc0f21939ec7b",
      "structure_str": "3aaae71728e45ee8e274460b4e0c58ff",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>app.k9mail.feature.launcher.FeatureLauncherActivity</td></tr>\n<tr><th>state_str</th><td>f0a354f8a9281b6b6b2dc0f21939ec7b</td></tr>\n<tr><th>structure_str</th><td>3aaae71728e45ee8e274460b4e0c58ff</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\napp.k9mail.feature.launcher.FeatureLauncherActivity\nf0a354f8a9281b6b6b2dc0f21939ec7b\ncom.fsck.k9.debug:id/action_bar_root,android:id/content,android:id/navigationBarBackground,android:id/statusBarBackground\nK-9 Mail,wireless headph,Back,Next,Email address"
    }
  ],
  "edges": [
    {
      "from": "c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "to": "61313c33ffc04b0a4ff93735152c7ddf",
      "id": "c3e8c9a9fec5d9eed0f40a9783f44f1c-->61313c33ffc04b0a4ff93735152c7ddf",
      "title": "<table class=\"table\">\n<tr><th>26</th><td>IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')</td></tr>\n</table>",
      "label": "26",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')",
          "event_id": 26,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "to": "8006523b45a79f3278661fcaeaa2ebe3",
      "id": "c3e8c9a9fec5d9eed0f40a9783f44f1c-->8006523b45a79f3278661fcaeaa2ebe3",
      "title": "<table class=\"table\">\n<tr><th>26</th><td>IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')</td></tr>\n</table>",
      "label": "26",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')",
          "event_id": 26,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "to": "e2484d8b2a16670784e6c8d3ebd0fb2f",
      "id": "c3e8c9a9fec5d9eed0f40a9783f44f1c-->e2484d8b2a16670784e6c8d3ebd0fb2f",
      "title": "<table class=\"table\">\n<tr><th>19</th><td>IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')</td></tr>\n</table>",
      "label": "19",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')",
          "event_id": 19,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "61313c33ffc04b0a4ff93735152c7ddf",
      "to": "c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "id": "61313c33ffc04b0a4ff93735152c7ddf-->c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "title": "<table class=\"table\">\n<tr><th>26</th><td>KeyEvent(state=61313c33ffc04b0a4ff93735152c7ddf, name=BACK)</td></tr>\n</table>",
      "label": "26",
      "events": [
        {
          "event_str": "KeyEvent(state=61313c33ffc04b0a4ff93735152c7ddf, name=BACK)",
          "event_id": 26,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "8006523b45a79f3278661fcaeaa2ebe3",
      "to": "302e338ddac3fa6d57da0480959a3405",
      "id": "8006523b45a79f3278661fcaeaa2ebe3-->302e338ddac3fa6d57da0480959a3405",
      "title": "<table class=\"table\">\n<tr><th>17</th><td>TouchEvent(state=8006523b45a79f3278661fcaeaa2ebe3, view=ed098265dd043ac0f69cf666f68144ce(FeatureLauncherActivity/TextView-Get starte))</td></tr>\n<tr><th>20</th><td>TouchEvent(state=8006523b45a79f3278661fcaeaa2ebe3, view=338c2b2e1e399e974ea948967a22dc02(FeatureLauncherActivity/Button-))</td></tr>\n<tr><th>26</th><td>TouchEvent(state=8006523b45a79f3278661fcaeaa2ebe3, view=e245bd5b29fa5ca0b87d8acca15f8100(FeatureLauncherActivity/View-))</td></tr>\n</table>",
      "label": "17, 20, 26",
      "events": [
        {
          "event_str": "TouchEvent(state=8006523b45a79f3278661fcaeaa2ebe3, view=ed098265dd043ac0f69cf666f68144ce(FeatureLauncherActivity/TextView-Get starte))",
          "event_id": 17,
          "event_type": "touch",
          "view_images": [
            "views/view_ed098265dd043ac0f69cf666f68144ce.png"
          ]
        },
        {
          "event_str": "TouchEvent(state=8006523b45a79f3278661fcaeaa2ebe3, view=338c2b2e1e399e974ea948967a22dc02(FeatureLauncherActivity/Button-))",
          "event_id": 20,
          "event_type": "touch",
          "view_images": [
            "views/view_338c2b2e1e399e974ea948967a22dc02.png"
          ]
        },
        {
          "event_str": "TouchEvent(state=8006523b45a79f3278661fcaeaa2ebe3, view=e245bd5b29fa5ca0b87d8acca15f8100(FeatureLauncherActivity/View-))",
          "event_id": 26,
          "event_type": "touch",
          "view_images": [
            "views/view_e245bd5b29fa5ca0b87d8acca15f8100.png"
          ]
        }
      ]
    },
    {
      "from": "8006523b45a79f3278661fcaeaa2ebe3",
      "to": "7134db92336404c40fcf2a8a0f182ffb",
      "id": "8006523b45a79f3278661fcaeaa2ebe3-->7134db92336404c40fcf2a8a0f182ffb",
      "title": "<table class=\"table\">\n<tr><th>22</th><td>TouchEvent(state=8006523b45a79f3278661fcaeaa2ebe3, view=c46a26225470ff92da87d9a1670a16e5(FeatureLauncherActivity/TextView-Import set))</td></tr>\n<tr><th>25</th><td>TouchEvent(state=8006523b45a79f3278661fcaeaa2ebe3, view=44cc06867b634ae67a4210bf3a6782c5(FeatureLauncherActivity/View-))</td></tr>\n</table>",
      "label": "22, 25",
      "events": [
        {
          "event_str": "TouchEvent(state=8006523b45a79f3278661fcaeaa2ebe3, view=c46a26225470ff92da87d9a1670a16e5(FeatureLauncherActivity/TextView-Import set))",
          "event_id": 22,
          "event_type": "touch",
          "view_images": [
            "views/view_c46a26225470ff92da87d9a1670a16e5.png"
          ]
        },
        {
          "event_str": "TouchEvent(state=8006523b45a79f3278661fcaeaa2ebe3, view=44cc06867b634ae67a4210bf3a6782c5(FeatureLauncherActivity/View-))",
          "event_id": 25,
          "event_type": "touch",
          "view_images": [
            "views/view_44cc06867b634ae67a4210bf3a6782c5.png"
          ]
        }
      ]
    },
    {
      "from": "8006523b45a79f3278661fcaeaa2ebe3",
      "to": "c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "id": "8006523b45a79f3278661fcaeaa2ebe3-->c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "title": "<table class=\"table\">\n<tr><th>24</th><td>KeyEvent(state=8006523b45a79f3278661fcaeaa2ebe3, name=BACK)</td></tr>\n</table>",
      "label": "24",
      "events": [
        {
          "event_str": "KeyEvent(state=8006523b45a79f3278661fcaeaa2ebe3, name=BACK)",
          "event_id": 24,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "302e338ddac3fa6d57da0480959a3405",
      "to": "a9e5ab939c46510919a403873570855c",
      "id": "302e338ddac3fa6d57da0480959a3405-->a9e5ab939c46510919a403873570855c",
      "title": "<table class=\"table\">\n<tr><th>4</th><td>SetTextEvent(state=302e338ddac3fa6d57da0480959a3405, view=cbd37719b2b0016c3843b1a3f59ebdf0(FeatureLauncherActivity/EditText-), text=john.doe@exampl)</td></tr>\n</table>",
      "label": "4",
      "events": [
        {
          "event_str": "SetTextEvent(state=302e338ddac3fa6d57da0480959a3405, view=cbd37719b2b0016c3843b1a3f59ebdf0(FeatureLauncherActivity/EditText-), text=john.doe@exampl)",
          "event_id": 4,
          "event_type": "set_text",
          "view_images": [
            "views/view_cbd37719b2b0016c3843b1a3f59ebdf0.png"
          ]
        }
      ]
    },
    {
      "from": "302e338ddac3fa6d57da0480959a3405",
      "to": "ed1152153c6f5f83d480165213b802f0",
      "id": "302e338ddac3fa6d57da0480959a3405-->ed1152153c6f5f83d480165213b802f0",
      "title": "<table class=\"table\">\n</table>",
      "label": "",
      "events": []
    },
    {
      "from": "302e338ddac3fa6d57da0480959a3405",
      "to": "8006523b45a79f3278661fcaeaa2ebe3",
      "id": "302e338ddac3fa6d57da0480959a3405-->8006523b45a79f3278661fcaeaa2ebe3",
      "title": "<table class=\"table\">\n<tr><th>21</th><td>KeyEvent(state=302e338ddac3fa6d57da0480959a3405, name=BACK)</td></tr>\n</table>",
      "label": "21",
      "events": [
        {
          "event_str": "KeyEvent(state=302e338ddac3fa6d57da0480959a3405, name=BACK)",
          "event_id": 21,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "302e338ddac3fa6d57da0480959a3405",
      "to": "f0a354f8a9281b6b6b2dc0f21939ec7b",
      "id": "302e338ddac3fa6d57da0480959a3405-->f0a354f8a9281b6b6b2dc0f21939ec7b",
      "title": "<table class=\"table\">\n<tr><th>26</th><td>SetTextEvent(state=302e338ddac3fa6d57da0480959a3405, view=cbd37719b2b0016c3843b1a3f59ebdf0(FeatureLauncherActivity/EditText-), text=wireless headph)</td></tr>\n</table>",
      "label": "26",
      "events": [
        {
          "event_str": "SetTextEvent(state=302e338ddac3fa6d57da0480959a3405, view=cbd37719b2b0016c3843b1a3f59ebdf0(FeatureLauncherActivity/EditText-), text=wireless headph)",
          "event_id": 26,
          "event_type": "set_text",
          "view_images": [
            "views/view_cbd37719b2b0016c3843b1a3f59ebdf0.png"
          ]
        }
      ]
    },
    {
      "from": "302e338ddac3fa6d57da0480959a3405",
      "to": "c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "id": "302e338ddac3fa6d57da0480959a3405-->c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "title": "<table class=\"table\">\n<tr><th>26</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "26",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 26,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "a9e5ab939c46510919a403873570855c",
      "to": "c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "id": "a9e5ab939c46510919a403873570855c-->c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "title": "<table class=\"table\">\n<tr><th>19</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "19",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 19,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "e2484d8b2a16670784e6c8d3ebd0fb2f",
      "to": "c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "id": "e2484d8b2a16670784e6c8d3ebd0fb2f-->c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "title": "<table class=\"table\">\n<tr><th>19</th><td>KeyEvent(state=e2484d8b2a16670784e6c8d3ebd0fb2f, name=BACK)</td></tr>\n</table>",
      "label": "19",
      "events": [
        {
          "event_str": "KeyEvent(state=e2484d8b2a16670784e6c8d3ebd0fb2f, name=BACK)",
          "event_id": 19,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "7134db92336404c40fcf2a8a0f182ffb",
      "to": "8c39b31ec7698d988a0395796fe63731",
      "id": "7134db92336404c40fcf2a8a0f182ffb-->8c39b31ec7698d988a0395796fe63731",
      "title": "<table class=\"table\">\n<tr><th>8</th><td>TouchEvent(state=7134db92336404c40fcf2a8a0f182ffb, view=c6e57d6be01f3b89a385123a0f7ee5ca(FeatureLauncherActivity/Button-Select fil))</td></tr>\n</table>",
      "label": "8",
      "events": [
        {
          "event_str": "TouchEvent(state=7134db92336404c40fcf2a8a0f182ffb, view=c6e57d6be01f3b89a385123a0f7ee5ca(FeatureLauncherActivity/Button-Select fil))",
          "event_id": 8,
          "event_type": "touch",
          "view_images": [
            "views/view_c6e57d6be01f3b89a385123a0f7ee5ca.png"
          ]
        }
      ]
    },
    {
      "from": "7134db92336404c40fcf2a8a0f182ffb",
      "to": "8006523b45a79f3278661fcaeaa2ebe3",
      "id": "7134db92336404c40fcf2a8a0f182ffb-->8006523b45a79f3278661fcaeaa2ebe3",
      "title": "<table class=\"table\">\n<tr><th>16</th><td>TouchEvent(state=7134db92336404c40fcf2a8a0f182ffb, view=3fb0ff50d81f3e47d2692cddea0fee69(FeatureLauncherActivity/View-))</td></tr>\n<tr><th>23</th><td>TouchEvent(state=7134db92336404c40fcf2a8a0f182ffb, view=ef500b81f8f414edf686e15b2500f668(FeatureLauncherActivity/View-))</td></tr>\n<tr><th>25</th><td>TouchEvent(state=7134db92336404c40fcf2a8a0f182ffb, view=338c2b2e1e399e974ea948967a22dc02(FeatureLauncherActivity/Button-))</td></tr>\n<tr><th>26</th><td>KeyEvent(state=7134db92336404c40fcf2a8a0f182ffb, name=BACK)</td></tr>\n</table>",
      "label": "16, 23, 25, 26",
      "events": [
        {
          "event_str": "TouchEvent(state=7134db92336404c40fcf2a8a0f182ffb, view=3fb0ff50d81f3e47d2692cddea0fee69(FeatureLauncherActivity/View-))",
          "event_id": 16,
          "event_type": "touch",
          "view_images": [
            "views/view_3fb0ff50d81f3e47d2692cddea0fee69.png"
          ]
        },
        {
          "event_str": "TouchEvent(state=7134db92336404c40fcf2a8a0f182ffb, view=ef500b81f8f414edf686e15b2500f668(FeatureLauncherActivity/View-))",
          "event_id": 23,
          "event_type": "touch",
          "view_images": [
            "views/view_ef500b81f8f414edf686e15b2500f668.png"
          ]
        },
        {
          "event_str": "TouchEvent(state=7134db92336404c40fcf2a8a0f182ffb, view=338c2b2e1e399e974ea948967a22dc02(FeatureLauncherActivity/Button-))",
          "event_id": 25,
          "event_type": "touch",
          "view_images": [
            "views/view_338c2b2e1e399e974ea948967a22dc02.png"
          ]
        },
        {
          "event_str": "KeyEvent(state=7134db92336404c40fcf2a8a0f182ffb, name=BACK)",
          "event_id": 26,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "8c39b31ec7698d988a0395796fe63731",
      "to": "c1c1fd93800024bf64f1cfee9d4f1fd5",
      "id": "8c39b31ec7698d988a0395796fe63731-->c1c1fd93800024bf64f1cfee9d4f1fd5",
      "title": "<table class=\"table\">\n<tr><th>9</th><td>TouchEvent(state=8c39b31ec7698d988a0395796fe63731, view=c8c35fda35b6396578fd4e22e4c25eaa(PickActivity/Button-Images))</td></tr>\n</table>",
      "label": "9",
      "events": [
        {
          "event_str": "TouchEvent(state=8c39b31ec7698d988a0395796fe63731, view=c8c35fda35b6396578fd4e22e4c25eaa(PickActivity/Button-Images))",
          "event_id": 9,
          "event_type": "touch",
          "view_images": [
            "views/view_c8c35fda35b6396578fd4e22e4c25eaa.png"
          ]
        }
      ]
    },
    {
      "from": "c1c1fd93800024bf64f1cfee9d4f1fd5",
      "to": "37c2eae9a2a375f34e0cc8aade3dd5de",
      "id": "c1c1fd93800024bf64f1cfee9d4f1fd5-->37c2eae9a2a375f34e0cc8aade3dd5de",
      "title": "<table class=\"table\">\n<tr><th>10</th><td>TouchEvent(state=c1c1fd93800024bf64f1cfee9d4f1fd5, view=c282835e65fc9a951d9db4bca9d66a81(PickActivity/Button-Images))</td></tr>\n</table>",
      "label": "10",
      "events": [
        {
          "event_str": "TouchEvent(state=c1c1fd93800024bf64f1cfee9d4f1fd5, view=c282835e65fc9a951d9db4bca9d66a81(PickActivity/Button-Images))",
          "event_id": 10,
          "event_type": "touch",
          "view_images": [
            "views/view_c282835e65fc9a951d9db4bca9d66a81.png"
          ]
        }
      ]
    },
    {
      "from": "37c2eae9a2a375f34e0cc8aade3dd5de",
      "to": "78539d55fb0ea160a0b1911203129baa",
      "id": "37c2eae9a2a375f34e0cc8aade3dd5de-->78539d55fb0ea160a0b1911203129baa",
      "title": "<table class=\"table\">\n<tr><th>11</th><td>TouchEvent(state=37c2eae9a2a375f34e0cc8aade3dd5de, view=c8c35fda35b6396578fd4e22e4c25eaa(PickActivity/Button-Images))</td></tr>\n</table>",
      "label": "11",
      "events": [
        {
          "event_str": "TouchEvent(state=37c2eae9a2a375f34e0cc8aade3dd5de, view=c8c35fda35b6396578fd4e22e4c25eaa(PickActivity/Button-Images))",
          "event_id": 11,
          "event_type": "touch",
          "view_images": [
            "views/view_c8c35fda35b6396578fd4e22e4c25eaa.png"
          ]
        }
      ]
    },
    {
      "from": "78539d55fb0ea160a0b1911203129baa",
      "to": "3db1de1be1439e12b72cda678753836d",
      "id": "78539d55fb0ea160a0b1911203129baa-->3db1de1be1439e12b72cda678753836d",
      "title": "<table class=\"table\">\n<tr><th>12</th><td>TouchEvent(state=78539d55fb0ea160a0b1911203129baa, view=c282835e65fc9a951d9db4bca9d66a81(PickActivity/Button-Images))</td></tr>\n</table>",
      "label": "12",
      "events": [
        {
          "event_str": "TouchEvent(state=78539d55fb0ea160a0b1911203129baa, view=c282835e65fc9a951d9db4bca9d66a81(PickActivity/Button-Images))",
          "event_id": 12,
          "event_type": "touch",
          "view_images": [
            "views/view_c282835e65fc9a951d9db4bca9d66a81.png"
          ]
        }
      ]
    },
    {
      "from": "78539d55fb0ea160a0b1911203129baa",
      "to": "0d6c9d4f1e1453576cf942bc95e00fa8",
      "id": "78539d55fb0ea160a0b1911203129baa-->0d6c9d4f1e1453576cf942bc95e00fa8",
      "title": "<table class=\"table\">\n<tr><th>14</th><td>KeyEvent(state=78539d55fb0ea160a0b1911203129baa, name=BACK)</td></tr>\n</table>",
      "label": "14",
      "events": [
        {
          "event_str": "KeyEvent(state=78539d55fb0ea160a0b1911203129baa, name=BACK)",
          "event_id": 14,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "3db1de1be1439e12b72cda678753836d",
      "to": "78539d55fb0ea160a0b1911203129baa",
      "id": "3db1de1be1439e12b72cda678753836d-->78539d55fb0ea160a0b1911203129baa",
      "title": "<table class=\"table\">\n<tr><th>13</th><td>TouchEvent(state=3db1de1be1439e12b72cda678753836d, view=c8c35fda35b6396578fd4e22e4c25eaa(PickActivity/Button-Images))</td></tr>\n</table>",
      "label": "13",
      "events": [
        {
          "event_str": "TouchEvent(state=3db1de1be1439e12b72cda678753836d, view=c8c35fda35b6396578fd4e22e4c25eaa(PickActivity/Button-Images))",
          "event_id": 13,
          "event_type": "touch",
          "view_images": [
            "views/view_c8c35fda35b6396578fd4e22e4c25eaa.png"
          ]
        }
      ]
    },
    {
      "from": "0d6c9d4f1e1453576cf942bc95e00fa8",
      "to": "7134db92336404c40fcf2a8a0f182ffb",
      "id": "0d6c9d4f1e1453576cf942bc95e00fa8-->7134db92336404c40fcf2a8a0f182ffb",
      "title": "<table class=\"table\">\n<tr><th>15</th><td>KeyEvent(state=0d6c9d4f1e1453576cf942bc95e00fa8, name=BACK)</td></tr>\n</table>",
      "label": "15",
      "events": [
        {
          "event_str": "KeyEvent(state=0d6c9d4f1e1453576cf942bc95e00fa8, name=BACK)",
          "event_id": 15,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "ed1152153c6f5f83d480165213b802f0",
      "to": "a9e5ab939c46510919a403873570855c",
      "id": "ed1152153c6f5f83d480165213b802f0-->a9e5ab939c46510919a403873570855c",
      "title": "<table class=\"table\">\n<tr><th>19</th><td>SetTextEvent(state=ed1152153c6f5f83d480165213b802f0, view=e986504f50027dfaa1c5c387ad826b09(FeatureLauncherActivity/EditText-Email addr), text=john.doe@exampl)</td></tr>\n</table>",
      "label": "19",
      "events": [
        {
          "event_str": "SetTextEvent(state=ed1152153c6f5f83d480165213b802f0, view=e986504f50027dfaa1c5c387ad826b09(FeatureLauncherActivity/EditText-Email addr), text=john.doe@exampl)",
          "event_id": 19,
          "event_type": "set_text",
          "view_images": [
            "views/view_e986504f50027dfaa1c5c387ad826b09.png"
          ]
        }
      ]
    },
    {
      "from": "f0a354f8a9281b6b6b2dc0f21939ec7b",
      "to": "c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "id": "f0a354f8a9281b6b6b2dc0f21939ec7b-->c3e8c9a9fec5d9eed0f40a9783f44f1c",
      "title": "<table class=\"table\">\n<tr><th>26</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "26",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 26,
          "event_type": "intent",
          "view_images": []
        }
      ]
    }
  ],
  "num_nodes": 15,
  "num_edges": 25,
  "num_effective_events": 26,
  "num_reached_activities": 2,
  "test_date": "2025-06-27 10:41:54",
  "time_spent": 334.789913,
  "num_transitions": 56,
  "device_serial": "emulator-5554",
  "device_model_number": "sdk_gphone64_x86_64",
  "device_sdk_version": 35,
  "app_sha256": "44fdd3523a2839bc2f11f729ef1f48defbfc76a2a74fd27a55121a265e85c457",
  "app_package": "com.fsck.k9.debug",
  "app_main_activity": "com.fsck.k9.activity.MessageList",
  "app_num_total_activities": 28
}