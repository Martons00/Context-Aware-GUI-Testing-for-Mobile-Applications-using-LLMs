var utg = 
{
  "nodes": [
    {
      "id": "f8bad0be0114b0036c596178f86e2416",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133038.png",
      "label": "NexusLauncherActivity\n<FIRST>",
      "package": "com.google.android.apps.nexuslauncher",
      "activity": ".NexusLauncherActivity",
      "state_str": "f8bad0be0114b0036c596178f86e2416",
      "structure_str": "345d86390034d21a3935ecda158a4915",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.apps.nexuslauncher</td></tr>\n<tr><th>activity</th><td>.NexusLauncherActivity</td></tr>\n<tr><th>state_str</th><td>f8bad0be0114b0036c596178f86e2416</td></tr>\n<tr><th>structure_str</th><td>345d86390034d21a3935ecda158a4915</td></tr>\n</table>",
      "content": "com.google.android.apps.nexuslauncher\n.NexusLauncherActivity\nf8bad0be0114b0036c596178f86e2416\ncom.google.android.apps.nexuslauncher:id/smartspace_subtitle_group,com.google.android.apps.nexuslauncher:id/search_container_hotseat,com.google.android.apps.nexuslauncher:id/launcher,com.google.android.apps.nexuslauncher:id/end_part,com.google.android.apps.nexuslauncher:id/workspace,com.google.android.apps.nexuslauncher:id/lens_icon,com.google.android.apps.nexuslauncher:id/bc_smartspace_view,com.google.android.apps.nexuslauncher:id/g_icon,com.google.android.apps.nexuslauncher:id/date,com.google.android.apps.nexuslauncher:id/mic_icon,android:id/content,com.google.android.apps.nexuslauncher:id/search_container_workspace,com.google.android.apps.nexuslauncher:id/base_template_card_with_date,com.google.android.apps.nexuslauncher:id/smartspace_card_pager,com.google.android.apps.nexuslauncher:id/scrim_view,com.google.android.apps.nexuslauncher:id/text_group,com.google.android.apps.nexuslauncher:id/overview_actions_view,com.google.android.apps.nexuslauncher:id/drag_layer,com.google.android.apps.nexuslauncher:id/page_indicator,com.google.android.apps.nexuslauncher:id/hotseat\nYouTube,Messages,Chrome,Gmail,Phone,DroidBot,Sun, Jun 29,Photos",
      "font": "14px Arial red"
    },
    {
      "id": "5583506110a5e4ad2c604c116d2c3143",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133043.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "5583506110a5e4ad2c604c116d2c3143",
      "structure_str": "5583506110a5e4ad2c604c116d2c3143",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>5583506110a5e4ad2c604c116d2c3143</td></tr>\n<tr><th>structure_str</th><td>5583506110a5e4ad2c604c116d2c3143</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\n5583506110a5e4ad2c604c116d2c3143\n\n"
    },
    {
      "id": "9fc8e85ca67fb9868fd9437146adebc9",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133052.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "9fc8e85ca67fb9868fd9437146adebc9",
      "structure_str": "d94f9547f616a86e10a5aae85fe61665",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>9fc8e85ca67fb9868fd9437146adebc9</td></tr>\n<tr><th>structure_str</th><td>d94f9547f616a86e10a5aae85fe61665</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\n9fc8e85ca67fb9868fd9437146adebc9\nit.feio.android.omninotes.alpha:id/fab,it.feio.android.omninotes.alpha:id/alarmIcon,it.feio.android.omninotes.alpha:id/action_bar_root,it.feio.android.omninotes.alpha:id/fab_note,it.feio.android.omninotes.alpha:id/snackbar_placeholder,it.feio.android.omninotes.alpha:id/category_marker,it.feio.android.omninotes.alpha:id/toolbar,it.feio.android.omninotes.alpha:id/note_title,it.feio.android.omninotes.alpha:id/fab_expand_menu_button,it.feio.android.omninotes.alpha:id/menu_sort,it.feio.android.omninotes.alpha:id/note_date,it.feio.android.omninotes.alpha:id/fab_checklist,it.feio.android.omninotes.alpha:id/card_layout,it.feio.android.omninotes.alpha:id/menu_search,it.feio.android.omninotes.alpha:id/list_root,it.feio.android.omninotes.alpha:id/fab_camera,it.feio.android.omninotes.alpha:id/root,android:id/content,it.feio.android.omninotes.alpha:id/drawer_layout,android:id/navigationBarBackground,it.feio.android.omninotes.alpha:id/crouton_handle,it.feio.android.omninotes.alpha:id/list,it.feio.android.omninotes.alpha:id/attachmentThumbnail,it.feio.android.omninotes.alpha:id/expanded_image,it.feio.android.omninotes.alpha:id/note_content,it.feio.android.omninotes.alpha:id/fragment_container,android:id/statusBarBackground\nNotes,Checklist,a Passbook is shared with you,Updated: 2 days ago,yu,Photo,Text note,Updated: 4 days ago,\u25fb New item ### U\n\u25fb ### U ### Exam\u2026,Hello World,Updated: moments ago"
    },
    {
      "id": "eec05832c2715a77d61996970415374a",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133137.png",
      "label": "NexusLauncherActivity",
      "package": "com.google.android.apps.nexuslauncher",
      "activity": ".NexusLauncherActivity",
      "state_str": "eec05832c2715a77d61996970415374a",
      "structure_str": "69b5bc5de8c58038e74a74637a0b7c53",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.apps.nexuslauncher</td></tr>\n<tr><th>activity</th><td>.NexusLauncherActivity</td></tr>\n<tr><th>state_str</th><td>eec05832c2715a77d61996970415374a</td></tr>\n<tr><th>structure_str</th><td>69b5bc5de8c58038e74a74637a0b7c53</td></tr>\n</table>",
      "content": "com.google.android.apps.nexuslauncher\n.NexusLauncherActivity\neec05832c2715a77d61996970415374a\nit.feio.android.omninotes.alpha:id/fab,it.feio.android.omninotes.alpha:id/alarmIcon,it.feio.android.omninotes.alpha:id/action_bar_root,it.feio.android.omninotes.alpha:id/fab_note,it.feio.android.omninotes.alpha:id/snackbar_placeholder,it.feio.android.omninotes.alpha:id/category_marker,it.feio.android.omninotes.alpha:id/toolbar,it.feio.android.omninotes.alpha:id/note_title,it.feio.android.omninotes.alpha:id/fab_expand_menu_button,it.feio.android.omninotes.alpha:id/menu_sort,it.feio.android.omninotes.alpha:id/note_date,it.feio.android.omninotes.alpha:id/fab_checklist,it.feio.android.omninotes.alpha:id/card_layout,it.feio.android.omninotes.alpha:id/menu_search,it.feio.android.omninotes.alpha:id/list_root,it.feio.android.omninotes.alpha:id/fab_camera,it.feio.android.omninotes.alpha:id/root,android:id/content,it.feio.android.omninotes.alpha:id/drawer_layout,android:id/navigationBarBackground,it.feio.android.omninotes.alpha:id/crouton_handle,it.feio.android.omninotes.alpha:id/list,it.feio.android.omninotes.alpha:id/attachmentThumbnail,it.feio.android.omninotes.alpha:id/expanded_image,it.feio.android.omninotes.alpha:id/note_content,it.feio.android.omninotes.alpha:id/fragment_container,android:id/statusBarBackground\nNotes,Checklist,a Passbook is shared with you,Updated: 2 days ago,yu,Photo,Text note,Updated: 4 days ago,\u25fb New item ### U\n\u25fb ### U ### Exam\u2026,Hello World,Updated: moments ago"
    },
    {
      "id": "b5202c53bed5eceaa3cad5f0e20d6c18",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133157.png",
      "label": "NexusLauncherActivity",
      "package": "com.google.android.apps.nexuslauncher",
      "activity": ".NexusLauncherActivity",
      "state_str": "b5202c53bed5eceaa3cad5f0e20d6c18",
      "structure_str": "345d86390034d21a3935ecda158a4915",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.apps.nexuslauncher</td></tr>\n<tr><th>activity</th><td>.NexusLauncherActivity</td></tr>\n<tr><th>state_str</th><td>b5202c53bed5eceaa3cad5f0e20d6c18</td></tr>\n<tr><th>structure_str</th><td>345d86390034d21a3935ecda158a4915</td></tr>\n</table>",
      "content": "com.google.android.apps.nexuslauncher\n.NexusLauncherActivity\nb5202c53bed5eceaa3cad5f0e20d6c18\ncom.google.android.apps.nexuslauncher:id/smartspace_subtitle_group,com.google.android.apps.nexuslauncher:id/search_container_hotseat,com.google.android.apps.nexuslauncher:id/launcher,com.google.android.apps.nexuslauncher:id/end_part,com.google.android.apps.nexuslauncher:id/workspace,com.google.android.apps.nexuslauncher:id/lens_icon,com.google.android.apps.nexuslauncher:id/bc_smartspace_view,com.google.android.apps.nexuslauncher:id/g_icon,com.google.android.apps.nexuslauncher:id/date,com.google.android.apps.nexuslauncher:id/mic_icon,android:id/content,com.google.android.apps.nexuslauncher:id/search_container_workspace,com.google.android.apps.nexuslauncher:id/base_template_card_with_date,com.google.android.apps.nexuslauncher:id/smartspace_card_pager,com.google.android.apps.nexuslauncher:id/scrim_view,com.google.android.apps.nexuslauncher:id/text_group,com.google.android.apps.nexuslauncher:id/overview_actions_view,com.google.android.apps.nexuslauncher:id/drag_layer,com.google.android.apps.nexuslauncher:id/page_indicator,com.google.android.apps.nexuslauncher:id/hotseat\nYouTube,Messages,Chrome,Gmail,Omni Notes Alpha,Phone,Sun, Jun 29,Photos"
    },
    {
      "id": "8e1386b3328cc645284ed1ea6d9f0e23",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133215.png",
      "label": "AllInOneCalendarActivity",
      "package": "com.google.android.calendar",
      "activity": ".AllInOneCalendarActivity",
      "state_str": "8e1386b3328cc645284ed1ea6d9f0e23",
      "structure_str": "375df1b55e7b6b36ad7b88e6181b41f6",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.calendar</td></tr>\n<tr><th>activity</th><td>.AllInOneCalendarActivity</td></tr>\n<tr><th>state_str</th><td>8e1386b3328cc645284ed1ea6d9f0e23</td></tr>\n<tr><th>structure_str</th><td>375df1b55e7b6b36ad7b88e6181b41f6</td></tr>\n</table>",
      "content": "com.google.android.calendar\n.AllInOneCalendarActivity\n8e1386b3328cc645284ed1ea6d9f0e23\ncom.google.android.calendar:id/timely_date_picker_container,com.google.android.calendar:id/action_search,com.google.android.calendar:id/action_today,com.google.android.calendar:id/drag_up_view,com.google.android.calendar:id/hats_next_container,com.google.android.calendar:id/selected_account_disc,com.google.android.calendar:id/drawer_layout,com.google.android.calendar:id/date_picker_content,com.google.android.calendar:id/main_content_without_overlays,com.google.android.calendar:id/banner_container,com.google.android.calendar:id/date_picker_button,com.google.android.calendar:id/date_picker_text_view,com.google.android.calendar:id/alternate_timeline_fragment_container,com.google.android.calendar:id/ring_wrapper,com.google.android.calendar:id/og_selected_account_disc_apd,android:id/content,com.google.android.calendar:id/og_apd_internal_image_view,com.google.android.calendar:id/header,com.google.android.calendar:id/bottom_sheet_frame,com.google.android.calendar:id/custom_action_bar,com.google.android.calendar:id/alternate_timeline_holder,com.google.android.calendar:id/main_content_view,com.google.android.calendar:id/date_picker_arrow,com.google.android.calendar:id/floating_action_button,com.google.android.calendar:id/toolbar,com.google.android.calendar:id/main_pane,com.google.android.calendar:id/coordinator_layout,com.google.android.calendar:id/action_bar_root\nJune"
    },
    {
      "id": "6305b551c47d4d4bd6f96025838aa4ee",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133224.png",
      "label": "NexusLauncherActivity",
      "package": "com.google.android.apps.nexuslauncher",
      "activity": ".NexusLauncherActivity",
      "state_str": "6305b551c47d4d4bd6f96025838aa4ee",
      "structure_str": "07cfd6a0fe1dda0bc9e39909b50948f3",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.apps.nexuslauncher</td></tr>\n<tr><th>activity</th><td>.NexusLauncherActivity</td></tr>\n<tr><th>state_str</th><td>6305b551c47d4d4bd6f96025838aa4ee</td></tr>\n<tr><th>structure_str</th><td>07cfd6a0fe1dda0bc9e39909b50948f3</td></tr>\n</table>",
      "content": "com.google.android.apps.nexuslauncher\n.NexusLauncherActivity\n6305b551c47d4d4bd6f96025838aa4ee\ncom.google.android.calendar:id/timely_date_picker_container,com.google.android.calendar:id/action_search,com.google.android.calendar:id/action_today,com.google.android.calendar:id/drag_up_view,com.google.android.calendar:id/hats_next_container,com.google.android.calendar:id/selected_account_disc,com.google.android.calendar:id/drawer_layout,com.google.android.calendar:id/date_picker_content,com.google.android.calendar:id/main_content_without_overlays,com.google.android.calendar:id/banner_container,com.google.android.calendar:id/date_picker_button,com.google.android.calendar:id/date_picker_text_view,com.google.android.calendar:id/alternate_timeline_fragment_container,com.google.android.calendar:id/ring_wrapper,com.google.android.calendar:id/og_selected_account_disc_apd,android:id/content,com.google.android.calendar:id/og_apd_internal_image_view,com.google.android.calendar:id/header,com.google.android.calendar:id/bottom_sheet_frame,com.google.android.calendar:id/custom_action_bar,com.google.android.calendar:id/alternate_timeline_holder,com.google.android.calendar:id/main_content_view,com.google.android.calendar:id/date_picker_arrow,com.google.android.calendar:id/floating_action_button,com.google.android.calendar:id/toolbar,com.google.android.calendar:id/main_pane,com.google.android.calendar:id/coordinator_layout,com.google.android.calendar:id/action_bar_root\nJune"
    },
    {
      "id": "d9a885e764af09879e0942de2953fb18",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133226.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "d9a885e764af09879e0942de2953fb18",
      "structure_str": "7a3672044495a555fd6095c18e91ea8e",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>d9a885e764af09879e0942de2953fb18</td></tr>\n<tr><th>structure_str</th><td>7a3672044495a555fd6095c18e91ea8e</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\nd9a885e764af09879e0942de2953fb18\ncom.google.android.apps.nexuslauncher:id/snapshot,com.google.android.apps.nexuslauncher:id/clear_all,com.google.android.apps.nexuslauncher:id/icon,com.google.android.apps.nexuslauncher:id/overview_actions_view,android:id/content,com.google.android.apps.nexuslauncher:id/drag_layer,com.google.android.apps.nexuslauncher:id/overview_panel,com.google.android.apps.nexuslauncher:id/show_windows,com.google.android.apps.nexuslauncher:id/task,com.google.android.apps.nexuslauncher:id/launcher,com.google.android.apps.nexuslauncher:id/scrim_view\nClear all"
    },
    {
      "id": "8bc53ea15785ec984226ffdd4a7af9e3",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133233.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "8bc53ea15785ec984226ffdd4a7af9e3",
      "structure_str": "3fb84c0452ec6bdd5be1a6daec5decd1",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>8bc53ea15785ec984226ffdd4a7af9e3</td></tr>\n<tr><th>structure_str</th><td>3fb84c0452ec6bdd5be1a6daec5decd1</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\n8bc53ea15785ec984226ffdd4a7af9e3\nit.feio.android.omninotes.alpha:id/alarmIcon,it.feio.android.omninotes.alpha:id/action_bar_root,it.feio.android.omninotes.alpha:id/action_mode_close_button,it.feio.android.omninotes.alpha:id/action_bar_title,it.feio.android.omninotes.alpha:id/snackbar_placeholder,it.feio.android.omninotes.alpha:id/category_marker,it.feio.android.omninotes.alpha:id/toolbar,it.feio.android.omninotes.alpha:id/menu_share,it.feio.android.omninotes.alpha:id/note_title,it.feio.android.omninotes.alpha:id/menu_tags,it.feio.android.omninotes.alpha:id/menu_sort,it.feio.android.omninotes.alpha:id/note_date,it.feio.android.omninotes.alpha:id/card_layout,it.feio.android.omninotes.alpha:id/menu_search,it.feio.android.omninotes.alpha:id/list_root,it.feio.android.omninotes.alpha:id/menu_category,it.feio.android.omninotes.alpha:id/root,android:id/content,it.feio.android.omninotes.alpha:id/drawer_layout,it.feio.android.omninotes.alpha:id/action_mode_bar,android:id/navigationBarBackground,it.feio.android.omninotes.alpha:id/crouton_handle,it.feio.android.omninotes.alpha:id/list,it.feio.android.omninotes.alpha:id/attachmentThumbnail,it.feio.android.omninotes.alpha:id/expanded_image,it.feio.android.omninotes.alpha:id/note_content,it.feio.android.omninotes.alpha:id/fragment_container,android:id/statusBarBackground\nNotes,a Passbook is shared with you,1,Updated: 2 days ago,yu,Updated: 4 days ago,\u25fb New item ### U\n\u25fb ### U ### Exam\u2026,Hello World,Updated: moments ago"
    },
    {
      "id": "29548b908236774381d6e7e5679070cd",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133410.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "29548b908236774381d6e7e5679070cd",
      "structure_str": "e6201a3c1c97fb2f4e3fc395fa1ff926",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>29548b908236774381d6e7e5679070cd</td></tr>\n<tr><th>structure_str</th><td>e6201a3c1c97fb2f4e3fc395fa1ff926</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\n29548b908236774381d6e7e5679070cd\nit.feio.android.omninotes.alpha:id/fab,it.feio.android.omninotes.alpha:id/alarmIcon,it.feio.android.omninotes.alpha:id/action_bar_root,it.feio.android.omninotes.alpha:id/fab_note,it.feio.android.omninotes.alpha:id/search_bar,it.feio.android.omninotes.alpha:id/snackbar_placeholder,it.feio.android.omninotes.alpha:id/category_marker,it.feio.android.omninotes.alpha:id/search_src_text,it.feio.android.omninotes.alpha:id/toolbar,it.feio.android.omninotes.alpha:id/note_title,it.feio.android.omninotes.alpha:id/fab_expand_menu_button,it.feio.android.omninotes.alpha:id/menu_tags,it.feio.android.omninotes.alpha:id/note_date,it.feio.android.omninotes.alpha:id/fab_checklist,it.feio.android.omninotes.alpha:id/card_layout,it.feio.android.omninotes.alpha:id/menu_search,it.feio.android.omninotes.alpha:id/list_root,it.feio.android.omninotes.alpha:id/search_plate,it.feio.android.omninotes.alpha:id/fab_camera,it.feio.android.omninotes.alpha:id/root,android:id/content,it.feio.android.omninotes.alpha:id/drawer_layout,android:id/navigationBarBackground,it.feio.android.omninotes.alpha:id/submit_area,it.feio.android.omninotes.alpha:id/crouton_handle,it.feio.android.omninotes.alpha:id/menu_uncomplete_checklists,it.feio.android.omninotes.alpha:id/list,it.feio.android.omninotes.alpha:id/attachmentThumbnail,it.feio.android.omninotes.alpha:id/expanded_image,it.feio.android.omninotes.alpha:id/note_content,it.feio.android.omninotes.alpha:id/fragment_container,it.feio.android.omninotes.alpha:id/search_edit_frame,android:id/statusBarBackground,it.feio.android.omninotes.alpha:id/search_voice_btn\nSearch in notes,Checklist,a Passbook is shared with you,Updated: 2 days ago,yu,Photo,Text note,Updated: 4 days ago,\u25fb New item ### U\n\u25fb ### U ### Exam\u2026,Hello World,Updated: moments ago"
    },
    {
      "id": "2c60f52af19298a64804f0e0e5a44b29",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133423.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "2c60f52af19298a64804f0e0e5a44b29",
      "structure_str": "d5d2b368fdd079741aa480e929e25ed4",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>2c60f52af19298a64804f0e0e5a44b29</td></tr>\n<tr><th>structure_str</th><td>d5d2b368fdd079741aa480e929e25ed4</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\n2c60f52af19298a64804f0e0e5a44b29\nit.feio.android.omninotes.alpha:id/fab,it.feio.android.omninotes.alpha:id/alarmIcon,it.feio.android.omninotes.alpha:id/action_bar_root,it.feio.android.omninotes.alpha:id/fab_note,it.feio.android.omninotes.alpha:id/search_bar,it.feio.android.omninotes.alpha:id/snackbar_placeholder,it.feio.android.omninotes.alpha:id/category_marker,it.feio.android.omninotes.alpha:id/search_src_text,it.feio.android.omninotes.alpha:id/toolbar,it.feio.android.omninotes.alpha:id/note_title,it.feio.android.omninotes.alpha:id/fab_expand_menu_button,it.feio.android.omninotes.alpha:id/note_date,it.feio.android.omninotes.alpha:id/fab_checklist,it.feio.android.omninotes.alpha:id/card_layout,it.feio.android.omninotes.alpha:id/menu_search,it.feio.android.omninotes.alpha:id/list_root,it.feio.android.omninotes.alpha:id/search_plate,it.feio.android.omninotes.alpha:id/fab_camera,it.feio.android.omninotes.alpha:id/root,android:id/content,it.feio.android.omninotes.alpha:id/drawer_layout,android:id/navigationBarBackground,it.feio.android.omninotes.alpha:id/submit_area,it.feio.android.omninotes.alpha:id/crouton_handle,it.feio.android.omninotes.alpha:id/list,it.feio.android.omninotes.alpha:id/attachmentThumbnail,it.feio.android.omninotes.alpha:id/expanded_image,it.feio.android.omninotes.alpha:id/note_content,it.feio.android.omninotes.alpha:id/fragment_container,it.feio.android.omninotes.alpha:id/search_edit_frame,android:id/statusBarBackground,it.feio.android.omninotes.alpha:id/search_voice_btn\nSearch in notes,Checklist,a Passbook is shared with you,Updated: 2 days ago,yu,Photo,Text note,Updated: 4 days ago,\u25fb New item ### U\n\u25fb ### U ### Exam\u2026,Hello World,Updated: moments ago"
    },
    {
      "id": "ffed3d236e4ca8ae2c748a993a02a773",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133456.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "ffed3d236e4ca8ae2c748a993a02a773",
      "structure_str": "738632c0736b73fd295c13de1e314dd1",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>ffed3d236e4ca8ae2c748a993a02a773</td></tr>\n<tr><th>structure_str</th><td>738632c0736b73fd295c13de1e314dd1</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\nffed3d236e4ca8ae2c748a993a02a773\nit.feio.android.omninotes.alpha:id/content,it.feio.android.omninotes.alpha:id/radio,it.feio.android.omninotes.alpha:id/title\nTitle,Last modification date,Reminder date,Creation date"
    },
    {
      "id": "4d0d6757addff151262908d09583c285",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133502.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "4d0d6757addff151262908d09583c285",
      "structure_str": "d94f9547f616a86e10a5aae85fe61665",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>4d0d6757addff151262908d09583c285</td></tr>\n<tr><th>structure_str</th><td>d94f9547f616a86e10a5aae85fe61665</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\n4d0d6757addff151262908d09583c285\nit.feio.android.omninotes.alpha:id/fab,it.feio.android.omninotes.alpha:id/alarmIcon,it.feio.android.omninotes.alpha:id/action_bar_root,it.feio.android.omninotes.alpha:id/fab_note,it.feio.android.omninotes.alpha:id/snackbar_placeholder,it.feio.android.omninotes.alpha:id/category_marker,it.feio.android.omninotes.alpha:id/toolbar,it.feio.android.omninotes.alpha:id/note_title,it.feio.android.omninotes.alpha:id/fab_expand_menu_button,it.feio.android.omninotes.alpha:id/menu_sort,it.feio.android.omninotes.alpha:id/note_date,it.feio.android.omninotes.alpha:id/fab_checklist,it.feio.android.omninotes.alpha:id/card_layout,it.feio.android.omninotes.alpha:id/menu_search,it.feio.android.omninotes.alpha:id/list_root,it.feio.android.omninotes.alpha:id/fab_camera,it.feio.android.omninotes.alpha:id/root,android:id/content,it.feio.android.omninotes.alpha:id/drawer_layout,android:id/navigationBarBackground,it.feio.android.omninotes.alpha:id/crouton_handle,it.feio.android.omninotes.alpha:id/list,it.feio.android.omninotes.alpha:id/attachmentThumbnail,it.feio.android.omninotes.alpha:id/expanded_image,it.feio.android.omninotes.alpha:id/note_content,it.feio.android.omninotes.alpha:id/fragment_container,android:id/statusBarBackground\nNotes,Checklist,\u25fb Hello World\n\u25fb Hello World,a Passbook is shared with you,Updated: 2 days ago,Photo,Text note,Updated: 4 days ago,\u25fb New item ### U\n\u25fb ### U ### Exam\u2026,Hello World,Updated: moments ago"
    },
    {
      "id": "b0ff97955762fa20dcc73c4f8035abc6",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133508.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "b0ff97955762fa20dcc73c4f8035abc6",
      "structure_str": "e6201a3c1c97fb2f4e3fc395fa1ff926",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>b0ff97955762fa20dcc73c4f8035abc6</td></tr>\n<tr><th>structure_str</th><td>e6201a3c1c97fb2f4e3fc395fa1ff926</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\nb0ff97955762fa20dcc73c4f8035abc6\nit.feio.android.omninotes.alpha:id/fab,it.feio.android.omninotes.alpha:id/alarmIcon,it.feio.android.omninotes.alpha:id/action_bar_root,it.feio.android.omninotes.alpha:id/fab_note,it.feio.android.omninotes.alpha:id/search_bar,it.feio.android.omninotes.alpha:id/snackbar_placeholder,it.feio.android.omninotes.alpha:id/category_marker,it.feio.android.omninotes.alpha:id/search_src_text,it.feio.android.omninotes.alpha:id/toolbar,it.feio.android.omninotes.alpha:id/note_title,it.feio.android.omninotes.alpha:id/fab_expand_menu_button,it.feio.android.omninotes.alpha:id/menu_tags,it.feio.android.omninotes.alpha:id/note_date,it.feio.android.omninotes.alpha:id/fab_checklist,it.feio.android.omninotes.alpha:id/card_layout,it.feio.android.omninotes.alpha:id/menu_search,it.feio.android.omninotes.alpha:id/list_root,it.feio.android.omninotes.alpha:id/search_plate,it.feio.android.omninotes.alpha:id/fab_camera,it.feio.android.omninotes.alpha:id/root,android:id/content,it.feio.android.omninotes.alpha:id/drawer_layout,android:id/navigationBarBackground,it.feio.android.omninotes.alpha:id/submit_area,it.feio.android.omninotes.alpha:id/crouton_handle,it.feio.android.omninotes.alpha:id/menu_uncomplete_checklists,it.feio.android.omninotes.alpha:id/list,it.feio.android.omninotes.alpha:id/attachmentThumbnail,it.feio.android.omninotes.alpha:id/expanded_image,it.feio.android.omninotes.alpha:id/note_content,it.feio.android.omninotes.alpha:id/fragment_container,it.feio.android.omninotes.alpha:id/search_edit_frame,android:id/statusBarBackground,it.feio.android.omninotes.alpha:id/search_voice_btn\nSearch in notes,Checklist,\u25fb Hello World\n\u25fb Hello World,a Passbook is shared with you,Updated: 2 days ago,Photo,Text note,Updated: 4 days ago,\u25fb New item ### U\n\u25fb ### U ### Exam\u2026,Hello World,Updated: moments ago"
    },
    {
      "id": "85d101414477d7a3dfb7f6bf7c63cde2",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133521.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "85d101414477d7a3dfb7f6bf7c63cde2",
      "structure_str": "d5d2b368fdd079741aa480e929e25ed4",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>85d101414477d7a3dfb7f6bf7c63cde2</td></tr>\n<tr><th>structure_str</th><td>d5d2b368fdd079741aa480e929e25ed4</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\n85d101414477d7a3dfb7f6bf7c63cde2\nit.feio.android.omninotes.alpha:id/fab,it.feio.android.omninotes.alpha:id/alarmIcon,it.feio.android.omninotes.alpha:id/action_bar_root,it.feio.android.omninotes.alpha:id/fab_note,it.feio.android.omninotes.alpha:id/search_bar,it.feio.android.omninotes.alpha:id/snackbar_placeholder,it.feio.android.omninotes.alpha:id/category_marker,it.feio.android.omninotes.alpha:id/search_src_text,it.feio.android.omninotes.alpha:id/toolbar,it.feio.android.omninotes.alpha:id/note_title,it.feio.android.omninotes.alpha:id/fab_expand_menu_button,it.feio.android.omninotes.alpha:id/note_date,it.feio.android.omninotes.alpha:id/fab_checklist,it.feio.android.omninotes.alpha:id/card_layout,it.feio.android.omninotes.alpha:id/menu_search,it.feio.android.omninotes.alpha:id/list_root,it.feio.android.omninotes.alpha:id/search_plate,it.feio.android.omninotes.alpha:id/fab_camera,it.feio.android.omninotes.alpha:id/root,android:id/content,it.feio.android.omninotes.alpha:id/drawer_layout,android:id/navigationBarBackground,it.feio.android.omninotes.alpha:id/submit_area,it.feio.android.omninotes.alpha:id/crouton_handle,it.feio.android.omninotes.alpha:id/list,it.feio.android.omninotes.alpha:id/attachmentThumbnail,it.feio.android.omninotes.alpha:id/expanded_image,it.feio.android.omninotes.alpha:id/note_content,it.feio.android.omninotes.alpha:id/fragment_container,it.feio.android.omninotes.alpha:id/search_edit_frame,android:id/statusBarBackground,it.feio.android.omninotes.alpha:id/search_voice_btn\nSearch in notes,Checklist,\u25fb Hello World\n\u25fb Hello World,a Passbook is shared with you,Updated: 2 days ago,Photo,Text note,Updated: 4 days ago,\u25fb New item ### U\n\u25fb ### U ### Exam\u2026,Hello World,Updated: moments ago"
    },
    {
      "id": "45d283259ee78f338cdf50b6858d1eb3",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133535.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "45d283259ee78f338cdf50b6858d1eb3",
      "structure_str": "d94f9547f616a86e10a5aae85fe61665",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>45d283259ee78f338cdf50b6858d1eb3</td></tr>\n<tr><th>structure_str</th><td>d94f9547f616a86e10a5aae85fe61665</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\n45d283259ee78f338cdf50b6858d1eb3\nit.feio.android.omninotes.alpha:id/fab,it.feio.android.omninotes.alpha:id/alarmIcon,it.feio.android.omninotes.alpha:id/action_bar_root,it.feio.android.omninotes.alpha:id/fab_note,it.feio.android.omninotes.alpha:id/snackbar_placeholder,it.feio.android.omninotes.alpha:id/category_marker,it.feio.android.omninotes.alpha:id/toolbar,it.feio.android.omninotes.alpha:id/note_title,it.feio.android.omninotes.alpha:id/fab_expand_menu_button,it.feio.android.omninotes.alpha:id/menu_sort,it.feio.android.omninotes.alpha:id/note_date,it.feio.android.omninotes.alpha:id/fab_checklist,it.feio.android.omninotes.alpha:id/card_layout,it.feio.android.omninotes.alpha:id/menu_search,it.feio.android.omninotes.alpha:id/list_root,it.feio.android.omninotes.alpha:id/fab_camera,it.feio.android.omninotes.alpha:id/root,android:id/content,it.feio.android.omninotes.alpha:id/drawer_layout,android:id/navigationBarBackground,it.feio.android.omninotes.alpha:id/crouton_handle,it.feio.android.omninotes.alpha:id/list,it.feio.android.omninotes.alpha:id/attachmentThumbnail,it.feio.android.omninotes.alpha:id/expanded_image,it.feio.android.omninotes.alpha:id/note_content,it.feio.android.omninotes.alpha:id/fragment_container,android:id/statusBarBackground\nNotes,Checklist,\u25fb Hello World\n\u25fb Hello World,a Passbook is shared with you,Updated: 2 days ago,Photo,Text note,Updated: 4 days ago,\u25fb New item ### U\n\u25fb ### U ### Exam\u2026,Hello World,Updated: 5 minutes ago"
    },
    {
      "id": "fdfaa0a2b0afb3bdba3e6b632186be22",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133553.png",
      "label": "MainActivity",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "fdfaa0a2b0afb3bdba3e6b632186be22",
      "structure_str": "d94f9547f616a86e10a5aae85fe61665",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>fdfaa0a2b0afb3bdba3e6b632186be22</td></tr>\n<tr><th>structure_str</th><td>d94f9547f616a86e10a5aae85fe61665</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\nfdfaa0a2b0afb3bdba3e6b632186be22\nit.feio.android.omninotes.alpha:id/fab,it.feio.android.omninotes.alpha:id/alarmIcon,it.feio.android.omninotes.alpha:id/action_bar_root,it.feio.android.omninotes.alpha:id/fab_note,it.feio.android.omninotes.alpha:id/snackbar_placeholder,it.feio.android.omninotes.alpha:id/category_marker,it.feio.android.omninotes.alpha:id/toolbar,it.feio.android.omninotes.alpha:id/note_title,it.feio.android.omninotes.alpha:id/fab_expand_menu_button,it.feio.android.omninotes.alpha:id/menu_sort,it.feio.android.omninotes.alpha:id/note_date,it.feio.android.omninotes.alpha:id/fab_checklist,it.feio.android.omninotes.alpha:id/card_layout,it.feio.android.omninotes.alpha:id/menu_search,it.feio.android.omninotes.alpha:id/list_root,it.feio.android.omninotes.alpha:id/fab_camera,it.feio.android.omninotes.alpha:id/root,android:id/content,it.feio.android.omninotes.alpha:id/drawer_layout,android:id/navigationBarBackground,it.feio.android.omninotes.alpha:id/crouton_handle,it.feio.android.omninotes.alpha:id/list,it.feio.android.omninotes.alpha:id/attachmentThumbnail,it.feio.android.omninotes.alpha:id/expanded_image,it.feio.android.omninotes.alpha:id/note_content,it.feio.android.omninotes.alpha:id/fragment_container,android:id/statusBarBackground\nNotes,Checklist,\u25fb Hello World\n\u25fb Hello World,a Passbook is shared with you,Updated: 2 days ago,Photo,Text note,Updated: 4 days ago,Updated: 6 minutes ago,\u25fb New item ### U\n\u25fb ### U ### Exam\u2026,Hello World"
    },
    {
      "id": "15c409e69f4b5171c39482b00626ddc9",
      "shape": "image",
      "image": "states\\screen_2025-06-29_133601.png",
      "label": "MainActivity\n<LAST>",
      "package": "it.feio.android.omninotes.alpha",
      "activity": "it.feio.android.omninotes.MainActivity",
      "state_str": "15c409e69f4b5171c39482b00626ddc9",
      "structure_str": "e6201a3c1c97fb2f4e3fc395fa1ff926",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>it.feio.android.omninotes.alpha</td></tr>\n<tr><th>activity</th><td>it.feio.android.omninotes.MainActivity</td></tr>\n<tr><th>state_str</th><td>15c409e69f4b5171c39482b00626ddc9</td></tr>\n<tr><th>structure_str</th><td>e6201a3c1c97fb2f4e3fc395fa1ff926</td></tr>\n</table>",
      "content": "it.feio.android.omninotes.alpha\nit.feio.android.omninotes.MainActivity\n15c409e69f4b5171c39482b00626ddc9\nit.feio.android.omninotes.alpha:id/fab,it.feio.android.omninotes.alpha:id/alarmIcon,it.feio.android.omninotes.alpha:id/action_bar_root,it.feio.android.omninotes.alpha:id/fab_note,it.feio.android.omninotes.alpha:id/search_bar,it.feio.android.omninotes.alpha:id/snackbar_placeholder,it.feio.android.omninotes.alpha:id/category_marker,it.feio.android.omninotes.alpha:id/search_src_text,it.feio.android.omninotes.alpha:id/toolbar,it.feio.android.omninotes.alpha:id/note_title,it.feio.android.omninotes.alpha:id/fab_expand_menu_button,it.feio.android.omninotes.alpha:id/menu_tags,it.feio.android.omninotes.alpha:id/note_date,it.feio.android.omninotes.alpha:id/fab_checklist,it.feio.android.omninotes.alpha:id/card_layout,it.feio.android.omninotes.alpha:id/menu_search,it.feio.android.omninotes.alpha:id/list_root,it.feio.android.omninotes.alpha:id/search_plate,it.feio.android.omninotes.alpha:id/fab_camera,it.feio.android.omninotes.alpha:id/root,android:id/content,it.feio.android.omninotes.alpha:id/drawer_layout,android:id/navigationBarBackground,it.feio.android.omninotes.alpha:id/submit_area,it.feio.android.omninotes.alpha:id/crouton_handle,it.feio.android.omninotes.alpha:id/menu_uncomplete_checklists,it.feio.android.omninotes.alpha:id/list,it.feio.android.omninotes.alpha:id/attachmentThumbnail,it.feio.android.omninotes.alpha:id/expanded_image,it.feio.android.omninotes.alpha:id/note_content,it.feio.android.omninotes.alpha:id/fragment_container,it.feio.android.omninotes.alpha:id/search_edit_frame,android:id/statusBarBackground,it.feio.android.omninotes.alpha:id/search_voice_btn\nSearch in notes,Checklist,\u25fb Hello World\n\u25fb Hello World,a Passbook is shared with you,Updated: 2 days ago,Photo,Text note,Updated: 4 days ago,Updated: 6 minutes ago,\u25fb New item ### U\n\u25fb ### U ### Exam\u2026,Hello World",
      "font": "14px Arial red"
    }
  ],
  "edges": [
    {
      "from": "f8bad0be0114b0036c596178f86e2416",
      "to": "5583506110a5e4ad2c604c116d2c3143",
      "id": "f8bad0be0114b0036c596178f86e2416-->5583506110a5e4ad2c604c116d2c3143",
      "title": "<table class=\"table\">\n<tr><th>4</th><td>IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')</td></tr>\n</table>",
      "label": "4",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')",
          "event_id": 4,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "f8bad0be0114b0036c596178f86e2416",
      "to": "9fc8e85ca67fb9868fd9437146adebc9",
      "id": "f8bad0be0114b0036c596178f86e2416-->9fc8e85ca67fb9868fd9437146adebc9",
      "title": "<table class=\"table\">\n<tr><th>3</th><td>IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')</td></tr>\n</table>",
      "label": "3",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')",
          "event_id": 3,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "5583506110a5e4ad2c604c116d2c3143",
      "to": "f8bad0be0114b0036c596178f86e2416",
      "id": "5583506110a5e4ad2c604c116d2c3143-->f8bad0be0114b0036c596178f86e2416",
      "title": "<table class=\"table\">\n<tr><th>2</th><td>KeyEvent(state=5583506110a5e4ad2c604c116d2c3143, name=BACK)</td></tr>\n<tr><th>4</th><td>IntentEvent(intent='am force-stop it.feio.android.omninotes.alpha')</td></tr>\n</table>",
      "label": "2, 4",
      "events": [
        {
          "event_str": "KeyEvent(state=5583506110a5e4ad2c604c116d2c3143, name=BACK)",
          "event_id": 2,
          "event_type": "key",
          "view_images": []
        },
        {
          "event_str": "IntentEvent(intent='am force-stop it.feio.android.omninotes.alpha')",
          "event_id": 4,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "5583506110a5e4ad2c604c116d2c3143",
      "to": "eec05832c2715a77d61996970415374a",
      "id": "5583506110a5e4ad2c604c116d2c3143-->eec05832c2715a77d61996970415374a",
      "title": "<table class=\"table\">\n<tr><th>4</th><td>IntentEvent(intent='am force-stop it.feio.android.omninotes.alpha')</td></tr>\n</table>",
      "label": "4",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop it.feio.android.omninotes.alpha')",
          "event_id": 4,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "5583506110a5e4ad2c604c116d2c3143",
      "to": "b5202c53bed5eceaa3cad5f0e20d6c18",
      "id": "5583506110a5e4ad2c604c116d2c3143-->b5202c53bed5eceaa3cad5f0e20d6c18",
      "title": "<table class=\"table\">\n<tr><th>4</th><td>IntentEvent(intent='am force-stop it.feio.android.omninotes.alpha')</td></tr>\n</table>",
      "label": "4",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop it.feio.android.omninotes.alpha')",
          "event_id": 4,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "5583506110a5e4ad2c604c116d2c3143",
      "to": "6305b551c47d4d4bd6f96025838aa4ee",
      "id": "5583506110a5e4ad2c604c116d2c3143-->6305b551c47d4d4bd6f96025838aa4ee",
      "title": "<table class=\"table\">\n<tr><th>5</th><td>KeyEvent(state=5583506110a5e4ad2c604c116d2c3143, name=BACK)</td></tr>\n</table>",
      "label": "5",
      "events": [
        {
          "event_str": "KeyEvent(state=5583506110a5e4ad2c604c116d2c3143, name=BACK)",
          "event_id": 5,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "5583506110a5e4ad2c604c116d2c3143",
      "to": "d9a885e764af09879e0942de2953fb18",
      "id": "5583506110a5e4ad2c604c116d2c3143-->d9a885e764af09879e0942de2953fb18",
      "title": "<table class=\"table\">\n<tr><th>5</th><td>KeyEvent(state=5583506110a5e4ad2c604c116d2c3143, name=BACK)</td></tr>\n</table>",
      "label": "5",
      "events": [
        {
          "event_str": "KeyEvent(state=5583506110a5e4ad2c604c116d2c3143, name=BACK)",
          "event_id": 5,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "9fc8e85ca67fb9868fd9437146adebc9",
      "to": "f8bad0be0114b0036c596178f86e2416",
      "id": "9fc8e85ca67fb9868fd9437146adebc9-->f8bad0be0114b0036c596178f86e2416",
      "title": "<table class=\"table\">\n<tr><th>4</th><td>IntentEvent(intent='am force-stop it.feio.android.omninotes.alpha')</td></tr>\n</table>",
      "label": "4",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop it.feio.android.omninotes.alpha')",
          "event_id": 4,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "9fc8e85ca67fb9868fd9437146adebc9",
      "to": "b5202c53bed5eceaa3cad5f0e20d6c18",
      "id": "9fc8e85ca67fb9868fd9437146adebc9-->b5202c53bed5eceaa3cad5f0e20d6c18",
      "title": "<table class=\"table\">\n<tr><th>8</th><td>KeyEvent(state=9fc8e85ca67fb9868fd9437146adebc9, name=BACK)</td></tr>\n</table>",
      "label": "8",
      "events": [
        {
          "event_str": "KeyEvent(state=9fc8e85ca67fb9868fd9437146adebc9, name=BACK)",
          "event_id": 8,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "9fc8e85ca67fb9868fd9437146adebc9",
      "to": "8e1386b3328cc645284ed1ea6d9f0e23",
      "id": "9fc8e85ca67fb9868fd9437146adebc9-->8e1386b3328cc645284ed1ea6d9f0e23",
      "title": "<table class=\"table\">\n</table>",
      "label": "",
      "events": []
    },
    {
      "from": "9fc8e85ca67fb9868fd9437146adebc9",
      "to": "6305b551c47d4d4bd6f96025838aa4ee",
      "id": "9fc8e85ca67fb9868fd9437146adebc9-->6305b551c47d4d4bd6f96025838aa4ee",
      "title": "<table class=\"table\">\n</table>",
      "label": "",
      "events": []
    },
    {
      "from": "9fc8e85ca67fb9868fd9437146adebc9",
      "to": "29548b908236774381d6e7e5679070cd",
      "id": "9fc8e85ca67fb9868fd9437146adebc9-->29548b908236774381d6e7e5679070cd",
      "title": "<table class=\"table\">\n<tr><th>9</th><td>TouchEvent(state=9fc8e85ca67fb9868fd9437146adebc9, view=cf185b918ec4ec77e53b290d6a84165a(MainActivity/Button-))</td></tr>\n</table>",
      "label": "9",
      "events": [
        {
          "event_str": "TouchEvent(state=9fc8e85ca67fb9868fd9437146adebc9, view=cf185b918ec4ec77e53b290d6a84165a(MainActivity/Button-))",
          "event_id": 9,
          "event_type": "touch",
          "view_images": [
            "views/view_cf185b918ec4ec77e53b290d6a84165a.png"
          ]
        }
      ]
    },
    {
      "from": "9fc8e85ca67fb9868fd9437146adebc9",
      "to": "ffed3d236e4ca8ae2c748a993a02a773",
      "id": "9fc8e85ca67fb9868fd9437146adebc9-->ffed3d236e4ca8ae2c748a993a02a773",
      "title": "<table class=\"table\">\n<tr><th>13</th><td>TouchEvent(state=9fc8e85ca67fb9868fd9437146adebc9, view=25bd7f6de25a99eceff46d0109b02ec9(MainActivity/Button-))</td></tr>\n</table>",
      "label": "13",
      "events": [
        {
          "event_str": "TouchEvent(state=9fc8e85ca67fb9868fd9437146adebc9, view=25bd7f6de25a99eceff46d0109b02ec9(MainActivity/Button-))",
          "event_id": 13,
          "event_type": "touch",
          "view_images": [
            "views/view_25bd7f6de25a99eceff46d0109b02ec9.png"
          ]
        }
      ]
    },
    {
      "from": "eec05832c2715a77d61996970415374a",
      "to": "5583506110a5e4ad2c604c116d2c3143",
      "id": "eec05832c2715a77d61996970415374a-->5583506110a5e4ad2c604c116d2c3143",
      "title": "<table class=\"table\">\n<tr><th>4</th><td>IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')</td></tr>\n</table>",
      "label": "4",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')",
          "event_id": 4,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "eec05832c2715a77d61996970415374a",
      "to": "8e1386b3328cc645284ed1ea6d9f0e23",
      "id": "eec05832c2715a77d61996970415374a-->8e1386b3328cc645284ed1ea6d9f0e23",
      "title": "<table class=\"table\">\n<tr><th>5</th><td>TouchEvent(state=eec05832c2715a77d61996970415374a, view=31ee296af9d18a5fe763974907022b77(NexusLauncherActivity/ImageButton-))</td></tr>\n</table>",
      "label": "5",
      "events": [
        {
          "event_str": "TouchEvent(state=eec05832c2715a77d61996970415374a, view=31ee296af9d18a5fe763974907022b77(NexusLauncherActivity/ImageButton-))",
          "event_id": 5,
          "event_type": "touch",
          "view_images": [
            "views/view_31ee296af9d18a5fe763974907022b77.png"
          ]
        }
      ]
    },
    {
      "from": "b5202c53bed5eceaa3cad5f0e20d6c18",
      "to": "5583506110a5e4ad2c604c116d2c3143",
      "id": "b5202c53bed5eceaa3cad5f0e20d6c18-->5583506110a5e4ad2c604c116d2c3143",
      "title": "<table class=\"table\">\n<tr><th>4</th><td>IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')</td></tr>\n</table>",
      "label": "4",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')",
          "event_id": 4,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "b5202c53bed5eceaa3cad5f0e20d6c18",
      "to": "9fc8e85ca67fb9868fd9437146adebc9",
      "id": "b5202c53bed5eceaa3cad5f0e20d6c18-->9fc8e85ca67fb9868fd9437146adebc9",
      "title": "<table class=\"table\">\n<tr><th>8</th><td>IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')</td></tr>\n</table>",
      "label": "8",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')",
          "event_id": 8,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "b5202c53bed5eceaa3cad5f0e20d6c18",
      "to": "8e1386b3328cc645284ed1ea6d9f0e23",
      "id": "b5202c53bed5eceaa3cad5f0e20d6c18-->8e1386b3328cc645284ed1ea6d9f0e23",
      "title": "<table class=\"table\">\n<tr><th>8</th><td>TouchEvent(state=b5202c53bed5eceaa3cad5f0e20d6c18, view=80567ac696bd6977055aba987378159e(NexusLauncherActivity/TextView-Sun, Jun 2))</td></tr>\n</table>",
      "label": "8",
      "events": [
        {
          "event_str": "TouchEvent(state=b5202c53bed5eceaa3cad5f0e20d6c18, view=80567ac696bd6977055aba987378159e(NexusLauncherActivity/TextView-Sun, Jun 2))",
          "event_id": 8,
          "event_type": "touch",
          "view_images": [
            "views/view_80567ac696bd6977055aba987378159e.png"
          ]
        }
      ]
    },
    {
      "from": "b5202c53bed5eceaa3cad5f0e20d6c18",
      "to": "fdfaa0a2b0afb3bdba3e6b632186be22",
      "id": "b5202c53bed5eceaa3cad5f0e20d6c18-->fdfaa0a2b0afb3bdba3e6b632186be22",
      "title": "<table class=\"table\">\n<tr><th>18</th><td>IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')</td></tr>\n</table>",
      "label": "18",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')",
          "event_id": 18,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "8e1386b3328cc645284ed1ea6d9f0e23",
      "to": "5583506110a5e4ad2c604c116d2c3143",
      "id": "8e1386b3328cc645284ed1ea6d9f0e23-->5583506110a5e4ad2c604c116d2c3143",
      "title": "<table class=\"table\">\n<tr><th>5</th><td>IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')</td></tr>\n</table>",
      "label": "5",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')",
          "event_id": 5,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "8e1386b3328cc645284ed1ea6d9f0e23",
      "to": "9fc8e85ca67fb9868fd9437146adebc9",
      "id": "8e1386b3328cc645284ed1ea6d9f0e23-->9fc8e85ca67fb9868fd9437146adebc9",
      "title": "<table class=\"table\">\n<tr><th>8</th><td>IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')</td></tr>\n</table>",
      "label": "8",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start it.feio.android.omninotes.alpha/it.feio.android.omninotes.MainActivity')",
          "event_id": 8,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "d9a885e764af09879e0942de2953fb18",
      "to": "8bc53ea15785ec984226ffdd4a7af9e3",
      "id": "d9a885e764af09879e0942de2953fb18-->8bc53ea15785ec984226ffdd4a7af9e3",
      "title": "<table class=\"table\">\n<tr><th>6</th><td>ScrollEvent(state=d9a885e764af09879e0942de2953fb18, view=fb49941dcc3808442a2a19b330430c72(MainActivity/ListView-), direction=up)</td></tr>\n</table>",
      "label": "6",
      "events": [
        {
          "event_str": "ScrollEvent(state=d9a885e764af09879e0942de2953fb18, view=fb49941dcc3808442a2a19b330430c72(MainActivity/ListView-), direction=up)",
          "event_id": 6,
          "event_type": "scroll",
          "view_images": [
            "views/view_fb49941dcc3808442a2a19b330430c72.png"
          ]
        }
      ]
    },
    {
      "from": "8bc53ea15785ec984226ffdd4a7af9e3",
      "to": "9fc8e85ca67fb9868fd9437146adebc9",
      "id": "8bc53ea15785ec984226ffdd4a7af9e3-->9fc8e85ca67fb9868fd9437146adebc9",
      "title": "<table class=\"table\">\n<tr><th>7</th><td>TouchEvent(state=8bc53ea15785ec984226ffdd4a7af9e3, view=c20ddaced345235e835b4b88b4d1537e(MainActivity/ImageButton-))</td></tr>\n</table>",
      "label": "7",
      "events": [
        {
          "event_str": "TouchEvent(state=8bc53ea15785ec984226ffdd4a7af9e3, view=c20ddaced345235e835b4b88b4d1537e(MainActivity/ImageButton-))",
          "event_id": 7,
          "event_type": "touch",
          "view_images": [
            "views/view_c20ddaced345235e835b4b88b4d1537e.png"
          ]
        }
      ]
    },
    {
      "from": "29548b908236774381d6e7e5679070cd",
      "to": "2c60f52af19298a64804f0e0e5a44b29",
      "id": "29548b908236774381d6e7e5679070cd-->2c60f52af19298a64804f0e0e5a44b29",
      "title": "<table class=\"table\">\n<tr><th>11</th><td>KeyEvent(state=29548b908236774381d6e7e5679070cd, name=BACK)</td></tr>\n</table>",
      "label": "11",
      "events": [
        {
          "event_str": "KeyEvent(state=29548b908236774381d6e7e5679070cd, name=BACK)",
          "event_id": 11,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "2c60f52af19298a64804f0e0e5a44b29",
      "to": "29548b908236774381d6e7e5679070cd",
      "id": "2c60f52af19298a64804f0e0e5a44b29-->29548b908236774381d6e7e5679070cd",
      "title": "<table class=\"table\">\n<tr><th>11</th><td>TouchEvent(state=2c60f52af19298a64804f0e0e5a44b29, view=e25ca79c878d853a295fa689d1d6b628(MainActivity/AutoCompleteTextView-Search in ))</td></tr>\n</table>",
      "label": "11",
      "events": [
        {
          "event_str": "TouchEvent(state=2c60f52af19298a64804f0e0e5a44b29, view=e25ca79c878d853a295fa689d1d6b628(MainActivity/AutoCompleteTextView-Search in ))",
          "event_id": 11,
          "event_type": "touch",
          "view_images": [
            "views/view_e25ca79c878d853a295fa689d1d6b628.png"
          ]
        }
      ]
    },
    {
      "from": "2c60f52af19298a64804f0e0e5a44b29",
      "to": "9fc8e85ca67fb9868fd9437146adebc9",
      "id": "2c60f52af19298a64804f0e0e5a44b29-->9fc8e85ca67fb9868fd9437146adebc9",
      "title": "<table class=\"table\">\n<tr><th>12</th><td>KeyEvent(state=2c60f52af19298a64804f0e0e5a44b29, name=BACK)</td></tr>\n</table>",
      "label": "12",
      "events": [
        {
          "event_str": "KeyEvent(state=2c60f52af19298a64804f0e0e5a44b29, name=BACK)",
          "event_id": 12,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "ffed3d236e4ca8ae2c748a993a02a773",
      "to": "4d0d6757addff151262908d09583c285",
      "id": "ffed3d236e4ca8ae2c748a993a02a773-->4d0d6757addff151262908d09583c285",
      "title": "<table class=\"table\">\n<tr><th>14</th><td>TouchEvent(state=ffed3d236e4ca8ae2c748a993a02a773, view=15669cecd14e95be61a5406ac4d13314(MainActivity/LinearLayout-))</td></tr>\n</table>",
      "label": "14",
      "events": [
        {
          "event_str": "TouchEvent(state=ffed3d236e4ca8ae2c748a993a02a773, view=15669cecd14e95be61a5406ac4d13314(MainActivity/LinearLayout-))",
          "event_id": 14,
          "event_type": "touch",
          "view_images": [
            "views/view_15669cecd14e95be61a5406ac4d13314.png"
          ]
        }
      ]
    },
    {
      "from": "4d0d6757addff151262908d09583c285",
      "to": "b0ff97955762fa20dcc73c4f8035abc6",
      "id": "4d0d6757addff151262908d09583c285-->b0ff97955762fa20dcc73c4f8035abc6",
      "title": "<table class=\"table\">\n<tr><th>15</th><td>TouchEvent(state=4d0d6757addff151262908d09583c285, view=cf185b918ec4ec77e53b290d6a84165a(MainActivity/Button-))</td></tr>\n</table>",
      "label": "15",
      "events": [
        {
          "event_str": "TouchEvent(state=4d0d6757addff151262908d09583c285, view=cf185b918ec4ec77e53b290d6a84165a(MainActivity/Button-))",
          "event_id": 15,
          "event_type": "touch",
          "view_images": [
            "views/view_cf185b918ec4ec77e53b290d6a84165a.png"
          ]
        }
      ]
    },
    {
      "from": "b0ff97955762fa20dcc73c4f8035abc6",
      "to": "85d101414477d7a3dfb7f6bf7c63cde2",
      "id": "b0ff97955762fa20dcc73c4f8035abc6-->85d101414477d7a3dfb7f6bf7c63cde2",
      "title": "<table class=\"table\">\n<tr><th>16</th><td>KeyEvent(state=b0ff97955762fa20dcc73c4f8035abc6, name=BACK)</td></tr>\n</table>",
      "label": "16",
      "events": [
        {
          "event_str": "KeyEvent(state=b0ff97955762fa20dcc73c4f8035abc6, name=BACK)",
          "event_id": 16,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "85d101414477d7a3dfb7f6bf7c63cde2",
      "to": "45d283259ee78f338cdf50b6858d1eb3",
      "id": "85d101414477d7a3dfb7f6bf7c63cde2-->45d283259ee78f338cdf50b6858d1eb3",
      "title": "<table class=\"table\">\n<tr><th>17</th><td>KeyEvent(state=85d101414477d7a3dfb7f6bf7c63cde2, name=BACK)</td></tr>\n</table>",
      "label": "17",
      "events": [
        {
          "event_str": "KeyEvent(state=85d101414477d7a3dfb7f6bf7c63cde2, name=BACK)",
          "event_id": 17,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "45d283259ee78f338cdf50b6858d1eb3",
      "to": "b5202c53bed5eceaa3cad5f0e20d6c18",
      "id": "45d283259ee78f338cdf50b6858d1eb3-->b5202c53bed5eceaa3cad5f0e20d6c18",
      "title": "<table class=\"table\">\n<tr><th>18</th><td>KeyEvent(state=45d283259ee78f338cdf50b6858d1eb3, name=BACK)</td></tr>\n</table>",
      "label": "18",
      "events": [
        {
          "event_str": "KeyEvent(state=45d283259ee78f338cdf50b6858d1eb3, name=BACK)",
          "event_id": 18,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "fdfaa0a2b0afb3bdba3e6b632186be22",
      "to": "15c409e69f4b5171c39482b00626ddc9",
      "id": "fdfaa0a2b0afb3bdba3e6b632186be22-->15c409e69f4b5171c39482b00626ddc9",
      "title": "<table class=\"table\">\n<tr><th>19</th><td>TouchEvent(state=fdfaa0a2b0afb3bdba3e6b632186be22, view=cf185b918ec4ec77e53b290d6a84165a(MainActivity/Button-))</td></tr>\n</table>",
      "label": "19",
      "events": [
        {
          "event_str": "TouchEvent(state=fdfaa0a2b0afb3bdba3e6b632186be22, view=cf185b918ec4ec77e53b290d6a84165a(MainActivity/Button-))",
          "event_id": 19,
          "event_type": "touch",
          "view_images": [
            "views/view_cf185b918ec4ec77e53b290d6a84165a.png"
          ]
        }
      ]
    }
  ],
  "num_nodes": 18,
  "num_edges": 32,
  "num_effective_events": 19,
  "num_reached_activities": 1,
  "test_date": "2025-06-29 13:30:05",
  "time_spent": 355.586825,
  "num_transitions": 60,
  "device_serial": "emulator-5554",
  "device_model_number": "sdk_gphone64_x86_64",
  "device_sdk_version": 35,
  "app_sha256": "7d3528d0028af94fa39821f005767343df5f38d7cb0499fcd7ec1bddcb7bbeda",
  "app_package": "it.feio.android.omninotes.alpha",
  "app_main_activity": "it.feio.android.omninotes.MainActivity",
  "app_num_total_activities": 15
}