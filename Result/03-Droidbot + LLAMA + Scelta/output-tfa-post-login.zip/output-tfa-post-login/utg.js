var utg = 
{
  "nodes": [
    {
      "id": "f8bad0be0114b0036c596178f86e2416",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123555.png",
      "label": "NexusLauncherActivity\n<FIRST>",
      "package": "com.google.android.apps.nexuslauncher",
      "activity": ".NexusLauncherActivity",
      "state_str": "f8bad0be0114b0036c596178f86e2416",
      "structure_str": "345d86390034d21a3935ecda158a4915",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.google.android.apps.nexuslauncher</td></tr>\n<tr><th>activity</th><td>.NexusLauncherActivity</td></tr>\n<tr><th>state_str</th><td>f8bad0be0114b0036c596178f86e2416</td></tr>\n<tr><th>structure_str</th><td>345d86390034d21a3935ecda158a4915</td></tr>\n</table>",
      "content": "com.google.android.apps.nexuslauncher\n.NexusLauncherActivity\nf8bad0be0114b0036c596178f86e2416\ncom.google.android.apps.nexuslauncher:id/launcher,com.google.android.apps.nexuslauncher:id/text_group,com.google.android.apps.nexuslauncher:id/hotseat,com.google.android.apps.nexuslauncher:id/scrim_view,com.google.android.apps.nexuslauncher:id/g_icon,com.google.android.apps.nexuslauncher:id/workspace,com.google.android.apps.nexuslauncher:id/mic_icon,com.google.android.apps.nexuslauncher:id/page_indicator,com.google.android.apps.nexuslauncher:id/drag_layer,com.google.android.apps.nexuslauncher:id/bc_smartspace_view,com.google.android.apps.nexuslauncher:id/end_part,com.google.android.apps.nexuslauncher:id/overview_actions_view,com.google.android.apps.nexuslauncher:id/smartspace_subtitle_group,com.google.android.apps.nexuslauncher:id/search_container_hotseat,com.google.android.apps.nexuslauncher:id/base_template_card_with_date,com.google.android.apps.nexuslauncher:id/smartspace_card_pager,com.google.android.apps.nexuslauncher:id/date,com.google.android.apps.nexuslauncher:id/search_container_workspace,com.google.android.apps.nexuslauncher:id/lens_icon,android:id/content\nPhotos,Sun, Jun 29,Gmail,Phone,DroidBot,Chrome,YouTube,Messages",
      "font": "14px Arial red"
    },
    {
      "id": "61313c33ffc04b0a4ff93735152c7ddf",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123600.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "61313c33ffc04b0a4ff93735152c7ddf",
      "structure_str": "61313c33ffc04b0a4ff93735152c7ddf",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>61313c33ffc04b0a4ff93735152c7ddf</td></tr>\n<tr><th>structure_str</th><td>61313c33ffc04b0a4ff93735152c7ddf</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n61313c33ffc04b0a4ff93735152c7ddf\n\n"
    },
    {
      "id": "616d8e394381e6820e9956759c84d687",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123610.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "616d8e394381e6820e9956759c84d687",
      "structure_str": "ed39f8171a258cb9cc48471fb2d0c477",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>616d8e394381e6820e9956759c84d687</td></tr>\n<tr><th>structure_str</th><td>ed39f8171a258cb9cc48471fb2d0c477</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n616d8e394381e6820e9956759c84d687\ncom.fsck.k9.debug:id/message_list_coordinator,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/message_list,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/search_button,com.fsck.k9.debug:id/swiperefresh,android:id/statusBarBackground,android:id/navigationBarBackground,com.fsck.k9.debug:id/container,android:id/content,com.fsck.k9.debug:id/action_bar_root\nInbox"
    },
    {
      "id": "8cc687d9a0b35afcf13ab3ffb0fcddab",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123621.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "8cc687d9a0b35afcf13ab3ffb0fcddab",
      "structure_str": "1724ee88f0072ee9840acbef9d8b8db1",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>8cc687d9a0b35afcf13ab3ffb0fcddab</td></tr>\n<tr><th>structure_str</th><td>1724ee88f0072ee9840acbef9d8b8db1</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n8cc687d9a0b35afcf13ab3ffb0fcddab\ncom.fsck.k9.debug:id/title,com.fsck.k9.debug:id/content\nMark all as read,Select all"
    },
    {
      "id": "9fdc211f534f2f363cd0116ac5ea68ed",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123641.png",
      "label": "MessageList\n<LAST>",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "9fdc211f534f2f363cd0116ac5ea68ed",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>9fdc211f534f2f363cd0116ac5ea68ed</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n9fdc211f534f2f363cd0116ac5ea68ed\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\n   Search,Inbox",
      "font": "14px Arial red"
    },
    {
      "id": "caf5631c1d562c25f2c46fafdf1c3dfc",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123647.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "caf5631c1d562c25f2c46fafdf1c3dfc",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>caf5631c1d562c25f2c46fafdf1c3dfc</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\ncaf5631c1d562c25f2c46fafdf1c3dfc\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Search  ### Exa"
    },
    {
      "id": "b6c5b26037ced8c3214cb06dcac7156d",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123653.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "b6c5b26037ced8c3214cb06dcac7156d",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>b6c5b26037ced8c3214cb06dcac7156d</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nb6c5b26037ced8c3214cb06dcac7156d\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\n### Exa  ### Fi,Inbox"
    },
    {
      "id": "279e2d30f10555a4ed4cf436875fbef2",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123705.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "279e2d30f10555a4ed4cf436875fbef2",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>279e2d30f10555a4ed4cf436875fbef2</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n279e2d30f10555a4ed4cf436875fbef2\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,ExaFi wirelessl"
    },
    {
      "id": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123722.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>eeae072fb2e8d6ecbbe24c35f135a3a6</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\neeae072fb2e8d6ecbbe24c35f135a3a6\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nwireless headph,Inbox"
    },
    {
      "id": "127fdca3223ebf0096869b24c7f5bdef",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123810.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "127fdca3223ebf0096869b24c7f5bdef",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>127fdca3223ebf0096869b24c7f5bdef</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n127fdca3223ebf0096869b24c7f5bdef\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Search"
    },
    {
      "id": "f7c50225c83a0cd86cced82b3caec230",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123816.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "f7c50225c83a0cd86cced82b3caec230",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>f7c50225c83a0cd86cced82b3caec230</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nf7c50225c83a0cd86cced82b3caec230\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Search [INST] <"
    },
    {
      "id": "f9da2cb689817346c1f496e37efd51e1",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123948.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "f9da2cb689817346c1f496e37efd51e1",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>f9da2cb689817346c1f496e37efd51e1</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nf9da2cb689817346c1f496e37efd51e1\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nSearch  ### Det,Inbox"
    },
    {
      "id": "47edfb97e557b545a0fedbc4a22b7600",
      "shape": "image",
      "image": "states\\screen_2025-06-29_123955.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "47edfb97e557b545a0fedbc4a22b7600",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>47edfb97e557b545a0fedbc4a22b7600</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n47edfb97e557b545a0fedbc4a22b7600\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,### Det ### Det"
    },
    {
      "id": "cebcaf3ffb903c5b13298e22ad072a28",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124043.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "cebcaf3ffb903c5b13298e22ad072a28",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>cebcaf3ffb903c5b13298e22ad072a28</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\ncebcaf3ffb903c5b13298e22ad072a28\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nSearch [/SYS],Inbox"
    },
    {
      "id": "8f4cbdf81b58433103e7bff8783cc97c",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124214.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "8f4cbdf81b58433103e7bff8783cc97c",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>8f4cbdf81b58433103e7bff8783cc97c</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n8f4cbdf81b58433103e7bff8783cc97c\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nSearch  ### Cor,Inbox"
    },
    {
      "id": "5023782a7c74c17cc45f46c082238945",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124257.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "5023782a7c74c17cc45f46c082238945",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>5023782a7c74c17cc45f46c082238945</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n5023782a7c74c17cc45f46c082238945\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nsearch ### Focu,Inbox"
    },
    {
      "id": "dc7646d1f8cb97867ca0479c922f9edb",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124347.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "dc7646d1f8cb97867ca0479c922f9edb",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>dc7646d1f8cb97867ca0479c922f9edb</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\ndc7646d1f8cb97867ca0479c922f9edb\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Search  ### Gen"
    },
    {
      "id": "f590b8ba7742eb094ce4a6d271582fc3",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124354.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "f590b8ba7742eb094ce4a6d271582fc3",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>f590b8ba7742eb094ce4a6d271582fc3</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nf590b8ba7742eb094ce4a6d271582fc3\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\n### Gen ### Gen,Inbox"
    },
    {
      "id": "bd2738a68bff2e585e96016c558ecc21",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124521.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "bd2738a68bff2e585e96016c558ecc21",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>bd2738a68bff2e585e96016c558ecc21</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nbd2738a68bff2e585e96016c558ecc21\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,search </SYS>"
    },
    {
      "id": "652f500c7c62167f2273e19c3bcb9977",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124531.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "652f500c7c62167f2273e19c3bcb9977",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>652f500c7c62167f2273e19c3bcb9977</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n652f500c7c62167f2273e19c3bcb9977\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nsearch [/INST],Inbox"
    },
    {
      "id": "8ffd3ced1623467a1ae58c148842d277",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124622.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "8ffd3ced1623467a1ae58c148842d277",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>8ffd3ced1623467a1ae58c148842d277</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n8ffd3ced1623467a1ae58c148842d277\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\n### Exa,Inbox"
    },
    {
      "id": "3a2e2376da0f93c094f5f9826aa37c1a",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124629.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "3a2e2376da0f93c094f5f9826aa37c1a",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>3a2e2376da0f93c094f5f9826aa37c1a</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n3a2e2376da0f93c094f5f9826aa37c1a\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nExa  ### Exampl,Inbox"
    },
    {
      "id": "919f479691fb0891d36b6766b1fcda54",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124643.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "919f479691fb0891d36b6766b1fcda54",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>919f479691fb0891d36b6766b1fcda54</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n919f479691fb0891d36b6766b1fcda54\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\n### Exampl  ###,Inbox"
    },
    {
      "id": "97ee1d3fa10070f426e7258dfadcaa59",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124728.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "97ee1d3fa10070f426e7258dfadcaa59",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>97ee1d3fa10070f426e7258dfadcaa59</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n97ee1d3fa10070f426e7258dfadcaa59\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Search   Note:"
    },
    {
      "id": "8574c640c133f4e4e4a4658ab45677d4",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124736.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "8574c640c133f4e4e4a4658ab45677d4",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>8574c640c133f4e4e4a4658ab45677d4</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n8574c640c133f4e4e4a4658ab45677d4\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,search  Note:"
    },
    {
      "id": "fb88c8dea353a0385bf91f2f39e5aef6",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124744.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "fb88c8dea353a0385bf91f2f39e5aef6",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>fb88c8dea353a0385bf91f2f39e5aef6</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nfb88c8dea353a0385bf91f2f39e5aef6\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Note:  ### Exam"
    },
    {
      "id": "b5cac7498a4807b26d71296071cd2a59",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124750.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "b5cac7498a4807b26d71296071cd2a59",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>b5cac7498a4807b26d71296071cd2a59</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nb5cac7498a4807b26d71296071cd2a59\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\n### Exam,Inbox"
    },
    {
      "id": "16aa6b2f81055a1c7d256f59eeccaf84",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124758.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "16aa6b2f81055a1c7d256f59eeccaf84",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>16aa6b2f81055a1c7d256f59eeccaf84</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n16aa6b2f81055a1c7d256f59eeccaf84\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Exam  ### Examp"
    },
    {
      "id": "c3450744ca28d2b8d167cd5398c62263",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124816.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "c3450744ca28d2b8d167cd5398c62263",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>c3450744ca28d2b8d167cd5398c62263</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nc3450744ca28d2b8d167cd5398c62263\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Exam ###  Examp"
    },
    {
      "id": "c1ea5af9bb96392814e220d8a359dae2",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124825.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "c1ea5af9bb96392814e220d8a359dae2",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>c1ea5af9bb96392814e220d8a359dae2</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nc1ea5af9bb96392814e220d8a359dae2\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,exam ###  examp"
    },
    {
      "id": "146e2e86d69f374726af95cb0e2d3b34",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124904.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "146e2e86d69f374726af95cb0e2d3b34",
      "structure_str": "1724ee88f0072ee9840acbef9d8b8db1",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>146e2e86d69f374726af95cb0e2d3b34</td></tr>\n<tr><th>structure_str</th><td>1724ee88f0072ee9840acbef9d8b8db1</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n146e2e86d69f374726af95cb0e2d3b34\ncom.fsck.k9.debug:id/title,com.fsck.k9.debug:id/content\nDate,Star,Attachments,Read/unread,Arrival,Sender,Subject"
    },
    {
      "id": "46a5bdd4627f371e0f6bd253473604b9",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124923.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "46a5bdd4627f371e0f6bd253473604b9",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>46a5bdd4627f371e0f6bd253473604b9</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n46a5bdd4627f371e0f6bd253473604b9\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nSearch  ### Foc,Inbox"
    },
    {
      "id": "733aa5148bf1cc3c9f8ce9bb39e078fe",
      "shape": "image",
      "image": "states\\screen_2025-06-29_124929.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "733aa5148bf1cc3c9f8ce9bb39e078fe",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>733aa5148bf1cc3c9f8ce9bb39e078fe</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n733aa5148bf1cc3c9f8ce9bb39e078fe\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\n### Foc  ### Fi,Inbox"
    },
    {
      "id": "22ac1c3821e05a5857e0ab9f3e049e67",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125026.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "22ac1c3821e05a5857e0ab9f3e049e67",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>22ac1c3821e05a5857e0ab9f3e049e67</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n22ac1c3821e05a5857e0ab9f3e049e67\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,search"
    },
    {
      "id": "acb338538cab2b4ecc07bf4f4160fd5e",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125032.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "acb338538cab2b4ecc07bf4f4160fd5e",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>acb338538cab2b4ecc07bf4f4160fd5e</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nacb338538cab2b4ecc07bf4f4160fd5e\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,search  ### Exa"
    },
    {
      "id": "f34862b8cbfa821e5e91461a427c9dca",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125040.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "f34862b8cbfa821e5e91461a427c9dca",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>f34862b8cbfa821e5e91461a427c9dca</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nf34862b8cbfa821e5e91461a427c9dca\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\n### Exa  ### Ad,Inbox"
    },
    {
      "id": "64c0fdccf8a65a5cd072b0e2c2590b54",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125136.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "64c0fdccf8a65a5cd072b0e2c2590b54",
      "structure_str": "8657ab7cee92beccb2871bab4fdf794d",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>64c0fdccf8a65a5cd072b0e2c2590b54</td></tr>\n<tr><th>structure_str</th><td>8657ab7cee92beccb2871bab4fdf794d</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n64c0fdccf8a65a5cd072b0e2c2590b54\ncom.fsck.k9.debug:id/preview,com.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/subject,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_button,com.fsck.k9.debug:id/divider,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,com.fsck.k9.debug:id/date,com.fsck.k9.debug:id/contact_picture,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/star,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/contact_picture_click_area,com.fsck.k9.debug:id/star_click_area,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/message_list_coordinator,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/main_text,com.fsck.k9.debug:id/attachment,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nRe: Aaaa,Fri,Load up to 100 more,Google \u2013 Hi Llm, Welcome to Google on your Google emulator device. Next, take these 2 steps to confirm your Google Account settings. Step 1: Privacy Checkup Confirm key settings and the data Google uses to personalize your experience Confirm Privacy Settings <... Step 2: Security Checkup Confirm what devices may have access to your Google Account and more Check Security Status <... Want to stay in the loop? Sign up to receive personalized tips, news and recommendations to help you get the most out of your Google Ac\u2026,Security alert,Raffaele Martone,Llm, review your Google Account settings,Google \u2013 [image: Google] You allowed K-9 Mail access to some of your Google Account data llm199644@gmail.com If you didn\u2019t allow K-9 Mail access to some of your Google Account data, someone else may be trying to access your Google Account data. Take a moment now to check your account activity and secure your account. Check activity <... To make changes at any time to the access that K-9 Mail has to your data, go to your Google Account <... You can also see security activity at ... You received this email to let you\u2026,[Gmail]/All Mail"
    },
    {
      "id": "2d8ab988366202ee97ed409883a5e4b9",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125210.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "2d8ab988366202ee97ed409883a5e4b9",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>2d8ab988366202ee97ed409883a5e4b9</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n2d8ab988366202ee97ed409883a5e4b9\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nsearch  Note: [,Inbox"
    },
    {
      "id": "82759ab3f0d87b32d1783bb5109fd153",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125216.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "82759ab3f0d87b32d1783bb5109fd153",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>82759ab3f0d87b32d1783bb5109fd153</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n82759ab3f0d87b32d1783bb5109fd153\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nNote: [</input>,Inbox"
    },
    {
      "id": "4368245b81f81ad71cf2e77dfa1d9974",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125310.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "4368245b81f81ad71cf2e77dfa1d9974",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>4368245b81f81ad71cf2e77dfa1d9974</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n4368245b81f81ad71cf2e77dfa1d9974\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Search  ### Ans"
    },
    {
      "id": "b8cd42cb8b44f6cf61be699ab2ad3b7d",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125316.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "b8cd42cb8b44f6cf61be699ab2ad3b7d",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>b8cd42cb8b44f6cf61be699ab2ad3b7d</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nb8cd42cb8b44f6cf61be699ab2ad3b7d\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\n### Ans  ### Fu,Inbox"
    },
    {
      "id": "970c8c0a2de66826cdb80e5c5624242a",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125404.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "970c8c0a2de66826cdb80e5c5624242a",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>970c8c0a2de66826cdb80e5c5624242a</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n970c8c0a2de66826cdb80e5c5624242a\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Search  Note: T"
    },
    {
      "id": "0fd61a526029735966c9352dfc03b822",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125410.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "0fd61a526029735966c9352dfc03b822",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>0fd61a526029735966c9352dfc03b822</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n0fd61a526029735966c9352dfc03b822\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nNote: T Note: T,Inbox"
    },
    {
      "id": "de86ece2f17fda5b3895ad7e795f66c0",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125415.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "de86ece2f17fda5b3895ad7e795f66c0",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>de86ece2f17fda5b3895ad7e795f66c0</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nde86ece2f17fda5b3895ad7e795f66c0\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Note: T [/INST]"
    },
    {
      "id": "f66cd33b597c4c93cd46f268fc7ae34f",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125542.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "f66cd33b597c4c93cd46f268fc7ae34f",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>f66cd33b597c4c93cd46f268fc7ae34f</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nf66cd33b597c4c93cd46f268fc7ae34f\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,search [INST] <"
    },
    {
      "id": "c0f6e1ac5b504d645bffe2f7fae3026b",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125549.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "c0f6e1ac5b504d645bffe2f7fae3026b",
      "structure_str": "196008ee83d09eb551e1f1956e3fcf85",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>c0f6e1ac5b504d645bffe2f7fae3026b</td></tr>\n<tr><th>structure_str</th><td>196008ee83d09eb551e1f1956e3fcf85</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nc0f6e1ac5b504d645bffe2f7fae3026b\ncom.fsck.k9.debug:id/message_list_coordinator,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/navigation_drawer_content,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/message_list,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/search_button,com.fsck.k9.debug:id/swiperefresh,android:id/statusBarBackground,android:id/navigationBarBackground,com.fsck.k9.debug:id/container,android:id/content,com.fsck.k9.debug:id/action_bar_root\n[Gmail]/Drafts,llm199644@gmail.com,Show accounts,[Gmail]/Sent Mail,[Gmail]/Spam,[Gmail]/Starred,Inbox,[Gmail]/Important,[Gmail]/Trash,1,Outbox,Manage folders,[Gmail]/All Mail"
    },
    {
      "id": "30e56b6205f3da93a1d41c345505420a",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125612.png",
      "label": "MessageCompose",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageCompose",
      "state_str": "30e56b6205f3da93a1d41c345505420a",
      "structure_str": "9ef355262e6d94c59ad4f64fbea3790b",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageCompose</td></tr>\n<tr><th>state_str</th><td>30e56b6205f3da93a1d41c345505420a</td></tr>\n<tr><th>structure_str</th><td>9ef355262e6d94c59ad4f64fbea3790b</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageCompose\n30e56b6205f3da93a1d41c345505420a\ncom.fsck.k9.debug:id/crypto_status_anchor,com.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/subject,com.fsck.k9.debug:id/recipient_expander_container,com.fsck.k9.debug:id/to_wrapper,com.fsck.k9.debug:id/to,com.fsck.k9.debug:id/recipient_expander,android:id/navigationBarBackground,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/add_attachment,com.fsck.k9.debug:id/identity,com.fsck.k9.debug:id/send,com.fsck.k9.debug:id/reply_to_expander,com.fsck.k9.debug:id/to_label,com.fsck.k9.debug:id/attachments,android:id/statusBarBackground,android:id/content,com.fsck.k9.debug:id/message_content,com.fsck.k9.debug:id/reply_to_expander_container\nGoogle <no-reply@google.com>, ,llm199644@gmail.com,From,To,Compose,Message text,Subject"
    },
    {
      "id": "581f5c07eb069305131a01597d6e1e6a",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125620.png",
      "label": "MessageCompose",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageCompose",
      "state_str": "581f5c07eb069305131a01597d6e1e6a",
      "structure_str": "9ef355262e6d94c59ad4f64fbea3790b",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageCompose</td></tr>\n<tr><th>state_str</th><td>581f5c07eb069305131a01597d6e1e6a</td></tr>\n<tr><th>structure_str</th><td>9ef355262e6d94c59ad4f64fbea3790b</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageCompose\n581f5c07eb069305131a01597d6e1e6a\ncom.fsck.k9.debug:id/crypto_status_anchor,com.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/subject,com.fsck.k9.debug:id/recipient_expander_container,com.fsck.k9.debug:id/to_wrapper,com.fsck.k9.debug:id/to,com.fsck.k9.debug:id/recipient_expander,android:id/navigationBarBackground,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/add_attachment,com.fsck.k9.debug:id/identity,com.fsck.k9.debug:id/send,com.fsck.k9.debug:id/reply_to_expander,com.fsck.k9.debug:id/to_label,com.fsck.k9.debug:id/attachments,android:id/statusBarBackground,android:id/content,com.fsck.k9.debug:id/message_content,com.fsck.k9.debug:id/reply_to_expander_container\nGoogle <no-reply@google.com>, ,llm199644@gmail.com,From,To,Compose,wireless headph,Subject"
    },
    {
      "id": "bfce3df1601f236bd87766ad4a166193",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125706.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "bfce3df1601f236bd87766ad4a166193",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>bfce3df1601f236bd87766ad4a166193</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nbfce3df1601f236bd87766ad4a166193\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Search ### Exam"
    },
    {
      "id": "6bc0c445b414722400f2c8f09899886b",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125801.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "6bc0c445b414722400f2c8f09899886b",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>6bc0c445b414722400f2c8f09899886b</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n6bc0c445b414722400f2c8f09899886b\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,Note:"
    },
    {
      "id": "616fed3907354827cd2c62b10747e955",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125821.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "616fed3907354827cd2c62b10747e955",
      "structure_str": "dcc9191c14304c8cba25938fbba82438",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>616fed3907354827cd2c62b10747e955</td></tr>\n<tr><th>structure_str</th><td>dcc9191c14304c8cba25938fbba82438</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n616fed3907354827cd2c62b10747e955\ncom.fsck.k9.debug:id/message_layout_animator,com.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/subject,com.fsck.k9.debug:id/attachments_container,com.fsck.k9.debug:id/date,com.fsck.k9.debug:id/message_view,com.fsck.k9.debug:id/menu_primary_action,com.fsck.k9.debug:id/message_container,com.fsck.k9.debug:id/contact_picture,android:id/navigationBarBackground,com.fsck.k9.debug:id/from,com.fsck.k9.debug:id/toggle_unread,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/delete,com.fsck.k9.debug:id/container,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/menu_overflow,com.fsck.k9.debug:id/recipient_names,com.fsck.k9.debug:id/participants_container,com.fsck.k9.debug:id/message_viewpager,com.fsck.k9.debug:id/message_scrollview,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/recipients,com.fsck.k9.debug:id/message_view_container,com.fsck.k9.debug:id/header_container,android:id/statusBarBackground,com.fsck.k9.debug:id/flagged,android:id/content\nFri,vets san franci4@gmail.com,llm,Aaaa,to raffaelemartone34@gmail.com"
    },
    {
      "id": "d18d481d150742140f105339679fcb89",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125833.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "d18d481d150742140f105339679fcb89",
      "structure_str": "0d35ecf632a134337feb47319e5c3ad7",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>d18d481d150742140f105339679fcb89</td></tr>\n<tr><th>structure_str</th><td>0d35ecf632a134337feb47319e5c3ad7</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\nd18d481d150742140f105339679fcb89\ncom.fsck.k9.debug:id/preview,com.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/subject,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_button,com.fsck.k9.debug:id/divider,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,com.fsck.k9.debug:id/date,com.fsck.k9.debug:id/contact_picture,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/star,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/contact_picture_click_area,com.fsck.k9.debug:id/star_click_area,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/message_list_coordinator,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/main_text,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nFri,Load up to 100 more,[Gmail]/Sent Mail,Aaaa,To: raffaelemartone34@gmail.com \u2013 vets san franci4@gmail.com"
    },
    {
      "id": "1d07fce7ccab5b2d047269955d22b798",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125901.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "1d07fce7ccab5b2d047269955d22b798",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>1d07fce7ccab5b2d047269955d22b798</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n1d07fce7ccab5b2d047269955d22b798\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\nInbox,search ### Exa"
    },
    {
      "id": "8bd32e01c21f644a2edd5f1e2b0f61c3",
      "shape": "image",
      "image": "states\\screen_2025-06-29_125914.png",
      "label": "MessageList",
      "package": "com.fsck.k9.debug",
      "activity": "com.fsck.k9.activity.MessageList",
      "state_str": "8bd32e01c21f644a2edd5f1e2b0f61c3",
      "structure_str": "8a453ea336bd690080f7db0e6f7c5e0c",
      "title": "<table class=\"table\">\n<tr><th>package</th><td>com.fsck.k9.debug</td></tr>\n<tr><th>activity</th><td>com.fsck.k9.activity.MessageList</td></tr>\n<tr><th>state_str</th><td>8bd32e01c21f644a2edd5f1e2b0f61c3</td></tr>\n<tr><th>structure_str</th><td>8a453ea336bd690080f7db0e6f7c5e0c</td></tr>\n</table>",
      "content": "com.fsck.k9.debug\ncom.fsck.k9.activity.MessageList\n8bd32e01c21f644a2edd5f1e2b0f61c3\ncom.fsck.k9.debug:id/toolbar,com.fsck.k9.debug:id/set_sort,com.fsck.k9.debug:id/swiperefresh,com.fsck.k9.debug:id/search_close_btn,com.fsck.k9.debug:id/floating_action_button,com.fsck.k9.debug:id/message_list,android:id/navigationBarBackground,com.fsck.k9.debug:id/message_list_container,com.fsck.k9.debug:id/action_bar_root,com.fsck.k9.debug:id/search_edit_frame,com.fsck.k9.debug:id/search_bar,com.fsck.k9.debug:id/toolbarTitle,com.fsck.k9.debug:id/search_src_text,com.fsck.k9.debug:id/search_plate,com.fsck.k9.debug:id/search,com.fsck.k9.debug:id/navigation_drawer_layout,com.fsck.k9.debug:id/message_list_coordinator,android:id/statusBarBackground,com.fsck.k9.debug:id/container,android:id/content\n### Exa  ### Sa,Inbox"
    }
  ],
  "edges": [
    {
      "from": "f8bad0be0114b0036c596178f86e2416",
      "to": "61313c33ffc04b0a4ff93735152c7ddf",
      "id": "f8bad0be0114b0036c596178f86e2416-->61313c33ffc04b0a4ff93735152c7ddf",
      "title": "<table class=\"table\">\n<tr><th>77</th><td>IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')</td></tr>\n</table>",
      "label": "77",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')",
          "event_id": 77,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "f8bad0be0114b0036c596178f86e2416",
      "to": "616d8e394381e6820e9956759c84d687",
      "id": "f8bad0be0114b0036c596178f86e2416-->616d8e394381e6820e9956759c84d687",
      "title": "<table class=\"table\">\n<tr><th>77</th><td>IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')</td></tr>\n</table>",
      "label": "77",
      "events": [
        {
          "event_str": "IntentEvent(intent='am start com.fsck.k9.debug/com.fsck.k9.activity.MessageList')",
          "event_id": 77,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "61313c33ffc04b0a4ff93735152c7ddf",
      "to": "f8bad0be0114b0036c596178f86e2416",
      "id": "61313c33ffc04b0a4ff93735152c7ddf-->f8bad0be0114b0036c596178f86e2416",
      "title": "<table class=\"table\">\n<tr><th>77</th><td>KeyEvent(state=61313c33ffc04b0a4ff93735152c7ddf, name=BACK)</td></tr>\n</table>",
      "label": "77",
      "events": [
        {
          "event_str": "KeyEvent(state=61313c33ffc04b0a4ff93735152c7ddf, name=BACK)",
          "event_id": 77,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "616d8e394381e6820e9956759c84d687",
      "to": "8cc687d9a0b35afcf13ab3ffb0fcddab",
      "id": "616d8e394381e6820e9956759c84d687-->8cc687d9a0b35afcf13ab3ffb0fcddab",
      "title": "<table class=\"table\">\n<tr><th>3</th><td>TouchEvent(state=616d8e394381e6820e9956759c84d687, view=8e194d50600b412a3ba9c17efed7f411(MessageList/ImageView-))</td></tr>\n</table>",
      "label": "3",
      "events": [
        {
          "event_str": "TouchEvent(state=616d8e394381e6820e9956759c84d687, view=8e194d50600b412a3ba9c17efed7f411(MessageList/ImageView-))",
          "event_id": 3,
          "event_type": "touch",
          "view_images": [
            "views/view_8e194d50600b412a3ba9c17efed7f411.png"
          ]
        }
      ]
    },
    {
      "from": "616d8e394381e6820e9956759c84d687",
      "to": "f8bad0be0114b0036c596178f86e2416",
      "id": "616d8e394381e6820e9956759c84d687-->f8bad0be0114b0036c596178f86e2416",
      "title": "<table class=\"table\">\n<tr><th>5</th><td>KeyEvent(state=616d8e394381e6820e9956759c84d687, name=BACK)</td></tr>\n</table>",
      "label": "5",
      "events": [
        {
          "event_str": "KeyEvent(state=616d8e394381e6820e9956759c84d687, name=BACK)",
          "event_id": 5,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "616d8e394381e6820e9956759c84d687",
      "to": "9fdc211f534f2f363cd0116ac5ea68ed",
      "id": "616d8e394381e6820e9956759c84d687-->9fdc211f534f2f363cd0116ac5ea68ed",
      "title": "<table class=\"table\">\n<tr><th>77</th><td>TouchEvent(state=616d8e394381e6820e9956759c84d687, view=da77da51cb9a01520cdd283ac2102cda(MessageList/ImageView-))</td></tr>\n</table>",
      "label": "77",
      "events": [
        {
          "event_str": "TouchEvent(state=616d8e394381e6820e9956759c84d687, view=da77da51cb9a01520cdd283ac2102cda(MessageList/ImageView-))",
          "event_id": 77,
          "event_type": "touch",
          "view_images": [
            "views/view_da77da51cb9a01520cdd283ac2102cda.png"
          ]
        }
      ]
    },
    {
      "from": "616d8e394381e6820e9956759c84d687",
      "to": "146e2e86d69f374726af95cb0e2d3b34",
      "id": "616d8e394381e6820e9956759c84d687-->146e2e86d69f374726af95cb0e2d3b34",
      "title": "<table class=\"table\">\n<tr><th>42</th><td>TouchEvent(state=616d8e394381e6820e9956759c84d687, view=ff8f22494c6a4b16c85d2491b1edba2f(MessageList/Button-))</td></tr>\n</table>",
      "label": "42",
      "events": [
        {
          "event_str": "TouchEvent(state=616d8e394381e6820e9956759c84d687, view=ff8f22494c6a4b16c85d2491b1edba2f(MessageList/Button-))",
          "event_id": 42,
          "event_type": "touch",
          "view_images": [
            "views/view_ff8f22494c6a4b16c85d2491b1edba2f.png"
          ]
        }
      ]
    },
    {
      "from": "616d8e394381e6820e9956759c84d687",
      "to": "97ee1d3fa10070f426e7258dfadcaa59",
      "id": "616d8e394381e6820e9956759c84d687-->97ee1d3fa10070f426e7258dfadcaa59",
      "title": "<table class=\"table\">\n<tr><th>51</th><td>TouchEvent(state=616d8e394381e6820e9956759c84d687, view=da77da51cb9a01520cdd283ac2102cda(MessageList/ImageView-))</td></tr>\n</table>",
      "label": "51",
      "events": [
        {
          "event_str": "TouchEvent(state=616d8e394381e6820e9956759c84d687, view=da77da51cb9a01520cdd283ac2102cda(MessageList/ImageView-))",
          "event_id": 51,
          "event_type": "touch",
          "view_images": [
            "views/view_da77da51cb9a01520cdd283ac2102cda.png"
          ]
        }
      ]
    },
    {
      "from": "616d8e394381e6820e9956759c84d687",
      "to": "30e56b6205f3da93a1d41c345505420a",
      "id": "616d8e394381e6820e9956759c84d687-->30e56b6205f3da93a1d41c345505420a",
      "title": "<table class=\"table\">\n<tr><th>64</th><td>TouchEvent(state=616d8e394381e6820e9956759c84d687, view=da77da51cb9a01520cdd283ac2102cda(MessageList/ImageView-))</td></tr>\n</table>",
      "label": "64",
      "events": [
        {
          "event_str": "TouchEvent(state=616d8e394381e6820e9956759c84d687, view=da77da51cb9a01520cdd283ac2102cda(MessageList/ImageView-))",
          "event_id": 64,
          "event_type": "touch",
          "view_images": [
            "views/view_da77da51cb9a01520cdd283ac2102cda.png"
          ]
        }
      ]
    },
    {
      "from": "8cc687d9a0b35afcf13ab3ffb0fcddab",
      "to": "616d8e394381e6820e9956759c84d687",
      "id": "8cc687d9a0b35afcf13ab3ffb0fcddab-->616d8e394381e6820e9956759c84d687",
      "title": "<table class=\"table\">\n<tr><th>4</th><td>TouchEvent(state=8cc687d9a0b35afcf13ab3ffb0fcddab, view=8e75944f4f8f32b551a0b0002fe70a92(MessageList/LinearLayout-))</td></tr>\n</table>",
      "label": "4",
      "events": [
        {
          "event_str": "TouchEvent(state=8cc687d9a0b35afcf13ab3ffb0fcddab, view=8e75944f4f8f32b551a0b0002fe70a92(MessageList/LinearLayout-))",
          "event_id": 4,
          "event_type": "touch",
          "view_images": [
            "views/view_8e75944f4f8f32b551a0b0002fe70a92.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "caf5631c1d562c25f2c46fafdf1c3dfc",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->caf5631c1d562c25f2c46fafdf1c3dfc",
      "title": "<table class=\"table\">\n<tr><th>30</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  ### Exa)</td></tr>\n</table>",
      "label": "30",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  ### Exa)",
          "event_id": 30,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "127fdca3223ebf0096869b24c7f5bdef",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->127fdca3223ebf0096869b24c7f5bdef",
      "title": "<table class=\"table\">\n<tr><th>19</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search)</td></tr>\n</table>",
      "label": "19",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search)",
          "event_id": 19,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>14</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=wireless headph)</td></tr>\n</table>",
      "label": "14",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=wireless headph)",
          "event_id": 14,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "8f4cbdf81b58433103e7bff8783cc97c",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->8f4cbdf81b58433103e7bff8783cc97c",
      "title": "<table class=\"table\">\n<tr><th>21</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  ### Cor)</td></tr>\n</table>",
      "label": "21",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  ### Cor)",
          "event_id": 21,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "5023782a7c74c17cc45f46c082238945",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->5023782a7c74c17cc45f46c082238945",
      "title": "<table class=\"table\">\n<tr><th>23</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=search ### Focu)</td></tr>\n</table>",
      "label": "23",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=search ### Focu)",
          "event_id": 23,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "dc7646d1f8cb97867ca0479c922f9edb",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->dc7646d1f8cb97867ca0479c922f9edb",
      "title": "<table class=\"table\">\n<tr><th>24</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  ### Gen)</td></tr>\n</table>",
      "label": "24",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  ### Gen)",
          "event_id": 24,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "bd2738a68bff2e585e96016c558ecc21",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->bd2738a68bff2e585e96016c558ecc21",
      "title": "<table class=\"table\">\n<tr><th>45</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=search </SYS>)</td></tr>\n</table>",
      "label": "45",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=search </SYS>)",
          "event_id": 45,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "97ee1d3fa10070f426e7258dfadcaa59",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->97ee1d3fa10070f426e7258dfadcaa59",
      "title": "<table class=\"table\">\n<tr><th>76</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search   Note:)</td></tr>\n</table>",
      "label": "76",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search   Note:)",
          "event_id": 76,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "46a5bdd4627f371e0f6bd253473604b9",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->46a5bdd4627f371e0f6bd253473604b9",
      "title": "<table class=\"table\">\n<tr><th>44</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  ### Foc)</td></tr>\n</table>",
      "label": "44",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  ### Foc)",
          "event_id": 44,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "4368245b81f81ad71cf2e77dfa1d9974",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->4368245b81f81ad71cf2e77dfa1d9974",
      "title": "<table class=\"table\">\n<tr><th>55</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  ### Ans)</td></tr>\n</table>",
      "label": "55",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  ### Ans)",
          "event_id": 55,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "970c8c0a2de66826cdb80e5c5624242a",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->970c8c0a2de66826cdb80e5c5624242a",
      "title": "<table class=\"table\">\n<tr><th>58</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  Note: T)</td></tr>\n</table>",
      "label": "58",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search  Note: T)",
          "event_id": 58,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "f66cd33b597c4c93cd46f268fc7ae34f",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->f66cd33b597c4c93cd46f268fc7ae34f",
      "title": "<table class=\"table\">\n<tr><th>62</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=search [INST] <)</td></tr>\n</table>",
      "label": "62",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=search [INST] <)",
          "event_id": 62,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "bfce3df1601f236bd87766ad4a166193",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->bfce3df1601f236bd87766ad4a166193",
      "title": "<table class=\"table\">\n<tr><th>66</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search ### Exam)</td></tr>\n</table>",
      "label": "66",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=Search ### Exam)",
          "event_id": 66,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "9fdc211f534f2f363cd0116ac5ea68ed",
      "to": "acb338538cab2b4ecc07bf4f4160fd5e",
      "id": "9fdc211f534f2f363cd0116ac5ea68ed-->acb338538cab2b4ecc07bf4f4160fd5e",
      "title": "<table class=\"table\">\n<tr><th>73</th><td>SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=search  ### Exa)</td></tr>\n</table>",
      "label": "73",
      "events": [
        {
          "event_str": "SetTextEvent(state=9fdc211f534f2f363cd0116ac5ea68ed, view=a51cfbc7e1204aa838e6056e48cc236a(MessageList/AutoCompleteTextView-   Search), text=search  ### Exa)",
          "event_id": 73,
          "event_type": "set_text",
          "view_images": [
            "views/view_a51cfbc7e1204aa838e6056e48cc236a.png"
          ]
        }
      ]
    },
    {
      "from": "caf5631c1d562c25f2c46fafdf1c3dfc",
      "to": "b6c5b26037ced8c3214cb06dcac7156d",
      "id": "caf5631c1d562c25f2c46fafdf1c3dfc-->b6c5b26037ced8c3214cb06dcac7156d",
      "title": "<table class=\"table\">\n<tr><th>8</th><td>SetTextEvent(state=caf5631c1d562c25f2c46fafdf1c3dfc, view=0b13f3a05f3adf21479f954e86208697(MessageList/AutoCompleteTextView-Search  ##), text=### Exa  ### Fi)</td></tr>\n</table>",
      "label": "8",
      "events": [
        {
          "event_str": "SetTextEvent(state=caf5631c1d562c25f2c46fafdf1c3dfc, view=0b13f3a05f3adf21479f954e86208697(MessageList/AutoCompleteTextView-Search  ##), text=### Exa  ### Fi)",
          "event_id": 8,
          "event_type": "set_text",
          "view_images": [
            "views/view_0b13f3a05f3adf21479f954e86208697.png"
          ]
        }
      ]
    },
    {
      "from": "caf5631c1d562c25f2c46fafdf1c3dfc",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "caf5631c1d562c25f2c46fafdf1c3dfc-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>27</th><td>SetTextEvent(state=caf5631c1d562c25f2c46fafdf1c3dfc, view=0b13f3a05f3adf21479f954e86208697(MessageList/AutoCompleteTextView-Search  ##), text=wireless headph)</td></tr>\n</table>",
      "label": "27",
      "events": [
        {
          "event_str": "SetTextEvent(state=caf5631c1d562c25f2c46fafdf1c3dfc, view=0b13f3a05f3adf21479f954e86208697(MessageList/AutoCompleteTextView-Search  ##), text=wireless headph)",
          "event_id": 27,
          "event_type": "set_text",
          "view_images": [
            "views/view_0b13f3a05f3adf21479f954e86208697.png"
          ]
        }
      ]
    },
    {
      "from": "caf5631c1d562c25f2c46fafdf1c3dfc",
      "to": "8ffd3ced1623467a1ae58c148842d277",
      "id": "caf5631c1d562c25f2c46fafdf1c3dfc-->8ffd3ced1623467a1ae58c148842d277",
      "title": "<table class=\"table\">\n<tr><th>31</th><td>SetTextEvent(state=caf5631c1d562c25f2c46fafdf1c3dfc, view=0b13f3a05f3adf21479f954e86208697(MessageList/AutoCompleteTextView-Search  ##), text=### Exa)</td></tr>\n</table>",
      "label": "31",
      "events": [
        {
          "event_str": "SetTextEvent(state=caf5631c1d562c25f2c46fafdf1c3dfc, view=0b13f3a05f3adf21479f954e86208697(MessageList/AutoCompleteTextView-Search  ##), text=### Exa)",
          "event_id": 31,
          "event_type": "set_text",
          "view_images": [
            "views/view_0b13f3a05f3adf21479f954e86208697.png"
          ]
        }
      ]
    },
    {
      "from": "b6c5b26037ced8c3214cb06dcac7156d",
      "to": "279e2d30f10555a4ed4cf436875fbef2",
      "id": "b6c5b26037ced8c3214cb06dcac7156d-->279e2d30f10555a4ed4cf436875fbef2",
      "title": "<table class=\"table\">\n<tr><th>9</th><td>SetTextEvent(state=b6c5b26037ced8c3214cb06dcac7156d, view=ac472abb6220888bdee94130bc2243d1(MessageList/AutoCompleteTextView-### Exa  #), text=ExaFi wirelessl)</td></tr>\n</table>",
      "label": "9",
      "events": [
        {
          "event_str": "SetTextEvent(state=b6c5b26037ced8c3214cb06dcac7156d, view=ac472abb6220888bdee94130bc2243d1(MessageList/AutoCompleteTextView-### Exa  #), text=ExaFi wirelessl)",
          "event_id": 9,
          "event_type": "set_text",
          "view_images": [
            "views/view_ac472abb6220888bdee94130bc2243d1.png"
          ]
        }
      ]
    },
    {
      "from": "279e2d30f10555a4ed4cf436875fbef2",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "279e2d30f10555a4ed4cf436875fbef2-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>10</th><td>SetTextEvent(state=279e2d30f10555a4ed4cf436875fbef2, view=6ab187566b7d601c592ad3e095e3de93(MessageList/AutoCompleteTextView-ExaFi wire), text=wireless headph)</td></tr>\n</table>",
      "label": "10",
      "events": [
        {
          "event_str": "SetTextEvent(state=279e2d30f10555a4ed4cf436875fbef2, view=6ab187566b7d601c592ad3e095e3de93(MessageList/AutoCompleteTextView-ExaFi wire), text=wireless headph)",
          "event_id": 10,
          "event_type": "set_text",
          "view_images": [
            "views/view_6ab187566b7d601c592ad3e095e3de93.png"
          ]
        }
      ]
    },
    {
      "from": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "to": "f8bad0be0114b0036c596178f86e2416",
      "id": "eeae072fb2e8d6ecbbe24c35f135a3a6-->f8bad0be0114b0036c596178f86e2416",
      "title": "<table class=\"table\">\n<tr><th>77</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "77",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 77,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "127fdca3223ebf0096869b24c7f5bdef",
      "to": "f7c50225c83a0cd86cced82b3caec230",
      "id": "127fdca3223ebf0096869b24c7f5bdef-->f7c50225c83a0cd86cced82b3caec230",
      "title": "<table class=\"table\">\n<tr><th>13</th><td>SetTextEvent(state=127fdca3223ebf0096869b24c7f5bdef, view=cd8a3a415c9bb8094681c679367e2059(MessageList/AutoCompleteTextView-Search), text=Search [INST] <)</td></tr>\n</table>",
      "label": "13",
      "events": [
        {
          "event_str": "SetTextEvent(state=127fdca3223ebf0096869b24c7f5bdef, view=cd8a3a415c9bb8094681c679367e2059(MessageList/AutoCompleteTextView-Search), text=Search [INST] <)",
          "event_id": 13,
          "event_type": "set_text",
          "view_images": [
            "views/view_cd8a3a415c9bb8094681c679367e2059.png"
          ]
        }
      ]
    },
    {
      "from": "127fdca3223ebf0096869b24c7f5bdef",
      "to": "f9da2cb689817346c1f496e37efd51e1",
      "id": "127fdca3223ebf0096869b24c7f5bdef-->f9da2cb689817346c1f496e37efd51e1",
      "title": "<table class=\"table\">\n<tr><th>15</th><td>SetTextEvent(state=127fdca3223ebf0096869b24c7f5bdef, view=cd8a3a415c9bb8094681c679367e2059(MessageList/AutoCompleteTextView-Search), text=Search  ### Det)</td></tr>\n</table>",
      "label": "15",
      "events": [
        {
          "event_str": "SetTextEvent(state=127fdca3223ebf0096869b24c7f5bdef, view=cd8a3a415c9bb8094681c679367e2059(MessageList/AutoCompleteTextView-Search), text=Search  ### Det)",
          "event_id": 15,
          "event_type": "set_text",
          "view_images": [
            "views/view_cd8a3a415c9bb8094681c679367e2059.png"
          ]
        }
      ]
    },
    {
      "from": "127fdca3223ebf0096869b24c7f5bdef",
      "to": "cebcaf3ffb903c5b13298e22ad072a28",
      "id": "127fdca3223ebf0096869b24c7f5bdef-->cebcaf3ffb903c5b13298e22ad072a28",
      "title": "<table class=\"table\">\n<tr><th>18</th><td>SetTextEvent(state=127fdca3223ebf0096869b24c7f5bdef, view=cd8a3a415c9bb8094681c679367e2059(MessageList/AutoCompleteTextView-Search), text=Search [/SYS])</td></tr>\n</table>",
      "label": "18",
      "events": [
        {
          "event_str": "SetTextEvent(state=127fdca3223ebf0096869b24c7f5bdef, view=cd8a3a415c9bb8094681c679367e2059(MessageList/AutoCompleteTextView-Search), text=Search [/SYS])",
          "event_id": 18,
          "event_type": "set_text",
          "view_images": [
            "views/view_cd8a3a415c9bb8094681c679367e2059.png"
          ]
        }
      ]
    },
    {
      "from": "127fdca3223ebf0096869b24c7f5bdef",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "127fdca3223ebf0096869b24c7f5bdef-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>20</th><td>SetTextEvent(state=127fdca3223ebf0096869b24c7f5bdef, view=cd8a3a415c9bb8094681c679367e2059(MessageList/AutoCompleteTextView-Search), text=wireless headph)</td></tr>\n</table>",
      "label": "20",
      "events": [
        {
          "event_str": "SetTextEvent(state=127fdca3223ebf0096869b24c7f5bdef, view=cd8a3a415c9bb8094681c679367e2059(MessageList/AutoCompleteTextView-Search), text=wireless headph)",
          "event_id": 20,
          "event_type": "set_text",
          "view_images": [
            "views/view_cd8a3a415c9bb8094681c679367e2059.png"
          ]
        }
      ]
    },
    {
      "from": "f7c50225c83a0cd86cced82b3caec230",
      "to": "f8bad0be0114b0036c596178f86e2416",
      "id": "f7c50225c83a0cd86cced82b3caec230-->f8bad0be0114b0036c596178f86e2416",
      "title": "<table class=\"table\">\n<tr><th>13</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "13",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 13,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "f9da2cb689817346c1f496e37efd51e1",
      "to": "47edfb97e557b545a0fedbc4a22b7600",
      "id": "f9da2cb689817346c1f496e37efd51e1-->47edfb97e557b545a0fedbc4a22b7600",
      "title": "<table class=\"table\">\n<tr><th>16</th><td>SetTextEvent(state=f9da2cb689817346c1f496e37efd51e1, view=94859a3441d6f83766abc5c9931137bc(MessageList/AutoCompleteTextView-Search  ##), text=### Det ### Det)</td></tr>\n</table>",
      "label": "16",
      "events": [
        {
          "event_str": "SetTextEvent(state=f9da2cb689817346c1f496e37efd51e1, view=94859a3441d6f83766abc5c9931137bc(MessageList/AutoCompleteTextView-Search  ##), text=### Det ### Det)",
          "event_id": 16,
          "event_type": "set_text",
          "view_images": [
            "views/view_94859a3441d6f83766abc5c9931137bc.png"
          ]
        }
      ]
    },
    {
      "from": "47edfb97e557b545a0fedbc4a22b7600",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "47edfb97e557b545a0fedbc4a22b7600-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>17</th><td>SetTextEvent(state=47edfb97e557b545a0fedbc4a22b7600, view=1921a30c47de77e341491c1c46862aad(MessageList/AutoCompleteTextView-### Det ##), text=wireless headph)</td></tr>\n</table>",
      "label": "17",
      "events": [
        {
          "event_str": "SetTextEvent(state=47edfb97e557b545a0fedbc4a22b7600, view=1921a30c47de77e341491c1c46862aad(MessageList/AutoCompleteTextView-### Det ##), text=wireless headph)",
          "event_id": 17,
          "event_type": "set_text",
          "view_images": [
            "views/view_1921a30c47de77e341491c1c46862aad.png"
          ]
        }
      ]
    },
    {
      "from": "cebcaf3ffb903c5b13298e22ad072a28",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "cebcaf3ffb903c5b13298e22ad072a28-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>19</th><td>SetTextEvent(state=cebcaf3ffb903c5b13298e22ad072a28, view=4b5c2358157cb451e1816e84831ee062(MessageList/AutoCompleteTextView-Search [/S), text=wireless headph)</td></tr>\n</table>",
      "label": "19",
      "events": [
        {
          "event_str": "SetTextEvent(state=cebcaf3ffb903c5b13298e22ad072a28, view=4b5c2358157cb451e1816e84831ee062(MessageList/AutoCompleteTextView-Search [/S), text=wireless headph)",
          "event_id": 19,
          "event_type": "set_text",
          "view_images": [
            "views/view_4b5c2358157cb451e1816e84831ee062.png"
          ]
        }
      ]
    },
    {
      "from": "8f4cbdf81b58433103e7bff8783cc97c",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "8f4cbdf81b58433103e7bff8783cc97c-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>22</th><td>SetTextEvent(state=8f4cbdf81b58433103e7bff8783cc97c, view=b21db7dedffdb83b8802c3b017de2938(MessageList/AutoCompleteTextView-Search  ##), text=wireless headph)</td></tr>\n</table>",
      "label": "22",
      "events": [
        {
          "event_str": "SetTextEvent(state=8f4cbdf81b58433103e7bff8783cc97c, view=b21db7dedffdb83b8802c3b017de2938(MessageList/AutoCompleteTextView-Search  ##), text=wireless headph)",
          "event_id": 22,
          "event_type": "set_text",
          "view_images": [
            "views/view_b21db7dedffdb83b8802c3b017de2938.png"
          ]
        }
      ]
    },
    {
      "from": "5023782a7c74c17cc45f46c082238945",
      "to": "f8bad0be0114b0036c596178f86e2416",
      "id": "5023782a7c74c17cc45f46c082238945-->f8bad0be0114b0036c596178f86e2416",
      "title": "<table class=\"table\">\n<tr><th>23</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "23",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 23,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "dc7646d1f8cb97867ca0479c922f9edb",
      "to": "f590b8ba7742eb094ce4a6d271582fc3",
      "id": "dc7646d1f8cb97867ca0479c922f9edb-->f590b8ba7742eb094ce4a6d271582fc3",
      "title": "<table class=\"table\">\n<tr><th>25</th><td>SetTextEvent(state=dc7646d1f8cb97867ca0479c922f9edb, view=75a5aeaddde25040318be999443ed623(MessageList/AutoCompleteTextView-Search  ##), text=### Gen ### Gen)</td></tr>\n</table>",
      "label": "25",
      "events": [
        {
          "event_str": "SetTextEvent(state=dc7646d1f8cb97867ca0479c922f9edb, view=75a5aeaddde25040318be999443ed623(MessageList/AutoCompleteTextView-Search  ##), text=### Gen ### Gen)",
          "event_id": 25,
          "event_type": "set_text",
          "view_images": [
            "views/view_75a5aeaddde25040318be999443ed623.png"
          ]
        }
      ]
    },
    {
      "from": "f590b8ba7742eb094ce4a6d271582fc3",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "f590b8ba7742eb094ce4a6d271582fc3-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>26</th><td>SetTextEvent(state=f590b8ba7742eb094ce4a6d271582fc3, view=c5f52498259cf92c53a58d708d0a4b5b(MessageList/AutoCompleteTextView-### Gen ##), text=wireless headph)</td></tr>\n</table>",
      "label": "26",
      "events": [
        {
          "event_str": "SetTextEvent(state=f590b8ba7742eb094ce4a6d271582fc3, view=c5f52498259cf92c53a58d708d0a4b5b(MessageList/AutoCompleteTextView-### Gen ##), text=wireless headph)",
          "event_id": 26,
          "event_type": "set_text",
          "view_images": [
            "views/view_c5f52498259cf92c53a58d708d0a4b5b.png"
          ]
        }
      ]
    },
    {
      "from": "bd2738a68bff2e585e96016c558ecc21",
      "to": "652f500c7c62167f2273e19c3bcb9977",
      "id": "bd2738a68bff2e585e96016c558ecc21-->652f500c7c62167f2273e19c3bcb9977",
      "title": "<table class=\"table\">\n<tr><th>29</th><td>SetTextEvent(state=bd2738a68bff2e585e96016c558ecc21, view=eb4089b94a6867d9f1e685e92854b5f5(MessageList/AutoCompleteTextView-search </S), text=search [/INST])</td></tr>\n</table>",
      "label": "29",
      "events": [
        {
          "event_str": "SetTextEvent(state=bd2738a68bff2e585e96016c558ecc21, view=eb4089b94a6867d9f1e685e92854b5f5(MessageList/AutoCompleteTextView-search </S), text=search [/INST])",
          "event_id": 29,
          "event_type": "set_text",
          "view_images": [
            "views/view_eb4089b94a6867d9f1e685e92854b5f5.png"
          ]
        }
      ]
    },
    {
      "from": "bd2738a68bff2e585e96016c558ecc21",
      "to": "22ac1c3821e05a5857e0ab9f3e049e67",
      "id": "bd2738a68bff2e585e96016c558ecc21-->22ac1c3821e05a5857e0ab9f3e049e67",
      "title": "<table class=\"table\">\n<tr><th>46</th><td>SetTextEvent(state=bd2738a68bff2e585e96016c558ecc21, view=eb4089b94a6867d9f1e685e92854b5f5(MessageList/AutoCompleteTextView-search </S), text=search)</td></tr>\n</table>",
      "label": "46",
      "events": [
        {
          "event_str": "SetTextEvent(state=bd2738a68bff2e585e96016c558ecc21, view=eb4089b94a6867d9f1e685e92854b5f5(MessageList/AutoCompleteTextView-search </S), text=search)",
          "event_id": 46,
          "event_type": "set_text",
          "view_images": [
            "views/view_eb4089b94a6867d9f1e685e92854b5f5.png"
          ]
        }
      ]
    },
    {
      "from": "652f500c7c62167f2273e19c3bcb9977",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "652f500c7c62167f2273e19c3bcb9977-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>30</th><td>SetTextEvent(state=652f500c7c62167f2273e19c3bcb9977, view=a13232cd65e35f5b8b3bbfec3ebfe919(MessageList/AutoCompleteTextView-search [/I), text=wireless headph)</td></tr>\n</table>",
      "label": "30",
      "events": [
        {
          "event_str": "SetTextEvent(state=652f500c7c62167f2273e19c3bcb9977, view=a13232cd65e35f5b8b3bbfec3ebfe919(MessageList/AutoCompleteTextView-search [/I), text=wireless headph)",
          "event_id": 30,
          "event_type": "set_text",
          "view_images": [
            "views/view_a13232cd65e35f5b8b3bbfec3ebfe919.png"
          ]
        }
      ]
    },
    {
      "from": "8ffd3ced1623467a1ae58c148842d277",
      "to": "3a2e2376da0f93c094f5f9826aa37c1a",
      "id": "8ffd3ced1623467a1ae58c148842d277-->3a2e2376da0f93c094f5f9826aa37c1a",
      "title": "<table class=\"table\">\n<tr><th>32</th><td>SetTextEvent(state=8ffd3ced1623467a1ae58c148842d277, view=fd1f9d3550e2dc451332435e67f28cf5(MessageList/AutoCompleteTextView-### Exa), text=Exa  ### Exampl)</td></tr>\n</table>",
      "label": "32",
      "events": [
        {
          "event_str": "SetTextEvent(state=8ffd3ced1623467a1ae58c148842d277, view=fd1f9d3550e2dc451332435e67f28cf5(MessageList/AutoCompleteTextView-### Exa), text=Exa  ### Exampl)",
          "event_id": 32,
          "event_type": "set_text",
          "view_images": [
            "views/view_fd1f9d3550e2dc451332435e67f28cf5.png"
          ]
        }
      ]
    },
    {
      "from": "3a2e2376da0f93c094f5f9826aa37c1a",
      "to": "919f479691fb0891d36b6766b1fcda54",
      "id": "3a2e2376da0f93c094f5f9826aa37c1a-->919f479691fb0891d36b6766b1fcda54",
      "title": "<table class=\"table\">\n<tr><th>33</th><td>SetTextEvent(state=3a2e2376da0f93c094f5f9826aa37c1a, view=d585cdbe68cc43eb97fe68cd102e605b(MessageList/AutoCompleteTextView-Exa  ### E), text=### Exampl  ###)</td></tr>\n</table>",
      "label": "33",
      "events": [
        {
          "event_str": "SetTextEvent(state=3a2e2376da0f93c094f5f9826aa37c1a, view=d585cdbe68cc43eb97fe68cd102e605b(MessageList/AutoCompleteTextView-Exa  ### E), text=### Exampl  ###)",
          "event_id": 33,
          "event_type": "set_text",
          "view_images": [
            "views/view_d585cdbe68cc43eb97fe68cd102e605b.png"
          ]
        }
      ]
    },
    {
      "from": "919f479691fb0891d36b6766b1fcda54",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "919f479691fb0891d36b6766b1fcda54-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>34</th><td>SetTextEvent(state=919f479691fb0891d36b6766b1fcda54, view=4448a15484568c100ee9c865da6f4446(MessageList/AutoCompleteTextView-### Exampl), text=wireless headph)</td></tr>\n</table>",
      "label": "34",
      "events": [
        {
          "event_str": "SetTextEvent(state=919f479691fb0891d36b6766b1fcda54, view=4448a15484568c100ee9c865da6f4446(MessageList/AutoCompleteTextView-### Exampl), text=wireless headph)",
          "event_id": 34,
          "event_type": "set_text",
          "view_images": [
            "views/view_4448a15484568c100ee9c865da6f4446.png"
          ]
        }
      ]
    },
    {
      "from": "97ee1d3fa10070f426e7258dfadcaa59",
      "to": "8574c640c133f4e4e4a4658ab45677d4",
      "id": "97ee1d3fa10070f426e7258dfadcaa59-->8574c640c133f4e4e4a4658ab45677d4",
      "title": "<table class=\"table\">\n<tr><th>76</th><td>SetTextEvent(state=97ee1d3fa10070f426e7258dfadcaa59, view=471bf830229ed5be798485e5fd381406(MessageList/AutoCompleteTextView-Search   N), text=search  Note:)</td></tr>\n</table>",
      "label": "76",
      "events": [
        {
          "event_str": "SetTextEvent(state=97ee1d3fa10070f426e7258dfadcaa59, view=471bf830229ed5be798485e5fd381406(MessageList/AutoCompleteTextView-Search   N), text=search  Note:)",
          "event_id": 76,
          "event_type": "set_text",
          "view_images": [
            "views/view_471bf830229ed5be798485e5fd381406.png"
          ]
        }
      ]
    },
    {
      "from": "97ee1d3fa10070f426e7258dfadcaa59",
      "to": "64c0fdccf8a65a5cd072b0e2c2590b54",
      "id": "97ee1d3fa10070f426e7258dfadcaa59-->64c0fdccf8a65a5cd072b0e2c2590b54",
      "title": "<table class=\"table\">\n<tr><th>50</th><td>SetTextEvent(state=97ee1d3fa10070f426e7258dfadcaa59, view=471bf830229ed5be798485e5fd381406(MessageList/AutoCompleteTextView-Search   N), text=Search   Note:)</td></tr>\n</table>",
      "label": "50",
      "events": [
        {
          "event_str": "SetTextEvent(state=97ee1d3fa10070f426e7258dfadcaa59, view=471bf830229ed5be798485e5fd381406(MessageList/AutoCompleteTextView-Search   N), text=Search   Note:)",
          "event_id": 50,
          "event_type": "set_text",
          "view_images": [
            "views/view_471bf830229ed5be798485e5fd381406.png"
          ]
        }
      ]
    },
    {
      "from": "97ee1d3fa10070f426e7258dfadcaa59",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "97ee1d3fa10070f426e7258dfadcaa59-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>61</th><td>SetTextEvent(state=97ee1d3fa10070f426e7258dfadcaa59, view=471bf830229ed5be798485e5fd381406(MessageList/AutoCompleteTextView-Search   N), text=wireless headph)</td></tr>\n</table>",
      "label": "61",
      "events": [
        {
          "event_str": "SetTextEvent(state=97ee1d3fa10070f426e7258dfadcaa59, view=471bf830229ed5be798485e5fd381406(MessageList/AutoCompleteTextView-Search   N), text=wireless headph)",
          "event_id": 61,
          "event_type": "set_text",
          "view_images": [
            "views/view_471bf830229ed5be798485e5fd381406.png"
          ]
        }
      ]
    },
    {
      "from": "8574c640c133f4e4e4a4658ab45677d4",
      "to": "fb88c8dea353a0385bf91f2f39e5aef6",
      "id": "8574c640c133f4e4e4a4658ab45677d4-->fb88c8dea353a0385bf91f2f39e5aef6",
      "title": "<table class=\"table\">\n<tr><th>37</th><td>SetTextEvent(state=8574c640c133f4e4e4a4658ab45677d4, view=3f36b060f427c70343a8d7b004ecc5ed(MessageList/AutoCompleteTextView-search  No), text=Note:  ### Exam)</td></tr>\n</table>",
      "label": "37",
      "events": [
        {
          "event_str": "SetTextEvent(state=8574c640c133f4e4e4a4658ab45677d4, view=3f36b060f427c70343a8d7b004ecc5ed(MessageList/AutoCompleteTextView-search  No), text=Note:  ### Exam)",
          "event_id": 37,
          "event_type": "set_text",
          "view_images": [
            "views/view_3f36b060f427c70343a8d7b004ecc5ed.png"
          ]
        }
      ]
    },
    {
      "from": "8574c640c133f4e4e4a4658ab45677d4",
      "to": "2d8ab988366202ee97ed409883a5e4b9",
      "id": "8574c640c133f4e4e4a4658ab45677d4-->2d8ab988366202ee97ed409883a5e4b9",
      "title": "<table class=\"table\">\n<tr><th>52</th><td>SetTextEvent(state=8574c640c133f4e4e4a4658ab45677d4, view=3f36b060f427c70343a8d7b004ecc5ed(MessageList/AutoCompleteTextView-search  No), text=search  Note: [)</td></tr>\n</table>",
      "label": "52",
      "events": [
        {
          "event_str": "SetTextEvent(state=8574c640c133f4e4e4a4658ab45677d4, view=3f36b060f427c70343a8d7b004ecc5ed(MessageList/AutoCompleteTextView-search  No), text=search  Note: [)",
          "event_id": 52,
          "event_type": "set_text",
          "view_images": [
            "views/view_3f36b060f427c70343a8d7b004ecc5ed.png"
          ]
        }
      ]
    },
    {
      "from": "8574c640c133f4e4e4a4658ab45677d4",
      "to": "6bc0c445b414722400f2c8f09899886b",
      "id": "8574c640c133f4e4e4a4658ab45677d4-->6bc0c445b414722400f2c8f09899886b",
      "title": "<table class=\"table\">\n<tr><th>68</th><td>SetTextEvent(state=8574c640c133f4e4e4a4658ab45677d4, view=3f36b060f427c70343a8d7b004ecc5ed(MessageList/AutoCompleteTextView-search  No), text=Note:)</td></tr>\n</table>",
      "label": "68",
      "events": [
        {
          "event_str": "SetTextEvent(state=8574c640c133f4e4e4a4658ab45677d4, view=3f36b060f427c70343a8d7b004ecc5ed(MessageList/AutoCompleteTextView-search  No), text=Note:)",
          "event_id": 68,
          "event_type": "set_text",
          "view_images": [
            "views/view_3f36b060f427c70343a8d7b004ecc5ed.png"
          ]
        }
      ]
    },
    {
      "from": "8574c640c133f4e4e4a4658ab45677d4",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "8574c640c133f4e4e4a4658ab45677d4-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>77</th><td>SetTextEvent(state=8574c640c133f4e4e4a4658ab45677d4, view=3f36b060f427c70343a8d7b004ecc5ed(MessageList/AutoCompleteTextView-search  No), text=wireless headph)</td></tr>\n</table>",
      "label": "77",
      "events": [
        {
          "event_str": "SetTextEvent(state=8574c640c133f4e4e4a4658ab45677d4, view=3f36b060f427c70343a8d7b004ecc5ed(MessageList/AutoCompleteTextView-search  No), text=wireless headph)",
          "event_id": 77,
          "event_type": "set_text",
          "view_images": [
            "views/view_3f36b060f427c70343a8d7b004ecc5ed.png"
          ]
        }
      ]
    },
    {
      "from": "fb88c8dea353a0385bf91f2f39e5aef6",
      "to": "b5cac7498a4807b26d71296071cd2a59",
      "id": "fb88c8dea353a0385bf91f2f39e5aef6-->b5cac7498a4807b26d71296071cd2a59",
      "title": "<table class=\"table\">\n<tr><th>38</th><td>SetTextEvent(state=fb88c8dea353a0385bf91f2f39e5aef6, view=5a962d9bc40dfa1f5e43c803fc684e93(MessageList/AutoCompleteTextView-Note:  ###), text=### Exam)</td></tr>\n</table>",
      "label": "38",
      "events": [
        {
          "event_str": "SetTextEvent(state=fb88c8dea353a0385bf91f2f39e5aef6, view=5a962d9bc40dfa1f5e43c803fc684e93(MessageList/AutoCompleteTextView-Note:  ###), text=### Exam)",
          "event_id": 38,
          "event_type": "set_text",
          "view_images": [
            "views/view_5a962d9bc40dfa1f5e43c803fc684e93.png"
          ]
        }
      ]
    },
    {
      "from": "b5cac7498a4807b26d71296071cd2a59",
      "to": "16aa6b2f81055a1c7d256f59eeccaf84",
      "id": "b5cac7498a4807b26d71296071cd2a59-->16aa6b2f81055a1c7d256f59eeccaf84",
      "title": "<table class=\"table\">\n<tr><th>39</th><td>SetTextEvent(state=b5cac7498a4807b26d71296071cd2a59, view=d7f22510e8c618628fd83354ff9690a8(MessageList/AutoCompleteTextView-### Exam), text=Exam  ### Examp)</td></tr>\n</table>",
      "label": "39",
      "events": [
        {
          "event_str": "SetTextEvent(state=b5cac7498a4807b26d71296071cd2a59, view=d7f22510e8c618628fd83354ff9690a8(MessageList/AutoCompleteTextView-### Exam), text=Exam  ### Examp)",
          "event_id": 39,
          "event_type": "set_text",
          "view_images": [
            "views/view_d7f22510e8c618628fd83354ff9690a8.png"
          ]
        }
      ]
    },
    {
      "from": "16aa6b2f81055a1c7d256f59eeccaf84",
      "to": "c3450744ca28d2b8d167cd5398c62263",
      "id": "16aa6b2f81055a1c7d256f59eeccaf84-->c3450744ca28d2b8d167cd5398c62263",
      "title": "<table class=\"table\">\n<tr><th>40</th><td>SetTextEvent(state=16aa6b2f81055a1c7d256f59eeccaf84, view=e017af14e1b659a3df80fed0a9a5f17d(MessageList/AutoCompleteTextView-Exam  ### ), text=Exam ###  Examp)</td></tr>\n</table>",
      "label": "40",
      "events": [
        {
          "event_str": "SetTextEvent(state=16aa6b2f81055a1c7d256f59eeccaf84, view=e017af14e1b659a3df80fed0a9a5f17d(MessageList/AutoCompleteTextView-Exam  ### ), text=Exam ###  Examp)",
          "event_id": 40,
          "event_type": "set_text",
          "view_images": [
            "views/view_e017af14e1b659a3df80fed0a9a5f17d.png"
          ]
        }
      ]
    },
    {
      "from": "c3450744ca28d2b8d167cd5398c62263",
      "to": "c1ea5af9bb96392814e220d8a359dae2",
      "id": "c3450744ca28d2b8d167cd5398c62263-->c1ea5af9bb96392814e220d8a359dae2",
      "title": "<table class=\"table\">\n<tr><th>41</th><td>SetTextEvent(state=c3450744ca28d2b8d167cd5398c62263, view=759263f862d70d4d5fd9539082187cd5(MessageList/AutoCompleteTextView-Exam ###  ), text=exam ###  examp)</td></tr>\n</table>",
      "label": "41",
      "events": [
        {
          "event_str": "SetTextEvent(state=c3450744ca28d2b8d167cd5398c62263, view=759263f862d70d4d5fd9539082187cd5(MessageList/AutoCompleteTextView-Exam ###  ), text=exam ###  examp)",
          "event_id": 41,
          "event_type": "set_text",
          "view_images": [
            "views/view_759263f862d70d4d5fd9539082187cd5.png"
          ]
        }
      ]
    },
    {
      "from": "c1ea5af9bb96392814e220d8a359dae2",
      "to": "f8bad0be0114b0036c596178f86e2416",
      "id": "c1ea5af9bb96392814e220d8a359dae2-->f8bad0be0114b0036c596178f86e2416",
      "title": "<table class=\"table\">\n<tr><th>41</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "41",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 41,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "146e2e86d69f374726af95cb0e2d3b34",
      "to": "616d8e394381e6820e9956759c84d687",
      "id": "146e2e86d69f374726af95cb0e2d3b34-->616d8e394381e6820e9956759c84d687",
      "title": "<table class=\"table\">\n<tr><th>43</th><td>TouchEvent(state=146e2e86d69f374726af95cb0e2d3b34, view=8e75944f4f8f32b551a0b0002fe70a92(MessageList/LinearLayout-))</td></tr>\n</table>",
      "label": "43",
      "events": [
        {
          "event_str": "TouchEvent(state=146e2e86d69f374726af95cb0e2d3b34, view=8e75944f4f8f32b551a0b0002fe70a92(MessageList/LinearLayout-))",
          "event_id": 43,
          "event_type": "touch",
          "view_images": [
            "views/view_8e75944f4f8f32b551a0b0002fe70a92.png"
          ]
        }
      ]
    },
    {
      "from": "46a5bdd4627f371e0f6bd253473604b9",
      "to": "733aa5148bf1cc3c9f8ce9bb39e078fe",
      "id": "46a5bdd4627f371e0f6bd253473604b9-->733aa5148bf1cc3c9f8ce9bb39e078fe",
      "title": "<table class=\"table\">\n<tr><th>45</th><td>SetTextEvent(state=46a5bdd4627f371e0f6bd253473604b9, view=4ce773af0d4c8c0bf93f1bdb4bdf6eec(MessageList/AutoCompleteTextView-Search  ##), text=### Foc  ### Fi)</td></tr>\n</table>",
      "label": "45",
      "events": [
        {
          "event_str": "SetTextEvent(state=46a5bdd4627f371e0f6bd253473604b9, view=4ce773af0d4c8c0bf93f1bdb4bdf6eec(MessageList/AutoCompleteTextView-Search  ##), text=### Foc  ### Fi)",
          "event_id": 45,
          "event_type": "set_text",
          "view_images": [
            "views/view_4ce773af0d4c8c0bf93f1bdb4bdf6eec.png"
          ]
        }
      ]
    },
    {
      "from": "733aa5148bf1cc3c9f8ce9bb39e078fe",
      "to": "f8bad0be0114b0036c596178f86e2416",
      "id": "733aa5148bf1cc3c9f8ce9bb39e078fe-->f8bad0be0114b0036c596178f86e2416",
      "title": "<table class=\"table\">\n<tr><th>45</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "45",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 45,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "22ac1c3821e05a5857e0ab9f3e049e67",
      "to": "acb338538cab2b4ecc07bf4f4160fd5e",
      "id": "22ac1c3821e05a5857e0ab9f3e049e67-->acb338538cab2b4ecc07bf4f4160fd5e",
      "title": "<table class=\"table\">\n<tr><th>47</th><td>SetTextEvent(state=22ac1c3821e05a5857e0ab9f3e049e67, view=cdb45ead263b5d0b1c87741da2bf0764(MessageList/AutoCompleteTextView-search), text=search  ### Exa)</td></tr>\n</table>",
      "label": "47",
      "events": [
        {
          "event_str": "SetTextEvent(state=22ac1c3821e05a5857e0ab9f3e049e67, view=cdb45ead263b5d0b1c87741da2bf0764(MessageList/AutoCompleteTextView-search), text=search  ### Exa)",
          "event_id": 47,
          "event_type": "set_text",
          "view_images": [
            "views/view_cdb45ead263b5d0b1c87741da2bf0764.png"
          ]
        }
      ]
    },
    {
      "from": "acb338538cab2b4ecc07bf4f4160fd5e",
      "to": "f34862b8cbfa821e5e91461a427c9dca",
      "id": "acb338538cab2b4ecc07bf4f4160fd5e-->f34862b8cbfa821e5e91461a427c9dca",
      "title": "<table class=\"table\">\n<tr><th>48</th><td>SetTextEvent(state=acb338538cab2b4ecc07bf4f4160fd5e, view=2a152d2591afe4559ae8217996e96b60(MessageList/AutoCompleteTextView-search  ##), text=### Exa  ### Ad)</td></tr>\n</table>",
      "label": "48",
      "events": [
        {
          "event_str": "SetTextEvent(state=acb338538cab2b4ecc07bf4f4160fd5e, view=2a152d2591afe4559ae8217996e96b60(MessageList/AutoCompleteTextView-search  ##), text=### Exa  ### Ad)",
          "event_id": 48,
          "event_type": "set_text",
          "view_images": [
            "views/view_2a152d2591afe4559ae8217996e96b60.png"
          ]
        }
      ]
    },
    {
      "from": "acb338538cab2b4ecc07bf4f4160fd5e",
      "to": "1d07fce7ccab5b2d047269955d22b798",
      "id": "acb338538cab2b4ecc07bf4f4160fd5e-->1d07fce7ccab5b2d047269955d22b798",
      "title": "<table class=\"table\">\n<tr><th>74</th><td>SetTextEvent(state=acb338538cab2b4ecc07bf4f4160fd5e, view=2a152d2591afe4559ae8217996e96b60(MessageList/AutoCompleteTextView-search  ##), text=search ### Exa)</td></tr>\n</table>",
      "label": "74",
      "events": [
        {
          "event_str": "SetTextEvent(state=acb338538cab2b4ecc07bf4f4160fd5e, view=2a152d2591afe4559ae8217996e96b60(MessageList/AutoCompleteTextView-search  ##), text=search ### Exa)",
          "event_id": 74,
          "event_type": "set_text",
          "view_images": [
            "views/view_2a152d2591afe4559ae8217996e96b60.png"
          ]
        }
      ]
    },
    {
      "from": "f34862b8cbfa821e5e91461a427c9dca",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "f34862b8cbfa821e5e91461a427c9dca-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>49</th><td>SetTextEvent(state=f34862b8cbfa821e5e91461a427c9dca, view=e85d1cc7568ebc11d603d7f806b0e172(MessageList/AutoCompleteTextView-### Exa  #), text=wireless headph)</td></tr>\n</table>",
      "label": "49",
      "events": [
        {
          "event_str": "SetTextEvent(state=f34862b8cbfa821e5e91461a427c9dca, view=e85d1cc7568ebc11d603d7f806b0e172(MessageList/AutoCompleteTextView-### Exa  #), text=wireless headph)",
          "event_id": 49,
          "event_type": "set_text",
          "view_images": [
            "views/view_e85d1cc7568ebc11d603d7f806b0e172.png"
          ]
        }
      ]
    },
    {
      "from": "64c0fdccf8a65a5cd072b0e2c2590b54",
      "to": "616d8e394381e6820e9956759c84d687",
      "id": "64c0fdccf8a65a5cd072b0e2c2590b54-->616d8e394381e6820e9956759c84d687",
      "title": "<table class=\"table\">\n<tr><th>64</th><td>KeyEvent(state=64c0fdccf8a65a5cd072b0e2c2590b54, name=BACK)</td></tr>\n</table>",
      "label": "64",
      "events": [
        {
          "event_str": "KeyEvent(state=64c0fdccf8a65a5cd072b0e2c2590b54, name=BACK)",
          "event_id": 64,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "2d8ab988366202ee97ed409883a5e4b9",
      "to": "82759ab3f0d87b32d1783bb5109fd153",
      "id": "2d8ab988366202ee97ed409883a5e4b9-->82759ab3f0d87b32d1783bb5109fd153",
      "title": "<table class=\"table\">\n<tr><th>53</th><td>SetTextEvent(state=2d8ab988366202ee97ed409883a5e4b9, view=6991c1b4d99a04087be609b1c48beb6e(MessageList/AutoCompleteTextView-search  No), text=Note: [</input>)</td></tr>\n</table>",
      "label": "53",
      "events": [
        {
          "event_str": "SetTextEvent(state=2d8ab988366202ee97ed409883a5e4b9, view=6991c1b4d99a04087be609b1c48beb6e(MessageList/AutoCompleteTextView-search  No), text=Note: [</input>)",
          "event_id": 53,
          "event_type": "set_text",
          "view_images": [
            "views/view_6991c1b4d99a04087be609b1c48beb6e.png"
          ]
        }
      ]
    },
    {
      "from": "82759ab3f0d87b32d1783bb5109fd153",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "82759ab3f0d87b32d1783bb5109fd153-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>54</th><td>SetTextEvent(state=82759ab3f0d87b32d1783bb5109fd153, view=a85715fc6de34d2b3b1b1b09d8943773(MessageList/AutoCompleteTextView-Note: [</i), text=wireless headph)</td></tr>\n</table>",
      "label": "54",
      "events": [
        {
          "event_str": "SetTextEvent(state=82759ab3f0d87b32d1783bb5109fd153, view=a85715fc6de34d2b3b1b1b09d8943773(MessageList/AutoCompleteTextView-Note: [</i), text=wireless headph)",
          "event_id": 54,
          "event_type": "set_text",
          "view_images": [
            "views/view_a85715fc6de34d2b3b1b1b09d8943773.png"
          ]
        }
      ]
    },
    {
      "from": "4368245b81f81ad71cf2e77dfa1d9974",
      "to": "b8cd42cb8b44f6cf61be699ab2ad3b7d",
      "id": "4368245b81f81ad71cf2e77dfa1d9974-->b8cd42cb8b44f6cf61be699ab2ad3b7d",
      "title": "<table class=\"table\">\n<tr><th>56</th><td>SetTextEvent(state=4368245b81f81ad71cf2e77dfa1d9974, view=5cf624dc59bec5765f1a7b840f83ed4c(MessageList/AutoCompleteTextView-Search  ##), text=### Ans  ### Fu)</td></tr>\n</table>",
      "label": "56",
      "events": [
        {
          "event_str": "SetTextEvent(state=4368245b81f81ad71cf2e77dfa1d9974, view=5cf624dc59bec5765f1a7b840f83ed4c(MessageList/AutoCompleteTextView-Search  ##), text=### Ans  ### Fu)",
          "event_id": 56,
          "event_type": "set_text",
          "view_images": [
            "views/view_5cf624dc59bec5765f1a7b840f83ed4c.png"
          ]
        }
      ]
    },
    {
      "from": "b8cd42cb8b44f6cf61be699ab2ad3b7d",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "b8cd42cb8b44f6cf61be699ab2ad3b7d-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>57</th><td>SetTextEvent(state=b8cd42cb8b44f6cf61be699ab2ad3b7d, view=f7bbed856e7a0fec673df619ca005781(MessageList/AutoCompleteTextView-### Ans  #), text=wireless headph)</td></tr>\n</table>",
      "label": "57",
      "events": [
        {
          "event_str": "SetTextEvent(state=b8cd42cb8b44f6cf61be699ab2ad3b7d, view=f7bbed856e7a0fec673df619ca005781(MessageList/AutoCompleteTextView-### Ans  #), text=wireless headph)",
          "event_id": 57,
          "event_type": "set_text",
          "view_images": [
            "views/view_f7bbed856e7a0fec673df619ca005781.png"
          ]
        }
      ]
    },
    {
      "from": "970c8c0a2de66826cdb80e5c5624242a",
      "to": "0fd61a526029735966c9352dfc03b822",
      "id": "970c8c0a2de66826cdb80e5c5624242a-->0fd61a526029735966c9352dfc03b822",
      "title": "<table class=\"table\">\n<tr><th>59</th><td>SetTextEvent(state=970c8c0a2de66826cdb80e5c5624242a, view=4d18927a5a8c9c7c5dfa7b6bb769c987(MessageList/AutoCompleteTextView-Search  No), text=Note: T Note: T)</td></tr>\n</table>",
      "label": "59",
      "events": [
        {
          "event_str": "SetTextEvent(state=970c8c0a2de66826cdb80e5c5624242a, view=4d18927a5a8c9c7c5dfa7b6bb769c987(MessageList/AutoCompleteTextView-Search  No), text=Note: T Note: T)",
          "event_id": 59,
          "event_type": "set_text",
          "view_images": [
            "views/view_4d18927a5a8c9c7c5dfa7b6bb769c987.png"
          ]
        }
      ]
    },
    {
      "from": "0fd61a526029735966c9352dfc03b822",
      "to": "de86ece2f17fda5b3895ad7e795f66c0",
      "id": "0fd61a526029735966c9352dfc03b822-->de86ece2f17fda5b3895ad7e795f66c0",
      "title": "<table class=\"table\">\n<tr><th>60</th><td>SetTextEvent(state=0fd61a526029735966c9352dfc03b822, view=03aec917823717cff6e9ac6bff573c87(MessageList/AutoCompleteTextView-Note: T No), text=Note: T [/INST])</td></tr>\n</table>",
      "label": "60",
      "events": [
        {
          "event_str": "SetTextEvent(state=0fd61a526029735966c9352dfc03b822, view=03aec917823717cff6e9ac6bff573c87(MessageList/AutoCompleteTextView-Note: T No), text=Note: T [/INST])",
          "event_id": 60,
          "event_type": "set_text",
          "view_images": [
            "views/view_03aec917823717cff6e9ac6bff573c87.png"
          ]
        }
      ]
    },
    {
      "from": "de86ece2f17fda5b3895ad7e795f66c0",
      "to": "f8bad0be0114b0036c596178f86e2416",
      "id": "de86ece2f17fda5b3895ad7e795f66c0-->f8bad0be0114b0036c596178f86e2416",
      "title": "<table class=\"table\">\n<tr><th>60</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "60",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 60,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "f66cd33b597c4c93cd46f268fc7ae34f",
      "to": "c0f6e1ac5b504d645bffe2f7fae3026b",
      "id": "f66cd33b597c4c93cd46f268fc7ae34f-->c0f6e1ac5b504d645bffe2f7fae3026b",
      "title": "<table class=\"table\">\n<tr><th>63</th><td>SetTextEvent(state=f66cd33b597c4c93cd46f268fc7ae34f, view=ee53f63ec7b31a762bce3ca14098f60a(MessageList/AutoCompleteTextView-search [IN), text=search [INST] <)</td></tr>\n</table>",
      "label": "63",
      "events": [
        {
          "event_str": "SetTextEvent(state=f66cd33b597c4c93cd46f268fc7ae34f, view=ee53f63ec7b31a762bce3ca14098f60a(MessageList/AutoCompleteTextView-search [IN), text=search [INST] <)",
          "event_id": 63,
          "event_type": "set_text",
          "view_images": [
            "views/view_ee53f63ec7b31a762bce3ca14098f60a.png"
          ]
        }
      ]
    },
    {
      "from": "c0f6e1ac5b504d645bffe2f7fae3026b",
      "to": "64c0fdccf8a65a5cd072b0e2c2590b54",
      "id": "c0f6e1ac5b504d645bffe2f7fae3026b-->64c0fdccf8a65a5cd072b0e2c2590b54",
      "title": "<table class=\"table\">\n<tr><th>64</th><td>TouchEvent(state=c0f6e1ac5b504d645bffe2f7fae3026b, view=a1e4d381da49678f55c5059dcbe5647c(MessageList/ImageButton-))</td></tr>\n</table>",
      "label": "64",
      "events": [
        {
          "event_str": "TouchEvent(state=c0f6e1ac5b504d645bffe2f7fae3026b, view=a1e4d381da49678f55c5059dcbe5647c(MessageList/ImageButton-))",
          "event_id": 64,
          "event_type": "touch",
          "view_images": [
            "views/view_a1e4d381da49678f55c5059dcbe5647c.png"
          ]
        }
      ]
    },
    {
      "from": "c0f6e1ac5b504d645bffe2f7fae3026b",
      "to": "616fed3907354827cd2c62b10747e955",
      "id": "c0f6e1ac5b504d645bffe2f7fae3026b-->616fed3907354827cd2c62b10747e955",
      "title": "<table class=\"table\">\n<tr><th>70</th><td>KeyEvent(state=c0f6e1ac5b504d645bffe2f7fae3026b, name=BACK)</td></tr>\n</table>",
      "label": "70",
      "events": [
        {
          "event_str": "KeyEvent(state=c0f6e1ac5b504d645bffe2f7fae3026b, name=BACK)",
          "event_id": 70,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "30e56b6205f3da93a1d41c345505420a",
      "to": "581f5c07eb069305131a01597d6e1e6a",
      "id": "30e56b6205f3da93a1d41c345505420a-->581f5c07eb069305131a01597d6e1e6a",
      "title": "<table class=\"table\">\n<tr><th>65</th><td>SetTextEvent(state=30e56b6205f3da93a1d41c345505420a, view=cbae422dcf632eb38e3429b2053920f7(MessageCompose/EditText-Message te), text=wireless headph)</td></tr>\n</table>",
      "label": "65",
      "events": [
        {
          "event_str": "SetTextEvent(state=30e56b6205f3da93a1d41c345505420a, view=cbae422dcf632eb38e3429b2053920f7(MessageCompose/EditText-Message te), text=wireless headph)",
          "event_id": 65,
          "event_type": "set_text",
          "view_images": [
            "views/view_cbae422dcf632eb38e3429b2053920f7.png"
          ]
        }
      ]
    },
    {
      "from": "581f5c07eb069305131a01597d6e1e6a",
      "to": "f8bad0be0114b0036c596178f86e2416",
      "id": "581f5c07eb069305131a01597d6e1e6a-->f8bad0be0114b0036c596178f86e2416",
      "title": "<table class=\"table\">\n<tr><th>65</th><td>IntentEvent(intent='am force-stop com.fsck.k9.debug')</td></tr>\n</table>",
      "label": "65",
      "events": [
        {
          "event_str": "IntentEvent(intent='am force-stop com.fsck.k9.debug')",
          "event_id": 65,
          "event_type": "intent",
          "view_images": []
        }
      ]
    },
    {
      "from": "bfce3df1601f236bd87766ad4a166193",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "bfce3df1601f236bd87766ad4a166193-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>67</th><td>SetTextEvent(state=bfce3df1601f236bd87766ad4a166193, view=5171a0dd1c96d6c127a1cbcd1e3bf9f6(MessageList/AutoCompleteTextView-Search ###), text=wireless headph)</td></tr>\n</table>",
      "label": "67",
      "events": [
        {
          "event_str": "SetTextEvent(state=bfce3df1601f236bd87766ad4a166193, view=5171a0dd1c96d6c127a1cbcd1e3bf9f6(MessageList/AutoCompleteTextView-Search ###), text=wireless headph)",
          "event_id": 67,
          "event_type": "set_text",
          "view_images": [
            "views/view_5171a0dd1c96d6c127a1cbcd1e3bf9f6.png"
          ]
        }
      ]
    },
    {
      "from": "6bc0c445b414722400f2c8f09899886b",
      "to": "c0f6e1ac5b504d645bffe2f7fae3026b",
      "id": "6bc0c445b414722400f2c8f09899886b-->c0f6e1ac5b504d645bffe2f7fae3026b",
      "title": "<table class=\"table\">\n<tr><th>69</th><td>SetTextEvent(state=6bc0c445b414722400f2c8f09899886b, view=bd67c3c40293f8d5c9f9367ea7600834(MessageList/AutoCompleteTextView-Note:), text=wireless headph)</td></tr>\n</table>",
      "label": "69",
      "events": [
        {
          "event_str": "SetTextEvent(state=6bc0c445b414722400f2c8f09899886b, view=bd67c3c40293f8d5c9f9367ea7600834(MessageList/AutoCompleteTextView-Note:), text=wireless headph)",
          "event_id": 69,
          "event_type": "set_text",
          "view_images": [
            "views/view_bd67c3c40293f8d5c9f9367ea7600834.png"
          ]
        }
      ]
    },
    {
      "from": "616fed3907354827cd2c62b10747e955",
      "to": "d18d481d150742140f105339679fcb89",
      "id": "616fed3907354827cd2c62b10747e955-->d18d481d150742140f105339679fcb89",
      "title": "<table class=\"table\">\n<tr><th>71</th><td>KeyEvent(state=616fed3907354827cd2c62b10747e955, name=BACK)</td></tr>\n</table>",
      "label": "71",
      "events": [
        {
          "event_str": "KeyEvent(state=616fed3907354827cd2c62b10747e955, name=BACK)",
          "event_id": 71,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "d18d481d150742140f105339679fcb89",
      "to": "616d8e394381e6820e9956759c84d687",
      "id": "d18d481d150742140f105339679fcb89-->616d8e394381e6820e9956759c84d687",
      "title": "<table class=\"table\">\n<tr><th>72</th><td>KeyEvent(state=d18d481d150742140f105339679fcb89, name=BACK)</td></tr>\n</table>",
      "label": "72",
      "events": [
        {
          "event_str": "KeyEvent(state=d18d481d150742140f105339679fcb89, name=BACK)",
          "event_id": 72,
          "event_type": "key",
          "view_images": []
        }
      ]
    },
    {
      "from": "1d07fce7ccab5b2d047269955d22b798",
      "to": "8bd32e01c21f644a2edd5f1e2b0f61c3",
      "id": "1d07fce7ccab5b2d047269955d22b798-->8bd32e01c21f644a2edd5f1e2b0f61c3",
      "title": "<table class=\"table\">\n<tr><th>75</th><td>SetTextEvent(state=1d07fce7ccab5b2d047269955d22b798, view=d48da13428c2709f13f221f6369c3838(MessageList/AutoCompleteTextView-search ###), text=### Exa  ### Sa)</td></tr>\n</table>",
      "label": "75",
      "events": [
        {
          "event_str": "SetTextEvent(state=1d07fce7ccab5b2d047269955d22b798, view=d48da13428c2709f13f221f6369c3838(MessageList/AutoCompleteTextView-search ###), text=### Exa  ### Sa)",
          "event_id": 75,
          "event_type": "set_text",
          "view_images": [
            "views/view_d48da13428c2709f13f221f6369c3838.png"
          ]
        }
      ]
    },
    {
      "from": "8bd32e01c21f644a2edd5f1e2b0f61c3",
      "to": "eeae072fb2e8d6ecbbe24c35f135a3a6",
      "id": "8bd32e01c21f644a2edd5f1e2b0f61c3-->eeae072fb2e8d6ecbbe24c35f135a3a6",
      "title": "<table class=\"table\">\n<tr><th>76</th><td>SetTextEvent(state=8bd32e01c21f644a2edd5f1e2b0f61c3, view=d372c18a29e40b07373cbdf2ad88f2e1(MessageList/AutoCompleteTextView-### Exa  #), text=wireless headph)</td></tr>\n</table>",
      "label": "76",
      "events": [
        {
          "event_str": "SetTextEvent(state=8bd32e01c21f644a2edd5f1e2b0f61c3, view=d372c18a29e40b07373cbdf2ad88f2e1(MessageList/AutoCompleteTextView-### Exa  #), text=wireless headph)",
          "event_id": 76,
          "event_type": "set_text",
          "view_images": [
            "views/view_d372c18a29e40b07373cbdf2ad88f2e1.png"
          ]
        }
      ]
    }
  ],
  "num_nodes": 54,
  "num_edges": 86,
  "num_effective_events": 77,
  "num_reached_activities": 2,
  "test_date": "2025-06-29 12:35:28",
  "time_spent": 1519.703992,
  "num_transitions": 244,
  "device_serial": "emulator-5554",
  "device_model_number": "sdk_gphone64_x86_64",
  "device_sdk_version": 35,
  "app_sha256": "44fdd3523a2839bc2f11f729ef1f48defbfc76a2a74fd27a55121a265e85c457",
  "app_package": "com.fsck.k9.debug",
  "app_main_activity": "com.fsck.k9.activity.MessageList",
  "app_num_total_activities": 28
}